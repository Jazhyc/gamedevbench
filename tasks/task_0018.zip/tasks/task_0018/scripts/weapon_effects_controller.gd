extends Node

@export_node_path("Node3D") var barrel_end_path: NodePath
@export_node_path("RayCast3D") var barrel_raycast_path: NodePath
@export var muzzle_flash_scene: PackedScene
@export var impact_effect_scene: PackedScene
@export var impact_force: float = 20.0

var has_round_available := false
var _current_round_count := 0
var barrel_end: Node3D
var barrel_raycast: RayCast3D

func _ready() -> void:
	barrel_end = get_node_or_null(barrel_end_path)
	barrel_raycast = get_node_or_null(barrel_raycast_path)
	reload()

func reload() -> void:
	_current_round_count = 6
	has_round_available = true

func fire_revolver() -> void:
	if not has_round_available:
		return

	_current_round_count -= 1
	has_round_available = _current_round_count > 0

	_spawn_muzzle_flash()
	_handle_hit()

func _spawn_muzzle_flash() -> void:
	if not muzzle_flash_scene or not barrel_end:
		return

	var effect := muzzle_flash_scene.instantiate()
	if effect is Node3D:
		barrel_end.add_child(effect)
		effect.global_transform = barrel_end.global_transform
	else:
		barrel_end.add_child(effect)

func _handle_hit() -> void:
	if not barrel_raycast or not barrel_raycast.is_colliding():
		return

	var hit_location := barrel_raycast.get_collision_point()
	var effect_to_spawn: PackedScene = impact_effect_scene
	var collider := barrel_raycast.get_collider()

	if collider is RigidBody3D:
		var impulse := -barrel_raycast.global_transform.basis.z * impact_force
		collider.apply_impulse(impulse, hit_location - collider.global_position)

	if collider is Node:
		for child in collider.get_children():
			if child.has_method("hit_object"):
				var custom_effect = child.get("impact_effect") if child.has_method("get") else null
				if custom_effect:
					effect_to_spawn = custom_effect
				child.hit_object(hit_location, -barrel_raycast.global_transform.basis.z * impact_force)
				break

	if effect_to_spawn:
		var new_effect := effect_to_spawn.instantiate()
		if new_effect is Node3D:
			add_child(new_effect)
			new_effect.global_position = hit_location
			var normal := barrel_raycast.get_collision_normal()
			if normal.length() > 0.01:
				var up := Vector3.UP if abs(normal.y) < 0.99 else Vector3.BACK
				new_effect.look_at(hit_location + normal, up)
		else:
			add_child(new_effect)
