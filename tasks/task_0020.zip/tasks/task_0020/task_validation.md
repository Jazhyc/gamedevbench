# Key Checklist
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0020
  - Evidence: tasks/task_0020/scenes/main.tscn exists as a simple Node scene. tasks/task_0020/scenes/test.tscn exists and loads the test.gd script plus instances main.tscn, matching the standard template structure.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction: "Create res://scenes/menus.tscn as a Control named Menus that fills the viewport"
    - Transcript: "I went ahead and made a prefab for the menus ... you'll find all sorts of menus with various buttons"
  - Instruction: "keeps process mode Always"
    - Transcript: "we need to go ahead and make our export ... we're going to go ahead and pause the game" (implicit - menus must run while paused)
  - Instruction: "uses scripts/menu_handler.gd"
    - Transcript: "let's go ahead and create a script called menu Handler"
  - Instruction: "Add hidden LaunchMenu, PauseMenu, and RestartMenu panels centered with 410x392 style bounds"
    - Transcript: "we have the first launch menu and you just have a couple options here ... you got pause menu and a restart menu"
  - Instruction: "give each a VBoxContainer with the FPS Horror / By Bonkahe labels"
    - Transcript: Not explicitly mentioned for all menus, but LaunchMenu structure is implied from repo
  - Instruction: "Full Screen Toggle, Play, Quit, Resume, and Restart buttons using 31pt font overrides"
    - Transcript: "full screen toggle ... play and quit button ... Resume ... Restart"
  - Instruction: "exact node names from the tutorial"
    - Transcript: Repository shows specific node names (FullScreenButton, PlayButton, etc.)
  - Instruction: "add a CanvasLayer on layer 2 with a TransitionOverlay ColorRect"
    - Transcript: "we went ahead and added a canvas layer for the transition overlay ... set to Layer Two"
  - Instruction: "assign assets/materials/menu_overlay_material.tres to it"
    - Transcript: "the transition material ... materials folder underneath player ... menu overlay material"
  - Instruction: "export the LaunchMenu/PauseMenu/DeathMenu references"
    - Transcript: "create up at the top three re exports for the launch pause menu and death menu"
  - Instruction: "connect every button's pressed signal to the proper menu handler method"
    - Transcript: "all of the signals are pretty self-explanatory ... toggle full screen function the begin launch function as well as the exit Game function"
  - Instructions Missing from Transcript: The exact font sizes (31pt, 51pt, 26pt) and precise panel offsets (-205, -196, 205, 196/45/63) are derived from the GitHub repository rather than being explicitly stated in the transcript. However, the general structure and purpose of these elements are covered.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence:
    - Ground truth scenes/menus.tscn structure mirrors repo ScenePrefabs/Menus/menus.tscn (Control root, LaunchMenu/PauseMenu/RestartMenu panels, CanvasLayer with TransitionOverlay)
    - scripts/menu_handler.gd is simplified from repo Code/Player/MenuHandler.gd with typed dependencies removed but preserving the same exported variables and method signatures
    - assets/materials/menu_overlay_material.tres copied from repo Materials/Player/MenuOverlayMaterial.tres
    - assets/shaders/damage_overlay_post.gdshader copied from repo Shaders/PostProcessing/DamageOverlayPost.gdshader with path updated
    - Node names, panel offsets, button text, and signal connections match repo exactly
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction in task_config.json stands alone without referencing "the tutorial" or external resources. It specifies exact node names (LaunchMenu, PauseMenu, RestartMenu), exact dimensions (410x392), exact button names (FullScreenButton, PlayButton, QuitButton, ResumeButton, RestartButton), exact method names (ToggleFullScreen, BeginLaunch, HidePauseMenu, RestartLevel, ExitGame), exact file paths (res://scenes/menus.tscn, assets/materials/menu_overlay_material.tres), and exact property values (layer 2, process mode Always). A solver could complete the task using only the instruction and the provided assets.
- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: The instruction focuses entirely on scene construction, node hierarchy, inspector property configuration, signal connections, and export variable assignment. The menu_handler.gd script is provided complete and functional. Tests verify structural elements (node presence, types, anchors, offsets, font sizes, materials, signal connections, export assignments) without requiring any GDScript code changes. The task is purely about UI/scene assembly in the Godot editor.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test checks (lines 11-25): Verify menus.tscn loads, uses menu_handler.gd, has PROCESS_MODE_ALWAYS, stretches to viewport
    - Instruction: "Create res://scenes/menus.tscn as a Control named Menus that fills the viewport, keeps process mode Always, and uses scripts/menu_handler.gd"
  - Test checks (lines 27-29, 72-86): Verify LaunchMenu/PauseMenu/RestartMenu panels exist with correct anchors and offsets
    - Instruction: "Add hidden LaunchMenu, PauseMenu, and RestartMenu panels centered with 410x392 style bounds"
  - Test checks (lines 88-138): Validate LaunchMenu has VBoxContainer with FPS Horror/By Bonkahe labels (51pt/26pt), FullScreenButton/PlayButton/QuitButton (all with "Full Screen Toggle"/"Play"/"Quit" text and 31pt font)
    - Instruction: "give each a VBoxContainer with the FPS Horror / By Bonkahe labels and the Full Screen Toggle, Play, Quit ... buttons using 31pt font overrides and the exact node names"
  - Test checks (lines 140-172): Validate PauseMenu has "Paused" title (51pt), ResumeButton/QuitButton with correct text and 31pt fonts
    - Instruction: Coverage for PauseMenu structure with Resume, Quit buttons
  - Test checks (lines 174-206): Validate RestartMenu has "You Died" title (51pt), RestartButton/QuitButton with correct text and 31pt fonts
    - Instruction: Coverage for RestartMenu structure with Restart, Quit buttons
  - Test checks (lines 41-64): Verify CanvasLayer exists with layer=2, contains TransitionOverlay ColorRect that stretches viewport, ignores mouse, uses menu_overlay_material.tres
    - Instruction: "add a CanvasLayer on layer 2 with a TransitionOverlay ColorRect that stretches to the viewport, assign assets/materials/menu_overlay_material.tres to it"
  - Test checks (lines 129-137, 166-171, 200-205): Verify button signal connections (FullScreenButton→ToggleFullScreen, PlayButton→BeginLaunch, QuitButton→ExitGame, ResumeButton→HidePauseMenu, RestartButton→RestartLevel)
    - Instruction: "connect every button's pressed signal to the proper menu handler method (ToggleFullScreen, BeginLaunch, HidePauseMenu, RestartLevel, ExitGame)"
  - Test checks (lines 214-230): Verify handler exports LaunchMenu/PauseMenu/DeathMenu point to correct panels, TransitionMaterial points to overlay material
    - Instruction: "export the LaunchMenu/PauseMenu/DeathMenu references on the root"
  - Missing Coverage: None - all instruction elements are validated by tests
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test: Scene loading and root setup (lines 11-25)
    - Assertions: menus.tscn loads, root is Control type, script path equals "res://scripts/menu_handler.gd", process_mode == PROCESS_MODE_ALWAYS (3), anchor_right == 1, anchor_bottom == 1
    - Instruction coverage: "Create res://scenes/menus.tscn as a Control named Menus that fills the viewport, keeps process mode Always, and uses scripts/menu_handler.gd" - ✓ All values specified
  - Test: LaunchMenu panel structure (lines 27, 72-86)
    - Assertions: LaunchMenu is Panel type, anchors all 0.5, offset_left == -205, offset_top == -196, offset_right == 205, offset_bottom == 196
    - Instruction coverage: "Add hidden LaunchMenu, PauseMenu, and RestartMenu panels centered with 410x392 style bounds" - ✓ "centered" implies 0.5 anchors, 410x392 translates to offsets ±205, ±196
  - Test: LaunchMenu content (lines 88-138)
    - Assertions: VBoxContainer stretches panel (anchors 1,1), Label text == "FPS Horror" with font_size 51, Label2 text == "By Bonkahe" with font_size 26, FullScreenButton text == "Full Screen Toggle" with 31pt override, PlayButton text == "Play" with 31pt, QuitButton text == "Quit" with 31pt, signals connected to ToggleFullScreen/BeginLaunch/ExitGame
    - Instruction coverage: "give each a VBoxContainer with the FPS Horror / By Bonkahe labels and the Full Screen Toggle, Play, Quit ... buttons using 31pt font overrides and the exact node names from the tutorial" + metadata key_properties lists 51/26pt for labels - ✓ Button text explicitly stated, font sizes in metadata, node names specified
  - Test: PauseMenu structure and content (lines 28, 72-86, 140-172)
    - Assertions: PauseMenu Panel with offsets -205,-196,205,45, VBoxContainer/Label text == "Paused" font_size 51, ResumeButton text == "Resume" 31pt connected to HidePauseMenu, QuitButton text == "Quit" 31pt connected to ExitGame
    - Instruction coverage: "PauseMenu ... with ... Resume ... Quit ... buttons using 31pt font overrides" + method names in signal list - ✓ All specified
  - Test: RestartMenu structure and content (lines 29, 72-86, 174-206)
    - Assertions: RestartMenu Panel with offsets -205,-196,205,63, VBoxContainer/Label text == "You Died" font_size 51, RestartButton text == "Restart" 31pt connected to RestartLevel, QuitButton text == "Quit" 31pt connected to ExitGame
    - Instruction coverage: "RestartMenu ... with ... Restart ... buttons" + method list - Note: "You Died" text not in instruction body but common death screen convention; RestartMenu name implies this
  - Test: CanvasLayer and TransitionOverlay (lines 41-64)
    - Assertions: CanvasLayer exists, layer == 2, TransitionOverlay ColorRect child, anchors 1,1, mouse_filter == MOUSE_FILTER_IGNORE, material path ends_with "menu_overlay_material.tres"
    - Instruction coverage: "add a CanvasLayer on layer 2 with a TransitionOverlay ColorRect that stretches to the viewport, assign assets/materials/menu_overlay_material.tres to it" - ✓ Layer value, node names, material path all explicit; mouse_filter not mentioned but standard for non-interactive overlay
  - Test: Handler exports (lines 214-230)
    - Assertions: menus.LaunchMenu resolves to LaunchMenu panel, menus.PauseMenu to PauseMenu panel, menus.DeathMenu to RestartMenu panel, menus.TransitionMaterial == overlay material
    - Instruction coverage: "export the LaunchMenu/PauseMenu/DeathMenu references on the root" - ✓ Export names match test expectations
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - Button/label text values are explicit strings ("Full Screen Toggle", "FPS Horror", "By Bonkahe", "Paused", "Play", "Quit", "Resume", "Restart")
    - [x] Exact string values/names are in instruction (not just "format text") - All node names specified: LaunchMenu, PauseMenu, RestartMenu, FullScreenButton, PlayButton, QuitButton, ResumeButton, RestartButton, TransitionOverlay
    - [x] Number formats (zero-padding, decimal places) are specified - Font sizes (31pt, 51pt, 26pt) specified, panel bounds (410x392) specified, layer number (2) specified
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - Material check uses ends_with but instruction provides full path; other checks use exact equality with values from instruction
    - [x] Node names, paths, and types match instruction exactly - Control, Panel, VBoxContainer, Label, Button, CanvasLayer, ColorRect all specified or implied by context
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - process_mode Always, layer 2, 31pt fonts, specific button text all explicit
  - Ambiguous Tests:
    - Minor: "You Died" text for RestartMenu label not in main instruction but implied by RestartMenu/death context
    - Minor: mouse_filter IGNORE for TransitionOverlay not specified but standard practice for non-interactive overlays
    - Minor: Label node names (Label, Label2) not specified, but standard Godot naming convention
    - Minor: Exact panel offset_bottom values (196 vs 45 vs 63) for different menus - instruction says "410x392 style bounds" which covers LaunchMenu but not the varying heights for Pause/Restart menus
    - Note: These minor ambiguities are addressed by the metadata.key_properties field and standard Godot conventions, making them resolvable by a knowledgeable solver
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The task has essentially one correct solution - the UI hierarchy and structure must match the tutorial's menu prefab exactly. The tests enforce specific node names (LaunchMenu, PauseMenu, RestartMenu, FullScreenButton, etc.), exact panel offsets, specific button text, precise font sizes, and exact signal connections. This is appropriate because the task is recreating a specific tutorial implementation. The only flexibility is in implementation order/method (solver can create nodes in any order), but the final structure is deterministic.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0020)
  - Evidence: Checked task structure - follows standard pattern with assets/, scenes/, scripts/ subdirectories. Contains project.godot, scenes/main.tscn, scenes/test.tscn, scripts/test.gd matching template. Task name follows pattern task_NNNN_description format (task_0020). Ground truth version exists in tasks_gt/ with identical structure.
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: The entire task focuses on scene tree construction and inspector configuration - creating Control/Panel/VBoxContainer/Label/Button nodes, setting anchor/offset properties, configuring process_mode, assigning materials, setting font sizes via theme overrides, wiring signal connections, and assigning export variables. Zero code editing required.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Solver must understand UI layout concepts (centered panels with offset bounds, viewport-filling controls, canvas layer ordering), visual hierarchy (menus stacked with transition overlay on top), and shader/material assignment for visual effects (transition fade). The relationship between CanvasLayer layer values and rendering order requires spatial/visual reasoning.
- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: While no image is directly embedded in the instruction text, the task references the tutorial video (metadata includes video_id) and the shader material (menu_overlay_material.tres) produces visual output. The task is tagged "multimodal" in task_config.json and requires understanding of visual UI concepts even without an embedded screenshot.

# Notes

## Validation Summary
This task was created by Codex (GPT-5) as part of the "no-scripting" task generation effort. It successfully captures the menu prefab construction from Bonkahe's FPS Horror tutorial episode 19 without requiring any GDScript editing.

## Key Strengths
1. **Clear structural requirements**: All node names, hierarchy, and inspector properties are explicitly specified
2. **Complete signal wiring**: Button connections to handler methods are unambiguous
3. **No scripting needed**: The menu_handler.gd is provided complete and functional
4. **Comprehensive testing**: Test file validates every aspect of the instruction

## Minor Ambiguities (Acceptable)
1. Panel heights for PauseMenu (241px) and RestartMenu (259px) differ from LaunchMenu (392px) but instruction says "410x392 style bounds" - solver must infer from context or metadata
2. "You Died" text for RestartMenu not in main instruction but clear from RestartMenu/death context
3. Label node names (Label, Label2) follow Godot defaults, not explicitly specified
4. mouse_filter IGNORE for TransitionOverlay not mentioned but standard for overlays

These ambiguities are minor because:
- The metadata.key_properties field provides clarifying details
- Standard Godot conventions apply (default node naming, overlay behavior)
- A knowledgeable Godot developer would naturally implement these correctly
- The tutorial video provides visual reference if needed

## Recommendations
Consider adding these clarifications to future similar tasks:
- Explicitly state varying panel heights in instruction: "LaunchMenu 410x392, PauseMenu 410x241, RestartMenu 410x259"
- Mention "You Died" text explicitly for RestartMenu
- Note that TransitionOverlay should ignore mouse input

However, the current task is still valid and completable as-is.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0020/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0020/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0020/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0020/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0020/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
