# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Analyzed tasks/task_0023/scenes/main.tscn (lines 1-33) - missing HUD CanvasLayer and DamageLabel that are required by test.gd (lines 21-24, 26-29, 31-33). Starting point will fail on "Add a CanvasLayer named HUD to host damage UI" check.
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Analyzed tasks_gt/task_0023/scenes/main.tscn (lines 34-40) - contains HUD CanvasLayer with DamageLabel set to "Total Damage: 0", and has signal connection from Player.taken_damage to Main._on_player_taken_damage. Main.gd (lines 10-13) correctly implements _on_player_taken_damage handler that updates total_damage and label text. Character.gd (lines 7-8) emits taken_damage signal with value 20.
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0023
  - Evidence: Both tasks/task_0023/ and tasks_gt/task_0023/ contain scenes/main.tscn and scenes/test.tscn. File structure matches expected pattern.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Create CanvasLayer named HUD with Label called DamageLabel / "my character could have a specific amount of Health it could have some kind of health bar that is going to be tracked by the main function"
  - DamageLabel starts at "Total Damage: 0" / "let's just say VAR total damage which is going to be initialized to zero"
  - Connect Player.taken_damage signal to Main._on_player_taken_damage / "if I go to my player you would see in the interface that I have this taken damage signal here if I double click it I can connect it to the main scene... on player taken damage function"
  - Label updates each time Player.take_damage emits 20 damage / "taken damage do Emit and we can even pass a value so I could for example pass that our character has taken like 20 damage... total damage equals to plus equals to damage"
  - Instructions Missing from Transcript: None. All instruction elements are covered in the transcript.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Code pattern matches transcript tutorial code structure. Character.gd signal definition (line 3: "signal taken_damage") and emit pattern (line 8: "taken_damage.emit(20)") matches tutorial. Main.gd handler (lines 10-13) matches transcript pattern of "total damage equals plus equals damage" and updating label text. Note: No repo folder exists at tutorials/Cashew OldDew/Signals in Godot 4.3/repo, but code structure clearly follows the tutorial transcript patterns.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: Instruction specifies exact node types (CanvasLayer, Label, CharacterBody2D), exact names (HUD, DamageLabel, Player), exact text value ("Total Damage: 0"), exact signal name (taken_damage), exact method name (_on_player_taken_damage), and exact damage value (20). No references to external tutorials or videos.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 11-14): Check Main exists as Node2D / Instruction: "In res://scenes/main.tscn create..."
  - Test 2 (lines 16-19): Check Player exists as CharacterBody2D under Main / Instruction: "...Player node's taken_damage signal..."
  - Test 3 (lines 21-24): Check HUD exists as CanvasLayer under Main / Instruction: "...create a CanvasLayer named HUD..."
  - Test 4 (lines 26-29): Check DamageLabel exists as Label under HUD / Instruction: "...with a Label called DamageLabel..."
  - Test 5 (lines 31-33): Check DamageLabel initial text / Instruction: "...that starts at \"Total Damage: 0\"..."
  - Test 6 (lines 35-38): Check signal connection Player.taken_damage -> Main._on_player_taken_damage / Instruction: "...connect the Player node's taken_damage signal to Main._on_player_taken_damage..."
  - Test 7 (lines 40-44): Check total_damage tracks emitted 20 damage / Instruction: "...Player.take_damage emits 20 damage"
  - Test 8 (lines 46-48): Check DamageLabel updates to "Total Damage: 20" / Instruction: "...the label updates each time Player.take_damage emits 20 damage"
  - Missing Coverage: None. All instruction elements are tested and all tests match instruction requirements.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1, Assertions: [main_node exists, main_node is Node2D], Instruction coverage: "In res://scenes/main.tscn" (implies Main node exists as root)
  - Test 2, Assertions: [player exists, player is CharacterBody2D], Instruction coverage: "Player node's taken_damage signal" (explicitly mentions Player node as CharacterBody2D type implied by context)
  - Test 3, Assertions: [hud exists, hud is CanvasLayer], Instruction coverage: "create a CanvasLayer named HUD"
  - Test 4, Assertions: [damage_label exists, damage_label is Label], Instruction coverage: "with a Label called DamageLabel"
  - Test 5, Assertions: [damage_label.text == "Total Damage: 0"], Instruction coverage: "that starts at \"Total Damage: 0\"" (exact string specified)
  - Test 6, Assertions: [player.is_connected("taken_damage", Callable(main_node, "_on_player_taken_damage"))], Instruction coverage: "connect the Player node's taken_damage signal to Main._on_player_taken_damage" (exact signal name and method name)
  - Test 7, Assertions: [main_node.total_damage == 20 after player.take_damage()], Instruction coverage: "Player.take_damage emits 20 damage" (exact value specified)
  - Test 8, Assertions: [damage_label.text == "Total Damage: 20"], Instruction coverage: "the label updates each time Player.take_damage emits 20 damage" (implies format "Total Damage: {value}")
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - "Total Damage: 0" and "Total Damage: 20" format is clear
    - [x] Exact string values/names are in instruction (not just "format text") - HUD, DamageLabel, Player, _on_player_taken_damage all specified
    - [x] Number formats (zero-padding, decimal places) are specified - "20 damage" specified, no padding needed for simple integers
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - Equality checks match exact values in instruction
    - [x] Node names, paths, and types match instruction exactly - All names (HUD, DamageLabel, Player) and types (CanvasLayer, Label, CharacterBody2D) specified
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - "Total Damage: 0", 20 damage value, signal/method names all exact
  - Ambiguous Tests: None. All test assertions have exact specifications in the instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: There is essentially one solution path clearly specified by the instruction. The instruction specifies exact node types, names, hierarchy (HUD under Main, DamageLabel under HUD), exact signal connection, exact string format, and exact damage value. The tests appropriately enforce this single clear solution.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0023)
  - Evidence: Follows standard structure - tasks/task_0023/ and tasks_gt/task_0023/ with scenes/ (containing main.tscn, test.tscn), scripts/ (containing .gd files), assets/, project.godot, and task_config.json. Naming convention task_{number}_{name} is consistent.
- [x] PROCEED. Check this box if the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Task focuses on creating nodes via the scene tree ("create a CanvasLayer named HUD with a Label called DamageLabel") and connecting signals through the inspector/scene editor ("connect the Player node's taken_damage signal to Main._on_player_taken_damage"). This is a no-scripting task emphasizing scene structure and signal connections.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: No multimodal reasoning required. Task can be completed with text-based instructions alone.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or multimodal inputs in the instruction.

# Notes

## Validation Summary
- **Task Type**: No-scripting signal connection task
- **Difficulty**: Easy (as specified in task_config.json)
- **Key Learning**: Demonstrates Godot signal system - emitting custom signals and connecting them between nodes
- **Tutorial Source**: YouTube - Cashew OldDew "Signals in Godot 4.3" (video_id: uQl0HC-2FNk)

## Code Analysis
The ground truth implementation correctly demonstrates:
1. **Signal definition**: `signal taken_damage` in character.gd:3
2. **Signal emission**: `taken_damage.emit(20)` in character.gd:8
3. **Signal connection**: Scene file line 40 connects Player.taken_damage -> Main._on_player_taken_damage
4. **Signal handler**: `_on_player_taken_damage(amount: int)` in main.gd:10-13 that updates both total_damage variable and UI label

## Starting Point vs Ground Truth
- Starting point has Player with take_damage() method and signal defined
- Starting point has Main._on_player_taken_damage() handler implemented
- Starting point is MISSING: HUD CanvasLayer, DamageLabel Label, and signal connection
- This creates appropriate difficulty - solver must create UI nodes and connect the signal

## Test Quality
All 8 test checks are well-designed:
- Incremental validation (node existence → types → properties → behavior)
- Clear error messages indicate what's missing
- Tests verify both structure (nodes, types, hierarchy) and behavior (signal emission, label update)
- No ambiguous assertions - all values explicitly specified in instruction

## Repository Note
No repository folder found at expected path, but code clearly follows tutorial transcript patterns. The task creator likely hand-crafted the code based on the video tutorial rather than copying from a GitHub repo.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0023/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0023/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0023/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0023/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0023/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
