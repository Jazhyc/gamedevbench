# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Manual inspection shows starting point is incomplete - scripts have empty pass statements, missing _ready() implementation, scene has incorrect collision layers (1,1 instead of 2,3), emission disabled, no script attached to ItemPickup, and no test_cube.tres resource file
- [ ] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: No ground truth folder exists for this task (tasks_gt/ folder does not exist)
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0024
  - Evidence: Both main.tscn and test.tscn exist in scenes/ folder (confirmed via file listing)
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "Author res://scripts/interactable_item.gd so it extends Node3D with class_name InteractableItem" / Transcript: "it's going to be of type node 3D as opposed to node and we're also going to go ahead and add a class name for interactable item"
  - Instruction 2: "exports a MeshInstance3D named item_highlight_mesh" / Transcript: "we're going to go ahead and add our export and this is going to be an item highlight mesh and this is be of type mesh instance 3D"
  - Instruction 3: "hides that mesh in _ready()" / Transcript: Not explicitly stated in transcript but implied by "we're just going to set the item highlight mesh to visible" in gain_focus
  - Instruction 4: "provides gain_focus() / lose_focus() methods that toggle its visibility" / Transcript: "we're going to create a new function that's going to be used to highlight the item and it's going to be called gain focus and we're just going to set the item highlight mesh to visible and then conversely we're also going to have a lose focus function"
  - Instruction 5: "Attach the script to the RigidBody3D in res://scenes/item_pickup.tscn" / Transcript: "let's drag in that interactable item. GD script on"
  - Instruction 6: "set its collision_layer to 2, collision_mask to 3" / Transcript: "let's put the Collision to layer two so that that way we can make the area 3D only sample against that layer"
  - Instruction 7: "assign MeshInstance3D/Highlight to the export" / Transcript: "we're going to select the Highlight mesh which in this case is just going to be the outline"
  - Instruction 8: "ensure the Highlight child stays hidden by default" / Transcript: "let's go ahead and disable that outline first"
  - Instruction 9: "using an emissive StandardMaterial3D for its outline" / Transcript: "let's create a new material for that and let set its emission to some very high value"
  - Instruction 10: "Create res://scripts/item_data.gd as a Resource with exported item_name (String) and item_model_prefab (PackedScene)" / Transcript: "this one's going to be called interactable item and interactable item mono.com data and this one's going to be of type Resource... we're going to add two new exports in they're going to be called item name and item model prefab one is going to be a string and that's just going to be the name of the item the other one's going to be the pack scene"
  - Instruction 11: "add res://resources/items/test_cube.tres using that script so it stores the name \"Test Cube\"" / Transcript: "we're going to call it test Cube... we can hit quickload and we now have our little test Cube here"
  - Instruction 12: "points item_model_prefab to res://scenes/item_pickup.tscn" / Transcript: "the prefab that the object will be referencing against"
  - Instruction 13: "Leave the ItemPickup instance in res://scenes/main.tscn" / Transcript: implicit from showing it in scene
  - Instructions Missing from Transcript: Specific collision_mask value of 3 is not in transcript (only layer 2 mentioned), hiding mesh in _ready() not explicitly stated
- [ ] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Repository exists at https://github.com/Bonkahe/Basic-Inventory-System-Godot4 but not cloned locally. Task structure appears to match tutorial workflow based on transcript analysis
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: Instruction contains all necessary details with exact paths, property values, node types, and relationships. No references to tutorial or other tasks
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1: Check ItemPickup is RigidBody3D / Instruction: "Attach the script to the RigidBody3D in res://scenes/item_pickup.tscn"
  - Test 2: Check collision_layer=2, collision_mask=3 / Instruction: "set its collision_layer to 2, collision_mask to 3"
  - Test 3: Check script is interactable_item.gd / Instruction: "Attach the script to the RigidBody3D"
  - Test 4: Check class_name InteractableItem / Instruction: "extends Node3D with class_name InteractableItem"
  - Test 5: Check item_highlight_mesh export assigned / Instruction: "assign MeshInstance3D/Highlight to the export"
  - Test 6: Check highlight hidden by default / Instruction: "ensure the Highlight child stays hidden by default"
  - Test 7: Check emissive StandardMaterial3D / Instruction: "using an emissive StandardMaterial3D for its outline"
  - Test 8: Check gain_focus shows mesh / Instruction: "gain_focus() / lose_focus() methods that toggle its visibility"
  - Test 9: Check lose_focus hides mesh / Instruction: "gain_focus() / lose_focus() methods that toggle its visibility"
  - Test 10: Check test_cube.tres is ItemData / Instruction: "add res://resources/items/test_cube.tres using that script"
  - Test 11: Check item_name = "Test Cube" / Instruction: "stores the name \"Test Cube\""
  - Test 12: Check item_model_prefab references scene / Instruction: "points item_model_prefab to res://scenes/item_pickup.tscn"
  - Missing Coverage: None, all tests match instructions
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1, Assertions: [pickup is RigidBody3D], Instruction coverage: "Attach the script to the RigidBody3D in res://scenes/item_pickup.tscn"
  - Test 2, Assertions: [collision_layer == 2, collision_mask == 3], Instruction coverage: "set its collision_layer to 2, collision_mask to 3"
  - Test 3, Assertions: [script path ends_with "interactable_item.gd"], Instruction coverage: "Author res://scripts/interactable_item.gd... Attach the script to the RigidBody3D"
  - Test 4, Assertions: [pickup is InteractableItem], Instruction coverage: "class_name InteractableItem"
  - Test 5, Assertions: [item_highlight_mesh != null], Instruction coverage: "assign MeshInstance3D/Highlight to the export"
  - Test 6, Assertions: [highlight.visible == false], Instruction coverage: "ensure the Highlight child stays hidden by default"
  - Test 7, Assertions: [material is StandardMaterial3D, emission_enabled == true], Instruction coverage: "using an emissive StandardMaterial3D for its outline"
  - Test 8, Assertions: [after gain_focus(), highlight.visible == true], Instruction coverage: "gain_focus() / lose_focus() methods that toggle its visibility"
  - Test 9, Assertions: [after lose_focus(), highlight.visible == false], Instruction coverage: "gain_focus() / lose_focus() methods that toggle its visibility"
  - Test 10, Assertions: [item_data is ItemData], Instruction coverage: "add res://resources/items/test_cube.tres using that script"
  - Test 11, Assertions: [item_name.strip_edges() == "Test Cube"], Instruction coverage: "stores the name \"Test Cube\""
  - Test 12, Assertions: [item_model_prefab.resource_path == "res://scenes/item_pickup.tscn"], Instruction coverage: "points item_model_prefab to res://scenes/item_pickup.tscn"
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction
    - [x] Exact string values/names are in instruction (not just "format text")
    - [x] Number formats (zero-padding, decimal places) are specified
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria
    - [x] Node names, paths, and types match instruction exactly
    - [x] Property values (numbers, booleans, strings) have exact values in instruction
  - Ambiguous Tests: None - all test assertions have corresponding exact specifications in the instruction
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: Single solution clearly defined. Tests check exact requirements: specific collision layers, exact paths, specific property values, and exact behaviors
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0024)
  - Evidence: Follows naming convention task_XXXX_description_name with scenes/, scripts/, project.godot, task_config.json structure
- [ ] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Task heavily involves scene tree manipulation (attaching scripts, setting node properties like collision_layer/mask, assigning exports through inspector, creating resource files)
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Requires understanding 3D scene hierarchy (RigidBody3D with MeshInstance3D children), visual properties (emission for highlight effect), and spatial relationships
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images provided in the instruction

# Notes

## Validation Summary
- Task: task_0024
- Tutorial: Bonkahe - Basic Inventory System [Part 1] - Godot 4.x
- Video ID: XLjCmdy8jdw

## Key Findings
1. **Starting Point Analysis**: The starting point is appropriately incomplete with:
   - Empty pass statements in gain_focus/lose_focus methods
   - Missing _ready() function to hide mesh
   - Incorrect collision layers (1,1 instead of 2,3)
   - Emission disabled in material
   - No script attached to ItemPickup
   - Missing test_cube.tres resource file

2. **Instruction Quality**: Instructions are comprehensive and unambiguous with exact specifications for:
   - File paths (res://scripts/interactable_item.gd, res://scenes/item_pickup.tscn)
   - Property values (collision_layer: 2, collision_mask: 3)
   - Node types (RigidBody3D, MeshInstance3D)
   - String values ("Test Cube")
   - Class names (InteractableItem, ItemData)

3. **Test Coverage**: All 12 test assertions have corresponding exact specifications in the instruction. No ambiguous tests found.

4. **Transcript Matching**: Instructions align well with transcript, with minor exceptions:
   - collision_mask value of 3 not explicitly stated in transcript (only layer 2 mentioned)
   - _ready() hiding behavior implied but not explicitly stated

5. **Issues**:
   - No ground truth folder exists (tasks_gt/ does not exist)
   - Cannot run automated validation due to Godot command not available
   - Repository not cloned locally for direct code comparison

## Recommendations
- Task appears well-designed with clear, unambiguous instructions
- Tests comprehensively cover all instruction requirements
- Consider adding explicit statement about collision_mask=3 in transcript or adjusting instruction to match transcript more closely
- Consider making hiding behavior in _ready() more explicit in either transcript or instruction

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0024/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0024/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0024/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0024/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0024/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
