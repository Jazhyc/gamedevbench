extends Node3D
class_name EnemyAIController

var did_place_on_mesh := false
var last_target : Node3D

func PlaceOnMesh():
	did_place_on_mesh = true

func SetNodeTarget(target: Node3D):
	last_target = target
