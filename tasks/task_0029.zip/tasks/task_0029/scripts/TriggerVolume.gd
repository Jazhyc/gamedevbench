extends Area3D
class_name TriggerVolume

func TriggerVolume_BodyEntered(_collided_body: Node3D) -> void:
	# TODO: Free the trigger once it fires so the spawn wave only happens once.
	pass
