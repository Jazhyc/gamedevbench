extends Node

func _ready():
	run_validation()

func run_validation():
	var steer_component = load("res://scripts/steer_component.gd").new()
	if not steer_component:
		return _fail("SteerComponent script missing")

	steer_component.debug_enabled = true
	steer_component.debug.clear()
	steer_component.steer(Vector2(16, -12), Vector2.ZERO, Vector2(64, -32), 120.0, 60.0)

	var debug_dict = steer_component.debug
	for key in ["velocity", "scaled_desired_velocity"]:
		if not debug_dict.has(key):
			return _fail("debug dictionary missing %s entry" % key)

	var script_text = FileAccess.get_file_as_string("res://scripts/steer_component.gd")
	var draw_block = _extract_draw_block(script_text)
	if draw_block.is_empty():
		return _fail("_draw function not found")

	if not _contains_call(draw_block, "draw_line", "Color.BLACK"):
		return _fail("Missing black velocity line")
	if not _contains_call(draw_block, "draw_line", "Color.RED"):
		return _fail("Missing red desired velocity line")
	if not _contains_call(draw_block, "draw_line", "Color.BLUE"):
		return _fail("Missing blue connector line")
	if not _contains_call(draw_block, "draw_circle", "Color.BLACK"):
		return _fail("Missing black velocity tip circle")
	if not _contains_call(draw_block, "draw_circle", "Color.RED"):
		return _fail("Missing red desired velocity tip circle")

	if draw_block.find("velocity") == -1:
		return _fail("Missing velocity usage in _draw")
	if draw_block.find("scaled_desired_velocity") == -1:
		return _fail("Missing scaled_desired_velocity usage in _draw")

	print("VALIDATION_PASSED: Steering gizmos are drawn with lines and circles")
	get_tree().quit()

func _extract_draw_block(text: String) -> String:
	var lines = text.split("\n")
	var in_draw = false
	var base_indent = 0
	var block: Array = []
	for line in lines:
		if not in_draw:
			if line.strip_edges().begins_with("func _draw"):
				in_draw = true
				base_indent = _indent_width(line)
			continue
		var stripped = line.strip_edges()
		if stripped.begins_with("func ") and _indent_width(line) <= base_indent:
			break
		if stripped.is_empty():
			continue
		block.append(stripped)
	return "\n".join(block)

func _indent_width(line: String) -> int:
	var trimmed = line.strip_edges(true, false)
	return line.length() - trimmed.length()

func _contains_call(block: String, call_name: String, color_name: String) -> bool:
	var lines = block.split("\n")
	for line in lines:
		if line.find(call_name) != -1 and line.find(color_name) != -1:
			return true
	return false

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
