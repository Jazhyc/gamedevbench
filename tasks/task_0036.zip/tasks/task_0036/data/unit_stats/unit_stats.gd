class_name UnitStats
extends Resource

@export var name: String
@export var traits: Array[Trait] = []
