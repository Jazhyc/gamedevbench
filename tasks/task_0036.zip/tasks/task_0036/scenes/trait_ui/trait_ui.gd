class_name TraitUI
extends PanelContainer

@export var trait_data: Trait : set = _set_trait_data
@export var active: bool : set = _set_active

@onready var trait_icon: TextureRect = %TraitIcon
@onready var active_units_label: Label = %ActiveUnitsLabel
@onready var trait_level_labels: RichTextLabel = %TraitLevelLabels
@onready var trait_label: Label = %TraitLabel


func update(_units: Array[Unit]) -> void:
	pass


func _set_trait_data(value: Trait) -> void:
	trait_data = value


func _set_active(value: bool) -> void:
	active = value
