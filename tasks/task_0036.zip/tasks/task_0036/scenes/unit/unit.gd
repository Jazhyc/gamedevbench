class_name Unit
extends Node2D

@export var stats: UnitStats
