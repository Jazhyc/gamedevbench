extends Node

const MAIN_SCENE := preload("res://scenes/main.tscn")
const TRAIT_SCENE := preload("res://scenes/trait_ui/trait_ui.tscn")
const UNIT_SCENE := preload("res://scenes/unit/unit.tscn")
const ELF_TRAIT := preload("res://data/traits/elf_trait.tres")
const ARCHER_STATS := preload("res://data/unit_stats/examples/elf_archer.tres")
const MARKSMAN_STATS := preload("res://data/unit_stats/examples/elf_marksman.tres")

func _ready():
	run_validation()

func report_fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func report_pass(message: String) -> void:
	print("VALIDATION_PASSED: %s" % message)
	get_tree().quit()

func run_validation() -> void:
	var main := MAIN_SCENE.instantiate()
	add_child(main)
	var trait_ui := main.get_node_or_null("TraitUI")
	if trait_ui == null:
		report_fail("Main.tscn must instance TraitUI as a direct child")
		return
	if trait_ui.get_script() == null:
		report_fail("TraitUI must have its script attached")
		return
	if trait_ui.get_script().resource_path != "res://scenes/trait_ui/trait_ui.gd":
		report_fail("TraitUI should use res://scenes/trait_ui/trait_ui.gd")
		return

	_validate_node_structure(trait_ui)
	_validate_trait_assignment(trait_ui)
	_validate_update_logic(trait_ui)

func _validate_node_structure(trait_ui: Control) -> void:
	var icon := trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/TraitIconBackground/TraitIcon")
	if icon == null or not (icon is TextureRect):
		report_fail("TraitIcon TextureRect missing from TraitUI")
		return
	var count_label := trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/VBoxContainer/ActiveUnitsLabel")
	if count_label == null or not (count_label is Label):
		report_fail("ActiveUnitsLabel missing from TraitUI")
		return
	var threshold_label := trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/VBoxContainer/TraitLevelLabels")
	if threshold_label == null or not (threshold_label is RichTextLabel):
		report_fail("TraitLevelLabels RichTextLabel missing")
		return
	if not threshold_label.bbcode_enabled:
		report_fail("TraitLevelLabels must enable BBCode")
		return
	var trait_name := trait_ui.get_node("MarginContainer/VBoxContainer/MarginContainer/TraitLabel")
	if trait_name == null or not (trait_name is Label):
		report_fail("TraitLabel missing from TraitUI")
		return

func _validate_trait_assignment(trait_ui: TraitUI) -> void:
	var TraitScript := preload("res://data/traits/trait.gd")
	var custom_trait: Trait = TraitScript.new()
	custom_trait.name = "Test Trait"
	custom_trait.icon = load("res://assets/sprites/traits/elf.png")
	custom_trait.levels = 1
	custom_trait.unit_requirements = [1]
	custom_trait.unit_modifiers = []
	trait_ui.trait_data = custom_trait
	var trait_label: Label = trait_ui.get_node("MarginContainer/VBoxContainer/MarginContainer/TraitLabel")
	var trait_icon: TextureRect = trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/TraitIconBackground/TraitIcon")
	if trait_label.text != "Test Trait":
		report_fail("Setting trait_data should update TraitLabel text")
		return
	if trait_icon.texture != custom_trait.icon:
		report_fail("Setting trait_data should update the trait icon texture")
		return

func _make_unit(stats_resource: Resource) -> Unit:
	var unit: Unit = UNIT_SCENE.instantiate()
	unit.stats = stats_resource.duplicate()
	return unit

func _validate_update_logic(trait_ui: TraitUI) -> void:
	trait_ui.trait_data = ELF_TRAIT
	trait_ui.active = false
	var units: Array[Unit] = []
	units.append(_make_unit(ARCHER_STATS))
	units.append(_make_unit(MARKSMAN_STATS))
	units.append(_make_unit(ARCHER_STATS))
	trait_ui.update(units)
	var count_label: Label = trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/VBoxContainer/ActiveUnitsLabel")
	if count_label.text != "2":
		report_fail("TraitUI.update must display unique unit count (expected 2)")
		return
	var threshold_label: RichTextLabel = trait_ui.get_node("MarginContainer/VBoxContainer/HBoxContainer/VBoxContainer/TraitLevelLabels")
	var expected_threshold := trait_ui.trait_data.get_levels_bbcode(2)
	if threshold_label.text != expected_threshold:
		report_fail("Trait level thresholds should match Trait.get_levels_bbcode")
		return
	if not is_equal_approx(trait_ui.modulate.a, 1.0):
		report_fail("TraitUI should fade in when enough units activate the trait")
		return
	trait_ui.update([])
	if not is_equal_approx(trait_ui.modulate.a, 0.5):
		report_fail("TraitUI should fade out (alpha=0.5) when inactive")
		return

	report_pass("Trait UI updates counts, thresholds, and highlights correctly")
