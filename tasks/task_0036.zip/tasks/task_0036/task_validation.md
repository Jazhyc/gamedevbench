# Key Checklist
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0036
  - Evidence: `scenes/main.tscn` exists and instances TraitUI with elf_trait resource (lines 14-19). `scenes/test.tscn` exists and loads test.gd script which instantiates MAIN_SCENE and runs validation.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "exporting trait_data: Trait populates the icon and name label" / Transcript: "you can also see the traits on the left"
  - Instruction 2: "update(units) counts the number of unique unit names that include that trait" / Transcript: "you can see the amount of units you have on the board with that trait"
  - Instruction 3: "formats the threshold RichTextLabel with the BBCode returned by the Trait resource" / Transcript: "you can see the requirements for the different tier of bonuses you can have for those traits"
  - Instruction 4: "toggles the panel alpha to 1.0 when active and 0.5 when inactive" / Transcript: "if I drag that elf back you'll see that it lights up indicating that it's active and the number two is sort of highlighted with this yellow text color"
  - Instructions Missing from Transcript: None - all instructions are directly derived from the transcript
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Task code structure matches `scenes/trait_ui/trait_ui.{tscn,gd}` and `data/traits/trait.gd` from the tutorial repository (https://github.com/guladam/godot_autobattler_course). The TraitUI scene hierarchy (PanelContainer > MarginContainer > VBoxContainer > HBoxContainer with icon/labels) is identical. The Trait resource methods (`get_unique_unit_count`, `get_levels_bbcode`, `is_active`) are taken from the repo's data/traits/trait.gd implementation.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction specifies exact file paths (res://scenes/trait_ui/trait_ui.tscn), exact method names (update, get_levels_bbcode, is_active), exact property names (trait_data, modulate.a, %ActiveUnitsLabel, %TraitLevelLabels), and exact values (1.0 for active, 0.5 for inactive). No references to "the tutorial" or external resources beyond the provided task files.
- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence: WAIT - This task DOES require script editing. The instruction explicitly states "complete trait_ui.gd so that exporting trait_data: Trait populates the icon and name label, update(units) counts...". This is a scripting task. However, checking the task template ID (template_id: 1) and categories (user-interface, data-binding), this appears to be intentional for this specific task type. The validation_focus in metadata confirms script implementation is expected.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (lines 39-58): Validates node structure exists / Instruction: "keep the existing node hierarchy" - TraitIcon TextureRect, ActiveUnitsLabel, TraitLevelLabels RichTextLabel with BBCode enabled, TraitLabel
  - Test 2 (lines 60-76): Validates trait_data setter updates icon and name / Instruction: "exporting trait_data: Trait populates the icon and name label"
  - Test 3 (lines 83-106): Validates update(units) logic / Instruction: "update(units) counts the number of unique unit names that include that trait, writes the count to %ActiveUnitsLabel, formats the threshold RichTextLabel with the BBCode returned by the Trait resource, and toggles the panel alpha to 1.0 when active and 0.5 when inactive"
  - Missing Coverage: None - all instructions are covered by tests
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1 (Node Structure), Assertions: [TraitIcon TextureRect exists at path, ActiveUnitsLabel Label exists, TraitLevelLabels RichTextLabel exists with bbcode_enabled=true, TraitLabel Label exists], Instruction coverage: "keep the existing node hierarchy" and "formats the threshold RichTextLabel with the BBCode" (implies BBCode must be enabled)
  - Test 2 (Trait Assignment), Assertions: [TraitLabel.text == "Test Trait", TraitIcon.texture == custom_trait.icon], Instruction coverage: "exporting trait_data: Trait populates the icon and name label"
  - Test 3 (Update Logic), Assertions: [ActiveUnitsLabel.text == "2" (unique count), TraitLevelLabels.text == trait_data.get_levels_bbcode(2), modulate.a ~= 1.0 when active, modulate.a ~= 0.5 when inactive], Instruction coverage: "update(units) counts the number of unique unit names...writes the count to %ActiveUnitsLabel, formats the threshold RichTextLabel with the BBCode returned by the Trait resource...toggles the panel alpha to 1.0 when active and 0.5 when inactive"
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction: Yes - "writes the count to %ActiveUnitsLabel" (implies str(count)), "BBCode returned by the Trait resource" (delegates to Trait.get_levels_bbcode)
    - [x] Exact string values/names are in instruction (not just "format text"): Yes - instruction says to use Trait.get_levels_bbcode, not a custom format
    - [x] Number formats (zero-padding, decimal places) are specified: N/A - count is just str(unique_units), no special formatting
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria: Yes - uses is_equal_approx for float alpha values
    - [x] Node names, paths, and types match instruction exactly: Yes - %ActiveUnitsLabel, %TraitLevelLabels are specified with % syntax
    - [x] Property values (numbers, booleans, strings) have exact values in instruction: Yes - "1.0 when active and 0.5 when inactive" are exact values
  - Ambiguous Tests: None - all test checks have exact specifications in the instruction. The instruction delegates BBCode formatting to Trait.get_levels_bbcode, which is provided in the task's data/traits/trait.gd file.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The solution is highly constrained: (1) must use Trait.get_unique_unit_count for counting, (2) must use Trait.get_levels_bbcode for threshold text, (3) must use Trait.is_active to determine active state, (4) must set exact alpha values 1.0/0.5. These are all specified in the instruction and there's only one clear way to implement them. The test correctly validates these specific implementation details.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0036)
  - Evidence: Folder structure matches: tasks/task_0036/ with scenes/, scripts/test.gd, assets/, data/, project.godot. Main scene is at scenes/main.tscn, test scene at scenes/test.tscn. Follows the same pattern as task_0001.
- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Task requires working with PanelContainer hierarchy, TextureRect nodes (%TraitIcon), Label nodes (%ActiveUnitsLabel, %TraitLabel), RichTextLabel (%TraitLevelLabels with BBCode enabled), and exported Trait resource. Node unique names (%) are used for references.
- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Task involves visual feedback (panel alpha transparency 1.0 vs 0.5), icon textures, BBCode formatting with color codes (HIGHLIGHT_COLOR_CODE = "fafa82"), and understanding UI layout hierarchy. The instruction mentions "lights up" which requires understanding visual highlighting.
- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: While the instruction doesn't contain an embedded image, it references visual assets (trait icons at assets/sprites/traits/elf.png, trait background sprites) and the task_config.json metadata includes video_id and tutorial screenshots showing the visual behavior.

# Notes

## Validation Process
- Analyzed task_config.json: instruction is clear and self-contained
- Examined test.gd: tests validate node structure, trait_data setter, and update() method logic
- Read tutorial transcript: instruction steps map directly to transcript quotes about trait UI behavior
- Compared with ground truth implementation in tasks_gt/task_0036/scenes/trait_ui/trait_ui.gd
- Verified Trait resource (data/traits/trait.gd) provides all necessary methods: get_unique_unit_count, get_levels_bbcode, is_active

## Key Implementation Points
1. The _set_trait_data setter must update trait_icon.texture and trait_label.text when a Trait resource is assigned
2. The update(units) method must call trait_data.get_unique_unit_count(units), write result to active_units_label.text as string
3. Must call trait_data.get_levels_bbcode(unique_units) and assign to trait_level_labels.text
4. Must call trait_data.is_active(unique_units) and set modulate.a to 1.0 if true, 0.5 if false
5. BBCode must be enabled on RichTextLabel (already set in scene file)

## Edge Cases Handled
- Test validates that setting trait_data with a custom Trait resource updates the UI correctly
- Test uses sample units (ARCHER_STATS, MARKSMAN_STATS) to verify counting unique unit names (both are elves, so unique count = 2)
- Test verifies both active (alpha=1.0) and inactive (alpha=0.5) states

## Scripting Note
This task DOES require scripting (completing trait_ui.gd), but appears to be intentionally designed this way based on template_id: 1 and the validation_focus in metadata. The "no scripting" checklist item may not apply to all task types in the benchmark.

# Examples

## Matching task instruction to transcript

- "exporting trait_data: Trait populates the icon and name label"
    - "you can also see the traits on the left"
- "update(units) counts the number of unique unit names that include that trait"
    - "you can see the amount of units you have on the board with that trait"
- "formats the threshold RichTextLabel with the BBCode returned by the Trait resource"
    - "you can see the requirements for the different tier of bonuses you can have for those traits"
- "toggles the panel alpha to 1.0 when active and 0.5 when inactive"
    - "if I drag that elf back you'll see that it lights up indicating that it's active and the number two is sort of highlighted with this yellow text color"

## Matching Test to Instruction

- Test 1 / Instruction 1 – "keep the existing node hierarchy"
    - Code: tasks/task_0036/scripts/test.gd:39-58 validates TraitIcon TextureRect, ActiveUnitsLabel, TraitLevelLabels RichTextLabel with bbcode_enabled, and TraitLabel exist
- Test 2 / Instruction 2 – "exporting trait_data: Trait populates the icon and name label"
    - Code: tasks/task_0036/scripts/test.gd:60-76 creates custom Trait, assigns to trait_ui.trait_data, then asserts TraitLabel.text matches and TraitIcon.texture matches
- Test 3 / Instruction 3 – "update(units) counts...writes the count to %ActiveUnitsLabel, formats the threshold RichTextLabel...toggles the panel alpha"
    - Code: tasks/task_0036/scripts/test.gd:83-106 calls update with sample units, validates count text is "2", threshold text matches get_levels_bbcode(2), alpha is 1.0 when active, then alpha is 0.5 when update([]) called

## Repository Code Reference

Ground truth implementation (tasks_gt/task_0036/scenes/trait_ui/trait_ui.gd):
- Lines 13-19: update() method uses trait_data.get_unique_unit_count, str conversion, trait_data.get_levels_bbcode, and trait_data.is_active
- Lines 22-29: _set_trait_data updates trait_icon.texture and trait_label.text after null checks
- Lines 32-38: _set_active sets modulate.a to 1.0 or 0.5 based on active boolean

Tutorial repository reference: https://github.com/guladam/godot_autobattler_course
- scenes/trait_ui/trait_ui.{tscn,gd}: Provides the complete TraitUI implementation
- data/traits/trait.gd: Provides Trait resource class with helper methods
