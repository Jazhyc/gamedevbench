class_name DragAndDrop
extends Node

signal dropped(starting_position: Vector2)

var dragging := false

func simulate_drop(_unit: Unit) -> void:
	dropped.emit(Vector2.ZERO)
