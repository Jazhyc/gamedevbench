class_name PlayerStats
extends Resource

@export var gold := 0
