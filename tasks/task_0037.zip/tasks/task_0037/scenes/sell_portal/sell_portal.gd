class_name SellPortal
extends Area2D

@export var unit_pool: UnitPool
@export var player_stats: PlayerStats
@export var sell_sound: AudioStream

@onready var outline_highlighter: OutlineHighlighter = $OutlineHighlighter
@onready var gold: HBoxContainer = %Gold
@onready var gold_label: Label = %GoldLabel
@onready var flip_sprite: FlipSprite = $FlipSprite

var current_unit: Unit


func _ready() -> void:
	pass


func _process(_delta: float) -> void:
	pass


func setup_unit(_unit: Unit) -> void:
	pass


func _sell_unit(_unit: Unit) -> void:
	pass


func _on_unit_dropped(_starting_position: Vector2, _unit: Unit) -> void:
	pass


func _on_area_entered(_unit: Unit) -> void:
	pass


func _on_area_exited(_unit: Unit) -> void:
	pass
