extends Node

const PORTAL_SCENE := preload("res://scenes/sell_portal/sell_portal.tscn")
const UNIT_SCENE := preload("res://scenes/unit/unit.tscn")
const ROGUE_STATS := preload("res://data/unit_stats/examples/rogue.tres")
const CHAMPION_STATS := preload("res://data/unit_stats/examples/champion.tres")

func _ready():
	run_validation()

func report_fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func report_pass(message: String) -> void:
	print("VALIDATION_PASSED: %s" % message)
	get_tree().quit()

func run_validation() -> void:
	var portal: SellPortal = PORTAL_SCENE.instantiate()
	add_child(portal)
	if portal.get_script() == null or portal.get_script().resource_path != "res://scenes/sell_portal/sell_portal.gd":
		report_fail("SellPortal.tscn must keep its script attached")
		return
	if not portal.is_connected("area_entered", Callable(portal, "_on_area_entered")):
		report_fail("SellPortal area_entered signal must connect to _on_area_entered")
		return
	if not portal.is_connected("area_exited", Callable(portal, "_on_area_exited")):
		report_fail("SellPortal area_exited signal must connect to _on_area_exited")
		return

	_validate_highlighter_behavior(portal)
	_validate_drop_and_sell_logic(portal)
	_validate_quick_sell(portal)

	report_pass("Sell portal previews gold, highlights, and sells units correctly")

func _make_unit(stats_resource: Resource) -> Unit:
	var unit: Unit = UNIT_SCENE.instantiate()
	add_child(unit)
	unit.stats = stats_resource.duplicate()
	return unit

func _validate_highlighter_behavior(portal: SellPortal) -> void:
	var unit := _make_unit(ROGUE_STATS)
	portal.setup_unit(unit)
	portal._on_area_entered(unit)
	if portal.current_unit != unit:
		report_fail("SellPortal should track the unit currently overlapping the portal")
		return
	var gold_container: HBoxContainer = portal.get_node("Gold")
	if not gold_container.visible:
		report_fail("Gold preview container must become visible on hover")
		return
	var gold_label: Label = portal.get_node("Gold/GoldLabel")
	if gold_label.text != str(unit.stats.get_gold_value()):
		report_fail("Gold label must show unit.stats.get_gold_value()")
		return
	var outline := portal.get_node("OutlineHighlighter") as OutlineHighlighter
	var line_value = outline.visuals.material.get_shader_parameter("line_thickness")
	if line_value <= 0.0:
		report_fail("OutlineHighlighter should raise line thickness while hovering")
		return
	unit.global_position = portal.global_position + Vector2(100, 0)
	portal._process(0.016)
	var sprite: Sprite2D = portal.get_node("Visuals/Sprite2D")
	if sprite.flip_h == false:
		report_fail("FlipSprite should face the hovered unit when processing")
		return
	portal._on_area_exited(unit)
	if portal.current_unit != null:
		report_fail("SellPortal should clear current_unit on exit")
		return
	if gold_container.visible:
		report_fail("Gold preview should hide when no unit overlaps")
		return
	line_value = outline.visuals.material.get_shader_parameter("line_thickness")
	if line_value != 0.0:
		report_fail("Outline should clear highlight after exit")
		return

func _validate_drop_and_sell_logic(portal: SellPortal) -> void:
	var unit := _make_unit(CHAMPION_STATS)
	portal.setup_unit(unit)
	var other := _make_unit(ROGUE_STATS)
	portal.setup_unit(other)
	portal._on_area_entered(unit)
	var starting_gold := portal.player_stats.gold
	other.simulate_drop()
	if portal.player_stats.gold != starting_gold:
		report_fail("Dropping a unit that is not hovering the portal must not change gold")
		return
	unit.simulate_drop()
	var expected_gain := unit.stats.get_gold_value()
	if portal.player_stats.gold != starting_gold + expected_gain:
		report_fail("Dropping the hovered unit should add its gold value to player_stats")
		return
	if portal.unit_pool.returned_units.size() == 0 or portal.unit_pool.returned_units[-1] != unit.stats:
		report_fail("SellPortal must push sold unit stats back into the unit pool")
		return
	if not unit.is_queued_for_deletion():
		report_fail("Sold units must queue_free()")
		return

func _validate_quick_sell(portal: SellPortal) -> void:
	var unit := _make_unit(ROGUE_STATS)
	portal.setup_unit(unit)
	var starting_gold := portal.player_stats.gold
	portal._on_area_entered(unit)
	unit.simulate_quick_sell()
	if portal.player_stats.gold != starting_gold + unit.stats.get_gold_value():
		report_fail("Quick sell should add the unit's gold value")
		return
	if portal.current_unit != null:
		report_fail("SellPortal should clear current_unit after quick selling")
		return
