extends Node3D

func _ready() -> void:
	# The day-night cycle system will be wired in by the solver.
	pass
