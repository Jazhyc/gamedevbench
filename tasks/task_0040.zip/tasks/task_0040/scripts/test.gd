extends Node

const ROTATION_TOLERANCE := 0.5
const COLOR_TOLERANCE := 0.05

func _ready() -> void:
	run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if not main:
		return fail("Main node missing")
	var sun = main.get_node_or_null("SunLight")
	if not (sun and sun is DirectionalLight3D):
		return fail("SunLight DirectionalLight3D missing")
	var porch = main.get_node_or_null("PorchLight")
	if not (porch and porch is OmniLight3D):
		return fail("PorchLight OmniLight3D missing")
	var label = main.get_node_or_null("ClockLabel")
	if not (label and label is Label):
		return fail("ClockLabel Label missing")
	var controller = main.get_node_or_null("DayNightCycle")
	if not controller:
		return fail("DayNightCycle node missing")
	if controller.get_script() == null or controller.get_script().resource_path.find("DayNightCycleNode.gd") == -1:
		return fail("DayNightCycle must use DayNightCycleNode.gd")
	if not validate_sampled_rotator(controller, sun):
		return
	if not validate_light_color(controller, sun):
		return
	if not validate_light_intensity(controller, sun):
		return
	if not validate_time_handler(controller):
		return
	if not validate_signal_and_script(main, controller, porch, label):
		return
	print("VALIDATION_PASSED")
	get_tree().quit()

func validate_sampled_rotator(controller: Node, sun: DirectionalLight3D) -> bool:
	var rotator = controller.get_node_or_null("SampledObjectRotator")
	if not rotator:
		fail("SampledObjectRotator child missing")
		return false
	if rotator.get_script() == null or rotator.get_script().resource_path.find("SampledObjectRotatorNode.gd") == -1:
		fail("SampledObjectRotator must use provided script")
		return false
	if rotator.target_node != sun:
		fail("SampledObjectRotator target_node must point to SunLight")
		return false
	var x_curve = rotator.x_rotation_curve
	if not x_curve:
		fail("SampledObjectRotator requires an X rotation curve")
		return false
	var zero = x_curve.sample_baked(0.0)
	var noon = x_curve.sample_baked(0.5)
	var one = x_curve.sample_baked(1.0)
	if abs(zero) > ROTATION_TOLERANCE:
		fail("Sun rotation curve must start near 0 degrees")
		return false
	if abs(noon - 180.0) > ROTATION_TOLERANCE:
		fail("Sun rotation curve must hit ~180 degrees at midday")
		return false
	if abs(one - 360.0) > ROTATION_TOLERANCE:
		fail("Sun rotation curve must wrap to 360 degrees")
		return false
	return true

func validate_light_color(controller: Node, sun: DirectionalLight3D) -> bool:
	var color_node = controller.get_node_or_null("LightColorTransition")
	if not color_node:
		fail("LightColorTransition child missing")
		return false
	if color_node.get_script() == null or color_node.get_script().resource_path.find("LightColorTransitionNode.gd") == -1:
		fail("LightColorTransition must use provided script")
		return false
	if color_node.light != sun:
		fail("LightColorTransition.light must target SunLight")
		return false
	var gradient = color_node.color_gradient
	if not gradient:
		fail("Color gradient not configured")
		return false
	var midnight = gradient.sample(0.0)
	var sunrise = gradient.sample(0.25)
	var midday = gradient.sample(0.5)
	var sunset = gradient.sample(0.75)
	var loop = gradient.sample(1.0)
	if not color_close(midnight, Color(0.05, 0.05, 0.08)):
		fail("Midnight gradient color must be dark")
		return false
	if not color_close(loop, Color(0.05, 0.05, 0.08)):
		fail("Gradient must loop back to dark at the end")
		return false
	if not color_close(midday, Color(0.98, 0.98, 0.94)):
		fail("Midday gradient color must be bright")
		return false
	if not color_close(sunrise, Color(0.97, 0.64, 0.28)):
		fail("Sunrise gradient color must be warm")
		return false
	if not color_close(sunset, Color(0.97, 0.64, 0.28)):
		fail("Sunset gradient color must be warm")
		return false
	return true

func validate_light_intensity(controller: Node, sun: DirectionalLight3D) -> bool:
	var intensity_node = controller.get_node_or_null("LightIntensityTransition")
	if not intensity_node:
		fail("LightIntensityTransition child missing")
		return false
	if intensity_node.get_script() == null or intensity_node.get_script().resource_path.find("LightIntensityTransitionNode.gd") == -1:
		fail("LightIntensityTransition must use provided script")
		return false
	if intensity_node.light != sun:
		fail("LightIntensityTransition.light must target SunLight")
		return false
	var curve = intensity_node.intensity_curve
	if not (curve and curve.get_point_count() >= 3):
		fail("Intensity curve must contain 3 control points")
		return false
	var night = curve.sample_baked(0.0)
	var midday = curve.sample_baked(0.5)
	var loop = curve.sample_baked(1.0)
	if night > 0.2:
		fail("Night intensity must stay low")
		return false
	if midday < 0.8:
		fail("Midday intensity must be significantly brighter")
		return false
	if loop > 0.2:
		fail("Intensity should fall back down by the end of the day")
		return false
	return true

func validate_time_handler(controller: Node) -> bool:
	var handler = controller.get_node_or_null("TimeHandler")
	if not handler:
		fail("TimeHandler child missing")
		return false
	if handler.get_script() == null or handler.get_script().resource_path.find("TimeHandler.gd") == -1:
		fail("TimeHandler must use provided script")
		return false
	if abs(handler.day_length_seconds - 10.0) > 0.01:
		fail("TimeHandler day length must be 10 seconds")
		return false
	if handler.display_interval_minutes != 10:
		fail("TimeHandler display interval must be 10 minutes")
		return false
	return true

func validate_signal_and_script(main: Node, controller: Node, porch: OmniLight3D, label: Label) -> bool:
	var callable = Callable(main, "_on_day_night_cycle_time_changed")
	if not controller.is_connected("time_changed", callable):
		fail("DayNightCycle.time_changed must be connected to Main._on_day_night_cycle_time_changed")
		return false
	if not main.has_method("_on_day_night_cycle_time_changed"):
		fail("Main script must implement _on_day_night_cycle_time_changed")
		return false
	main.call("_on_day_night_cycle_time_changed", "06:00")
	if porch.visible:
		fail("PorchLight should turn off at 06:00")
		return false
	if label.text != "06:00":
		fail("ClockLabel must show the emitted time")
		return false
	main.call("_on_day_night_cycle_time_changed", "18:00")
	if not porch.visible:
		fail("PorchLight should turn on at 18:00")
		return false
	if label.text != "18:00":
		fail("ClockLabel must update after second event")
		return false
	return true

func color_close(a: Color, b: Color) -> bool:
	var diff_r = abs(a.r - b.r)
	var diff_g = abs(a.g - b.g)
	var diff_b = abs(a.b - b.b)
	var diff_a = abs(a.a - b.a)
	return max(max(diff_r, diff_g), max(diff_b, diff_a)) <= COLOR_TOLERANCE
