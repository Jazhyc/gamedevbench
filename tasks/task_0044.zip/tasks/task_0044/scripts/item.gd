extends Resource
class_name Item

@export var texture: Texture2D = null
@export var quantity: int = 0
