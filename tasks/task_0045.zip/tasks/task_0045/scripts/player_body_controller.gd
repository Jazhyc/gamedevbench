extends CharacterBody3D

@export var animation_tree: AnimationTree
@export var hand_state_machine_playback_path: String = "parameters/playback"
@export var idle_animation_name: String = ""
@export var aiming_animation_name: String = ""
@export var idle_fire_animation_name: String = ""
@export var aiming_fire_animation_name: String = ""
@export var reload_animation_name: String = ""
@export var camera_node: Node3D
@export var arms_node: Node3D
@export var rotation_speed: float = 0.2
@export var camera_actual_rotation_speed: float = 10.0
@export var arms_actual_rotation_speed: float = 10.0
@export var vertical_rotation_limit: float = 60.0
@export var speed: float = 3.0
@export var jump_velocity: float = 4.0

var _hand_state_machine_playback: AnimationNodeStateMachinePlayback
var _target_rotation: Vector3 = Vector3.ZERO
var _is_aiming := false
var _gravity: float = float(ProjectSettings.get_setting("physics/3d/default_gravity"))

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if animation_tree:
		animation_tree.active = true
		if hand_state_machine_playback_path != "":
			_hand_state_machine_playback = animation_tree.get(hand_state_machine_playback_path) as AnimationNodeStateMachinePlayback

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		_target_rotation.x = clampf(_target_rotation.x - event.relative.y * rotation_speed, -vertical_rotation_limit, vertical_rotation_limit)
		_target_rotation.y = wrapf(_target_rotation.y - event.relative.x * rotation_speed, 0.0, 360.0)

	if event.is_action_pressed("escape"):
		_toggle_mouse_mode()

	if event.is_action_pressed("Aim"):
		_is_aiming = true
		_travel_to_animation(aiming_animation_name)
	elif event.is_action_released("Aim"):
		_is_aiming = false
		_travel_to_animation(idle_animation_name)

	if event.is_action_pressed("Fire"):
		if _is_aiming:
			_travel_to_animation(aiming_fire_animation_name)
		else:
			_travel_to_animation(idle_fire_animation_name)

	if event.is_action_pressed("Reload"):
		_is_aiming = false
		_travel_to_animation(reload_animation_name)

func _physics_process(delta: float) -> void:
	var vel := velocity
	if not is_on_floor():
		vel.y -= _gravity * delta
	if Input.is_action_just_pressed("Jump") and is_on_floor():
		vel.y = jump_velocity

	var input_dir := Input.get_vector("Move_left", "Move_right", "Move_up", "Move_down")
	var direction := Vector3(input_dir.x, 0.0, input_dir.y)
	if camera_node:
		direction = (camera_node.transform.basis * direction).normalized()
	if direction != Vector3.ZERO:
		vel.x = direction.x * speed
		vel.z = direction.z * speed
	else:
		vel.x = move_toward(vel.x, 0.0, speed)
		vel.z = move_toward(vel.z, 0.0, speed)

	velocity = vel
	move_and_slide()

	_update_node_rotation(camera_node, camera_actual_rotation_speed, delta)
	_update_node_rotation(arms_node, arms_actual_rotation_speed, delta)

func _update_node_rotation(target_node: Node3D, blend_speed: float, delta: float) -> void:
	if not target_node:
		return
	var weight := clampf(blend_speed * delta, 0.0, 1.0)
	var target_pitch := deg_to_rad(_target_rotation.x)
	var target_yaw := deg_to_rad(_target_rotation.y)
	target_node.rotation.x = lerp_angle(target_node.rotation.x, target_pitch, weight)
	target_node.rotation.y = lerp_angle(target_node.rotation.y, target_yaw, weight)
	target_node.rotation.z = 0.0

func _toggle_mouse_mode() -> void:
	if Input.mouse_mode == Input.MOUSE_MODE_VISIBLE:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	else:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _travel_to_animation(animation_name: String) -> void:
	if _hand_state_machine_playback and animation_name != "":
		_hand_state_machine_playback.travel(animation_name)
