extends Node

func _ready() -> void:
    _validate_setup()

func _fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func _validate_setup() -> void:
    var main = get_node_or_null("Main")
    if main == null:
        _fail("Main scene not instanced in test.tscn")
        return
    if not main is Node3D:
        _fail("Main scene root must be a Node3D")
        return

    var player = main.get_node_or_null("Player")
    if player == null:
        _fail("Player node not found")
        return
    if not player is CharacterBody3D:
        _fail("Player must be a CharacterBody3D")
        return

    if player.get_scene_file_path() != "res://addons/proto_controller/proto_controller.tscn":
        _fail("Player must instance the ProtoController scene")
        return

    if not player.can_sprint:
        _fail("ProtoController can_sprint must be enabled")
        return
    if not player.can_freefly:
        _fail("ProtoController can_freefly must be enabled")
        return

    var expected_inputs = {
        "input_left": "move_left",
        "input_right": "move_right",
        "input_forward": "move_up",
        "input_back": "move_down",
        "input_jump": "jump",
        "input_sprint": "sprint",
        "input_freefly": "freefly",
    }
    for property_name in expected_inputs.keys():
        var value = player.get(property_name)
        if value != expected_inputs[property_name]:
            _fail("%s should be set to '%s'" % [property_name, expected_inputs[property_name]])
            return

    var camera = player.get_node_or_null("Head/Camera3D")
    if camera == null:
        _fail("ProtoController must include Head/Camera3D")
        return
    if not camera.current:
        _fail("ProtoController Camera3D must be Current")
        return

    var expected_actions = {
        "move_left": Key.KEY_A,
        "move_right": Key.KEY_D,
        "move_up": Key.KEY_W,
        "move_down": Key.KEY_S,
        "jump": Key.KEY_SPACE,
        "sprint": Key.KEY_SHIFT,
        "freefly": Key.KEY_F,
    }
    for action in expected_actions.keys():
        if not InputMap.has_action(action):
            _fail("Input action '%s' is missing" % action)
            return
        var found = false
        for event in InputMap.action_get_events(action):
            if event is InputEventKey and event.physical_keycode == expected_actions[action]:
                found = true
                break
        if not found:
            _fail("Action '%s' is not bound to its expected key" % action)
            return

    print("VALIDATION_PASSED")
    get_tree().quit(0)
