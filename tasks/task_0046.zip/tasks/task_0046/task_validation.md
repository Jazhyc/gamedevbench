# Key Checklist
- [ ] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure
  - Evidence: Validation currently running (dependencies download in progress). Expected to fail because main.tscn does not have a Player node instanced.
- [ ] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: Pending validation run. Ground truth main.tscn (tasks_gt/task_0046/scenes/main.tscn:28-38) has Player node with all required properties configured.
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0046
  - Evidence: Both files exist in tasks/task_0046/scenes/ and tasks_gt/task_0046/scenes/
- [ ] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - **ISSUE**: Tutorial folder does not exist at the specified path "tutorials/Brackeys/How to make 3D Games in Godot". The transcript file cannot be located to verify instructions match.
  - Instruction excerpt in task_config.json: "11:11 – \"take the proto controller scene and drag it into a gray box level... I'll enable sprint and freefly... go under input actions and bind the appropriate keys... now I can move using the right keys, sprint, and toggle freefly.\""
  - This transcript excerpt suggests the instructions are likely accurate, but full transcript verification is not possible.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: ProtoController addon is from Brackeys' brackeys-proto-controller repository (https://github.com/Brackeys/brackeys-proto-controller).
  - The proto_controller.gd file (tasks/task_0046/addons/proto_controller/proto_controller.gd:1) has header "# ProtoController v1.0 by Brackeys"
  - Ground truth solution instances this addon: tasks_gt/task_0046/scenes/main.tscn:3,28-38
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: Instruction in task_config.json:4 is self-contained. It specifies exactly what to do: instance ProtoController, enable Sprint/Freefly, point input fields to custom actions, create Input Map bindings, and make camera Current.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (scripts/test.gd:11-24): Checks Main node exists, is Node3D, has Player node that is CharacterBody3D → Instruction: "Instance the ProtoController scene in Main as Player"
  - Test 2 (scripts/test.gd:27-29): Checks Player instances proto_controller.tscn → Instruction: "Instance the ProtoController scene (res://addons/proto_controller/proto_controller.tscn)"
  - Test 3 (scripts/test.gd:31-36): Checks can_sprint and can_freefly are enabled → Instruction: "enable Sprint and Freefly on the inspector"
  - Test 4 (scripts/test.gd:38-52): Checks all input_* properties match custom actions → Instruction: "point all of its input_* fields to custom actions named move_left/right/up/down, jump, sprint, and freefly"
  - Test 5 (scripts/test.gd:53-59): Checks Head/Camera3D exists and is Current → Instruction: "making sure the ProtoController camera is Current"
  - Test 6 (scripts/test.gd:61-82): Checks Input Map actions exist with correct key bindings → Instruction: "open Project Settings → Input Map and create those actions bound to A, D, W, S, Space, Shift, and F"
  - All instructions have corresponding tests. No missing coverage.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - For EACH test, list EVERY assertion/check it makes, then verify the instruction specifies that EXACT detail
  - Test 1, Assertions:
    - main exists and is not null
    - main is Node3D type
    - Player node exists under Main
    - Player is CharacterBody3D type
  - Instruction coverage: "Instance the ProtoController scene...in Main as Player" clearly specifies Player under Main. ProtoController is a CharacterBody3D (verified in proto_controller.tscn:16).
  - Test 2, Assertions:
    - Player.scene_file_path equals "res://addons/proto_controller/proto_controller.tscn"
  - Instruction coverage: "Instance the ProtoController scene (res://addons/proto_controller/proto_controller.tscn)" provides exact path.
  - Test 3, Assertions:
    - player.can_sprint is true
    - player.can_freefly is true
  - Instruction coverage: "enable Sprint and Freefly on the inspector" unambiguously specifies these two boolean properties must be true.
  - Test 4, Assertions:
    - player.input_left == "move_left"
    - player.input_right == "move_right"
    - player.input_forward == "move_up"
    - player.input_back == "move_down"
    - player.input_jump == "jump"
    - player.input_sprint == "sprint"
    - player.input_freefly == "freefly"
  - Instruction coverage: "point all of its input_* fields to custom actions named move_left/right/up/down, jump, sprint, and freefly" provides exact string values for each property.
  - Test 5, Assertions:
    - Head/Camera3D node exists under Player
    - camera.current is true
  - Instruction coverage: "making sure the ProtoController camera is Current" specifies camera must be Current. The ProtoController scene structure includes Head/Camera3D (proto_controller.tscn:36-40).
  - Test 6, Assertions:
    - InputMap.has_action("move_left") with Key.KEY_A
    - InputMap.has_action("move_right") with Key.KEY_D
    - InputMap.has_action("move_up") with Key.KEY_W
    - InputMap.has_action("move_down") with Key.KEY_S
    - InputMap.has_action("jump") with Key.KEY_SPACE
    - InputMap.has_action("sprint") with Key.KEY_SHIFT
    - InputMap.has_action("freefly") with Key.KEY_F
  - Instruction coverage: "open Project Settings → Input Map and create those actions bound to A, D, W, S, Space, Shift, and F so the exported fields match the bindings" provides exact key bindings for each action.
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction - All string values for actions are explicitly named
    - [x] Exact string values/names are in instruction (not just "format text") - "move_left/right/up/down, jump, sprint, and freefly" are explicit strings
    - [x] Number formats (zero-padding, decimal places) are specified - N/A, no number formatting required
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria - All tests use equality checks with values specified in instruction
    - [x] Node names, paths, and types match instruction exactly - "Main", "Player", "res://addons/proto_controller/proto_controller.tscn" all specified
    - [x] Property values (numbers, booleans, strings) have exact values in instruction - can_sprint=true, can_freefly=true, all input strings specified
  - Ambiguous Tests: None. All tests have exact specifications in the instruction.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: This task has one specific solution - instance the exact ProtoController scene at the exact path, configure exact properties with exact values, create exact Input Map actions with exact key bindings. The tests correctly enforce this single solution.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0046)
  - Evidence: Folder structure matches: tasks/task_0046/ and tasks_gt/task_0046/ both contain:
    - addons/ (for the ProtoController addon)
    - scenes/main.tscn
    - scenes/test.tscn
    - scripts/test.gd
    - project.godot
- [ ] PROCEED. Check this box is the task is validated and all key checks pass successfully.
  - **Pending**: Need to complete validation runs to verify tests execute correctly.
  - **Issue to address**: Tutorial transcript missing - cannot fully verify instruction-to-transcript mapping.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Instruction explicitly mentions "enable Sprint and Freefly on the inspector" and "point all of its input_* fields to custom actions" which are inspector/property operations.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: Task does not require multimodal reasoning. It's primarily text-based configuration of properties and Input Map settings.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or multimodal content in the instruction.

# Notes

## Tutorial Folder Issue
The task_config.json specifies tutorial_folder: "tutorials/Brackeys/How to make 3D Games in Godot" but this folder does not exist in the repository. The tutorials/ directory only contains Annie/, Bacon and Games/, and Bonkahe/ subfolders. This prevents full verification of the instruction-to-transcript mapping requirement.

## Validation Status
- Starting point validation: In progress (dependencies downloading)
- Ground truth validation: Pending
- Need to complete these validations to finalize the checklist

## Code Analysis Summary
The task is well-structured with clear instructions that map directly to testable conditions:
1. ProtoController addon is properly included in addons/proto_controller/
2. Ground truth shows correct implementation in main.tscn with Player node and all properties configured
3. project.godot in ground truth has all Input Map actions with correct key bindings
4. Tests comprehensively check all requirements without ambiguity

## Key Files Analyzed
- tasks/task_0046/task_config.json
- tasks/task_0046/scripts/test.gd
- tasks/task_0046/scenes/main.tscn
- tasks/task_0046/addons/proto_controller/proto_controller.gd
- tasks/task_0046/addons/proto_controller/proto_controller.tscn
- tasks_gt/task_0046/scenes/main.tscn
- tasks_gt/task_0046/project.godot
