extends Node

const CAR_SCENE := "res://scenes/car.tscn"
const TEXTURE_TOKEN := "spritesheet_vehicles.png"
const REGION := Rect2(291, 0, 70, 133)
const COLLIDER_RADIUS := 34.0
const COLLIDER_HEIGHT := 138.0
const CAMERA_ZOOM := Vector2(0.5, 0.5)
const ROT_TOL := 0.01
const FLOAT_TOL := 0.25

func _ready() -> void:
    await get_tree().process_frame
    run_validation()

func run_validation() -> void:
    var car_scene: PackedScene = load(CAR_SCENE)
    if car_scene == null:
        return _fail("VALIDATION_FAILED: %s is missing" % CAR_SCENE)
    var car = car_scene.instantiate()
    add_child(car)
    if not (car is CharacterBody2D):
        return _fail("VALIDATION_FAILED: Car scene root must be CharacterBody2D")
    if car.name != "Car":
        return _fail("VALIDATION_FAILED: Root node must be named 'Car'")

    var sprite := car.get_node_or_null("Sprite2D")
    if sprite == null:
        return _fail("VALIDATION_FAILED: Add a Sprite2D child named Sprite2D")
    if sprite.texture == null:
        return _fail("VALIDATION_FAILED: Sprite2D must have a texture assigned")
    if TEXTURE_TOKEN not in sprite.texture.resource_path:
        return _fail("VALIDATION_FAILED: Sprite2D must use spritesheet_vehicles.png")
    if not sprite.region_enabled:
        return _fail("VALIDATION_FAILED: Enable region on the Sprite2D")
    if sprite.region_rect != REGION:
        return _fail("VALIDATION_FAILED: Sprite2D region_rect must be %s" % REGION)
    if abs(fmod(sprite.rotation, TAU) - PI / 2.0) > ROT_TOL:
        return _fail("VALIDATION_FAILED: Sprite2D must be rotated 90 degrees to face forward")

    var collider := car.get_node_or_null("CollisionShape2D")
    if collider == null:
        return _fail("VALIDATION_FAILED: CollisionShape2D child is missing")
    if not (collider.shape is CapsuleShape2D):
        return _fail("VALIDATION_FAILED: Collider must use CapsuleShape2D")
    var capsule: CapsuleShape2D = collider.shape
    if abs(capsule.radius - COLLIDER_RADIUS) > FLOAT_TOL:
        return _fail("VALIDATION_FAILED: Capsule radius must be %.1f" % COLLIDER_RADIUS)
    if abs(capsule.height - COLLIDER_HEIGHT) > FLOAT_TOL:
        return _fail("VALIDATION_FAILED: Capsule height must be %.1f" % COLLIDER_HEIGHT)
    if abs(fmod(collider.rotation, TAU) - PI / 2.0) > ROT_TOL:
        return _fail("VALIDATION_FAILED: Collider must be rotated 90 degrees to align with the car body")

    var camera := car.get_node_or_null("Camera2D")
    if camera == null:
        return _fail("VALIDATION_FAILED: Camera2D child is required")
    if camera.zoom.distance_to(CAMERA_ZOOM) > FLOAT_TOL:
        return _fail("VALIDATION_FAILED: Camera zoom must be %s" % CAMERA_ZOOM)

    print("VALIDATION_PASSED: Car scene hierarchy matches tutorial setup")
    get_tree().quit(0)

func _fail(message: String) -> void:
    print(message)
    get_tree().quit(1)
