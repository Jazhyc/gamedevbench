extends Node

const ICON_PATH := "res://assets/icons/energy-arrow.png"
const FONT_PATH := "res://button_timer_font.tres"
const SWEEP_COLOR := Color(0.145098, 0.145098, 0.145098, 0.87451)

func _ready():
	await get_tree().process_frame
	_run_validation()

func _run_validation():
	var button := get_node_or_null("Main/AbilityButton")
	if not button or not button is TextureButton:
		return _fail("Main must instance a TextureButton named AbilityButton")
	if button.texture_normal == null or button.texture_normal.resource_path != ICON_PATH:
		return _fail("AbilityButton.texture_normal must use %s" % ICON_PATH)

	var sweep := button.get_node_or_null("Sweep")
	if not sweep or not sweep is TextureProgressBar:
		return _fail("Missing TextureProgressBar child named Sweep")
	if sweep.anchor_right != 1.0 or sweep.anchor_bottom != 1.0:
		return _fail("Sweep must fill the entire button using anchors 1,1")
	if sweep.fill_mode != TextureProgressBar.FILL_COUNTER_CLOCKWISE:
		return _fail("Sweep.fill_mode must be Counter Clockwise")
	if sweep.modulate != SWEEP_COLOR:
		return _fail("Sweep.modulate must be a dark translucent gray")

	var timer := button.get_node_or_null("Timer")
	if not timer or not timer is Timer:
		return _fail("Timer child is missing")
	if not timer.one_shot:
		return _fail("Timer must be configured as One Shot")

	var counter := button.get_node_or_null("Counter")
	if not counter or not counter is MarginContainer:
		return _fail("Counter MarginContainer child missing")
	if counter.anchor_top != 1.0 or counter.anchor_bottom != 1.0 or counter.anchor_right != 1.0:
		return _fail("Counter must be anchored along the button bottom edge")
	if counter.offset_top != -19.0:
		return _fail("Counter.offset_top must lift the label strip 19px above bottom")
	if not counter.has_theme_constant("margin_left") or counter.get_theme_constant("margin_left") != 5:
		return _fail("Counter left margin must be 5")
	if not counter.has_theme_constant("margin_right") or counter.get_theme_constant("margin_right") != 5:
		return _fail("Counter margins must be set to 5")
	if counter.mouse_filter != Control.MOUSE_FILTER_IGNORE:
		return _fail("Counter mouse filter must ignore input")

	var value_label := counter.get_node_or_null("Value")
	if not value_label or not value_label is Label:
		return _fail("Value Label child missing")
	var font = value_label.get_theme_font("font")
	if not font or font.resource_path != FONT_PATH:
		return _fail("Value label must use button_timer_font.tres")
	if value_label.get_theme_constant("outline_size") != 1:
		return _fail("Value label outline size must be 1")
	if value_label.get_theme_color("font_outline_color") != Color(0, 0, 0, 1):
		return _fail("Value label outline color must be opaque black")
	if not value_label.clip_text:
		return _fail("Value label must clip text")
	if value_label.horizontal_alignment != HORIZONTAL_ALIGNMENT_RIGHT:
		return _fail("Value label must right-align text")
	if value_label.text.strip_edges() != "0.0":
		return _fail("Value label text should default to 0.0")

	print("VALIDATION_PASSED: Ability button UI hierarchy configured")
	get_tree().quit()

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
