extends Area2D
class_name Crate

# TODO: emit a removed signal and expose minimap_icon once hooked up to minimap
