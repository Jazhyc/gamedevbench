extends CharacterBody2D
class_name Mob

# TODO: add minimap_icon + removed signal and movement logic
