extends Node2D

func _ready():
	pass # TODO: wire removed signals and minimap player reference
