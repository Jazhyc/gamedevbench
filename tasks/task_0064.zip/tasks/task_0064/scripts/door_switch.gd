extends Area2D

class_name DoorSwitch

var switch_pressed := false
