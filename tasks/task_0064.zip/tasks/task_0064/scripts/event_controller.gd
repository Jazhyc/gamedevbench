extends Node

# TODO: emit exit_switch_flipped once the door switch animation finishes.
