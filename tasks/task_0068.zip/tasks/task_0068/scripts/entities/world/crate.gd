extends Node2D
class_name Crate

func destroy():
    pass