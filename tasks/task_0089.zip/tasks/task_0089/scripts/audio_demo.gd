extends MarginContainer

@export_dir var sound_dir := "res://assets"

# TODO: Populate buttons from an audio directory and hook them to the AudioManager as described in the instructions.

func _ready() -> void:
	pass


func add_button(_file_name: String) -> void:
	pass


func on_audio_button_pressed(_button: Button) -> void:
	pass


func _process(_delta: float) -> void:
	pass
