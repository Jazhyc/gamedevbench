extends CharacterBody2D

const SPEED = 100.0
const JUMP_VELOCITY = -300.0
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
@onready var animated_sprite_2d = $AnimatedSprite2D

func _physics_process(delta):
	# TODO: slice the sprite sheet into animations and drive run/idle switching.
	if not is_on_floor():
		velocity.y += gravity * delta
