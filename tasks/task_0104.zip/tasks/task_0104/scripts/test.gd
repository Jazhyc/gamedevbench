extends Node

func _ready():
	run_validation()

func fail(msg: String) -> void:
	print("VALIDATION_FAILED: %s" % msg)
	get_tree().quit(1)

func approx_equal(a: Vector2, b: Vector2, tolerance := 0.01) -> bool:
	return a.distance_to(b) <= tolerance

func find_character_body(root: Node) -> CharacterBody2D:
	if root is CharacterBody2D:
		return root
	for child in root.get_children():
		var found := find_character_body(child)
		if found != null:
			return found
	return null

func get_atlas_from_frames(frames: SpriteFrames, anim_name: String) -> Texture2D:
	for i in range(frames.get_frame_count(anim_name)):
		var tex = frames.get_frame_texture(anim_name, i)
		if tex != null and tex is AtlasTexture and tex.atlas != null:
			return tex.atlas
	return null

func check_default_frames(frames: SpriteFrames, atlas: Texture2D, cell_size: Vector2) -> void:
	if frames.get_frame_count("default") != 4:
		fail("default animation must have 4 frames")
	for i in range(4):
		var tex = frames.get_frame_texture("default", i)
		if tex == null or not (tex is AtlasTexture):
			fail("default frame %d must be an AtlasTexture" % i)
		if tex.atlas != atlas:
			fail("default frame %d must use the same atlas" % i)
		var rect: Rect2 = tex.region
		var expected_pos = Vector2(cell_size.x * i, 0.0)
		if not approx_equal(rect.size, cell_size):
			fail("default frame %d region size mismatch" % i)
		if not approx_equal(rect.position, expected_pos):
			fail("default frame %d region position mismatch" % i)

func check_run_frames(frames: SpriteFrames, atlas: Texture2D, cell_size: Vector2) -> void:
	if frames.get_frame_count("run") != 6:
		fail("run animation must have 6 frames")
	for i in range(frames.get_frame_count("run")):
		var tex = frames.get_frame_texture("run", i)
		if tex == null or not (tex is AtlasTexture):
			fail("run frame %d must be an AtlasTexture" % i)
		if tex.atlas != atlas:
			fail("run frame %d must use the same atlas" % i)
		var rect: Rect2 = tex.region
		if not approx_equal(rect.size, cell_size):
			fail("run frame %d region size mismatch" % i)
		if abs(rect.position.y) > 0.01:
			fail("run frame %d should be on the top row" % i)

func run_validation() -> void:
	var dino = find_character_body(self)
	if dino == null:
		fail("CharacterBody2D missing")

	var anim: AnimatedSprite2D = null
	for child in dino.get_children():
		if child is AnimatedSprite2D:
			anim = child
			break
	if anim == null:
		fail("AnimatedSprite2D missing under CharacterBody2D")
	if anim.sprite_frames == null:
		fail("SpriteFrames missing on AnimatedSprite2D")

	var frames: SpriteFrames = anim.sprite_frames
	if not frames.has_animation("default"):
		fail("SpriteFrames missing default animation")
	if not frames.has_animation("run"):
		fail("SpriteFrames missing run animation")

	var atlas := get_atlas_from_frames(frames, "default")
	if atlas == null:
		fail("default animation frames must use an atlas texture")
	var atlas_size := atlas.get_size()
	if atlas_size.x <= 0.0 or atlas_size.y <= 0.0:
		fail("Atlas texture size invalid")

	var cell_size := Vector2(atlas_size.x / 24.0, atlas_size.y)
	check_default_frames(frames, atlas, cell_size)
	check_run_frames(frames, atlas, cell_size)

	var player_script = dino.get_script()
	if player_script == null:
		fail("Movement script missing")
	var code := ""
	if player_script is GDScript:
		code = player_script.source_code
	if code.find("play(\"run\"") == -1 or code.find("play(\"default\"") == -1:
		fail("Script should play run/default animations based on input")
	if code.find("flip_h") == -1:
		fail("Script should flip sprite horizontally")

	print("VALIDATION_PASSED: Sprite sheet animation configured")
	get_tree().quit(0)
