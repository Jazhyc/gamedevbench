# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure 
  - Evidence: `uv run gamedevbench validate task_0105` -> FAILED "default_bus_layout.tres not found".
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: `uv run gamedevbench --gt validate task_0105` -> PASSED "Audio players configured."
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0105
  - Evidence: `tasks/task_0105/scenes/main.tscn` and `tasks/task_0105/scenes/test.tscn`.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "Create `res://default_bus_layout.tres` with Music and SFX buses (set `bus/1/name` to `&\"Music\"` and `bus/2/name` to `&\"SFX\"`)."
    - Transcript: "set up different audio buses for the music and the sound effects ... rename it to something like music ... rename this one to something like sound effects or I just type in s effects with all caps"
  - Instruction 2: "Add `res://scenes/audio_player/audio_player.gd` with `play()` and `stop()` methods that operate on child `AudioStreamPlayer` nodes."
    - Transcript: "create a new script ... audio player.gd ... we have two methods here one is called play ... then we have the stop method ... child nodes will be audio stream players"
  - Instruction 3: "Create `res://scenes/audio_player/music_player.tscn` with a root node named `MusicPlayer` that uses `audio_player.gd` and has exactly four `AudioStreamPlayer` children, each with the bus set to \"Music\"."
    - Transcript: "rename this to music player ... add audio stream player ... change the bus from Master to music ... let's say we can have four simultaneous music tracks"
  - Instruction 4: "Create `res://scenes/audio_player/sfx_player.tscn` with a root node named `SFXPlayer` that uses `audio_player.gd` and has exactly sixteen `AudioStreamPlayer` children, each with the bus set to \"SFX\"."
    - Transcript: "rename this from music player to sfx player ... let's say we can have 16 ... change the bus from music to sfx"
  - Instruction 5: "Register autoloads in `project.godot` as `MusicPlayer=\"*res://scenes/audio_player/music_player.tscn\"` and `SFXPlayer=\"*res://scenes/audio_player/sfx_player.tscn\"`."
    - Transcript: "autoload tab ... music player is fine ... sfx player click on ADD"
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: `tasks_gt/task_0105/scenes/audio_player/audio_player.gd` matches `tutorials/GodotGameLab/Godot 4 Autobattler Tutorial_ Music and Sound Effects (S1 FINALE)/repo/scenes/audio_player/audio_player.gd`; `tasks_gt/task_0105/scenes/audio_player/music_player.tscn` and `tasks_gt/task_0105/scenes/audio_player/sfx_player.tscn` match repo equivalents; `tasks_gt/task_0105/default_bus_layout.tres` matches repo `default_bus_layout.tres`.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: `task_config.json` specifies exact file paths, node names, bus names, counts, and autoload entries.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (_validate_bus_layout), Instruction 1: checks `res://default_bus_layout.tres` and `bus/1`/`bus/2` names; instruction specifies both file path and bus indices.
  - Test 2 (_validate_autoloads), Instruction 5: checks exact autoload paths `res://scenes/audio_player/music_player.tscn` and `res://scenes/audio_player/sfx_player.tscn`; instruction specifies both entries.
  - Test 3 (_validate_audio_script), Instruction 2: checks script at `res://scenes/audio_player/audio_player.gd`; instruction specifies path and required methods.
  - Test 4 (_validate_player_scene music), Instruction 3: checks scene path, root node name, script path, exact count 4, bus name Music; instruction specifies all details.
  - Test 5 (_validate_player_scene sfx), Instruction 4: checks scene path, root node name, script path, exact count 16, bus name SFX; instruction specifies all details.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1, Assertions: `res://default_bus_layout.tres` exists; contains `bus/1/name = &"Music"`; contains `bus/2/name = &"SFX"`. Instruction coverage: explicit file name and bus indices.
  - Test 2, Assertions: project has autoload `MusicPlayer="*res://scenes/audio_player/music_player.tscn"`; autoload `SFXPlayer="*res://scenes/audio_player/sfx_player.tscn"`. Instruction coverage: exact autoload entries.
  - Test 3, Assertions: `res://scenes/audio_player/audio_player.gd` exists; contains `func play`; contains `func stop`. Instruction coverage: exact script path and method requirements.
  - Test 4, Assertions: `res://scenes/audio_player/music_player.tscn` exists; root name `MusicPlayer`; root uses `res://scenes/audio_player/audio_player.gd`; exactly 4 AudioStreamPlayer children; each child bus == "Music". Instruction coverage: all values and paths specified.
  - Test 5, Assertions: `res://scenes/audio_player/sfx_player.tscn` exists; root name `SFXPlayer`; root uses `res://scenes/audio_player/audio_player.gd`; exactly 16 AudioStreamPlayer children; each child bus == "SFX". Instruction coverage: all values and paths specified.
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction: bus names explicitly require `&"..."` StringName format.
    - [x] Exact string values/names are in instruction (not just "format text"): bus names, scene paths, and root names are specified.
    - [x] Number formats (zero-padding, decimal places) are specified: N/A (no number formatting checks in tests).
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria: exact string matches are specified.
    - [x] Node names, paths, and types match instruction exactly: all specified.
    - [x] Property values (numbers, booleans, strings) have exact values in instruction: all specified.
  - Ambiguous Tests: none.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: This task defines a single, specific solution with fixed paths and names that are explicitly stated in the instructions.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0105)
  - Evidence: standard `scenes/`, `scripts/`, `project.godot`, and `task_config.json` present in `tasks/task_0105`.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused. 
  - Evidence: instructions require creating audio buses and scenes with AudioStreamPlayer children and autoloads.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: no multimodal reasoning required.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: no image or other multimodal input in instruction.

# Notes
- Validation: start FAIL "default_bus_layout.tres not found"; GT PASS "Audio players configured."
- Instructions now specify fixed paths, names, and counts used by tests.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0105/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0105/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0105/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0105/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0105/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
