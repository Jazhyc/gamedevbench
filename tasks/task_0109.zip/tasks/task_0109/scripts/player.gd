extends CharacterBody2D

func on_action_complete() -> void:
	pass
