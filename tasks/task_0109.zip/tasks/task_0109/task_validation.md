# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure 
  - Evidence: `uv run gamedevbench validate task_0109` reports `Validation result: FAILED` with `Message: Missing hurt animation`.
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: `uv run gamedevbench --gt validate task_0109` reports `Validation result: PASSED` with `Message: Player hurt/fall/grounded animations are configured`.
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0109
  - Evidence: `tasks/task_0109/scenes/main.tscn` and `tasks/task_0109/scenes/test.tscn` both exist and load `Main` in `test.tscn`.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction: "create a new animation ... this animation is going to be three frames long ... mark this as 0.3 and have it a snap as 0.1 ... go to frame 70 and add three key frames ... right click insert key ... on action complete"
    - Transcript: "create a new animation ... this animation is going to be three frames long so we'll mark this as 0.3 and have it a snap as 0.1 ... go to frame 70 and add three key frames ... right click insert key ... on action complete"
  - Instruction: "create a new animation ... fall ... single frame animation ... 0.1 ... it does loop ... select frame 80 insert a key frame"
    - Transcript: "create a new animation let's call it fall this is a single frame animation we'll make this 0.1 it does loop go ahead and select frame 80 insert a key frame"
  - Instruction: "create a new animation ... grounded ... frame 82 ... insert a key frame"
    - Transcript: "new animation name is grounded frame 82 okay insert a key frame"
  - Instruction: "keyframe CharacterSprite and KnifeSprite to frames 70, 71, 72 ... frame 80 ... frame 82"
    - Transcript: "we'll go through the exercise of going through every single animation one by one and just setting the exact same frame that has been set on the player ... for example the fall is frame 80 ... this is 82 ... do this for every single animation"
  - Instructions Missing from Transcript: None.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: Player animation definitions in `tutorials/The GameDev Tavern/Create a Beat 'em up game in Godot! (Part 07_20_ Getting Hurt)/repo/scenes/characters/player.tscn` (hurt/fall/grounded animations and frame values) match the ground-truth scene in `tasks_gt/task_0109/scenes/main.tscn`.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: The instruction now specifies looping 0.1s animations for `fall` and `grounded`, and the tests only require looping plus 0.1s length.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (hurt), Instruction 1: animation name `hurt`, length 0.3, step 0.1, CharacterSprite/KnifeSprite frames 70,71,72 at 0.0/0.1/0.2, and method track calling `on_action_complete` at 0.3s.
  - Test 2 (fall), Instruction 2: animation name `fall`, length 0.1, looping, CharacterSprite/KnifeSprite frame 80 at 0.0.
  - Test 3 (grounded), Instruction 3: animation name `grounded`, length 0.1, looping, CharacterSprite/KnifeSprite frame 82 at 0.0.
  - Coverage: Tests require looping for `fall` and `grounded` and a 0.1s length, matching the instruction.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1, Assertions: animation `hurt` exists; `length == 0.3`; `step == 0.1`; value track `CharacterSprite:frame` times [0.0, 0.1, 0.2] with values [70, 71, 72]; value track `KnifeSprite:frame` times [0.0, 0.1, 0.2] with values [70, 71, 72]; method track exists with 1 key at time 0.3 calling `on_action_complete`. Instruction coverage: "add three AnimationPlayer animations named hurt, fall, and grounded" + "Set hurt to 0.3s with 0.1s steps" + "keyframe CharacterSprite and KnifeSprite to frames 70, 71, and 72" + "add a method track that calls on_action_complete at 0.3s."
  - Test 2, Assertions: animation `fall` exists; `length == 0.1`; looping enabled; value track `CharacterSprite:frame` time [0.0] value [80]; value track `KnifeSprite:frame` time [0.0] value [80]. Instruction coverage: "Set fall to a looping 0.1s animation with CharacterSprite and KnifeSprite on frame 80."
  - Test 3, Assertions: animation `grounded` exists; `length == 0.1`; looping enabled; value track `CharacterSprite:frame` time [0.0] value [82]; value track `KnifeSprite:frame` time [0.0] value [82]. Instruction coverage: "Set grounded to a looping 0.1s animation with CharacterSprite and KnifeSprite on frame 82."
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction
    - [x] Exact string values/names are in instruction (not just "format text")
    - [x] Number formats (zero-padding, decimal places) are specified
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria
    - [x] Node names, paths, and types match instruction exactly
    - [x] Property values (numbers, booleans, strings) have exact values in instruction
  - Ambiguous Tests: None.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: The instruction specifies exact animation names, lengths, frames, and callback, so the solution is effectively unique.
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0109)
  - Evidence: Uses `scenes/main.tscn`, `scenes/test.tscn`, `scripts/test.gd`, and `task_config.json` in standard locations.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused. 
  - Evidence: Instruction requires configuring AnimationPlayer animations and Sprite2D frame tracks in the Player scene.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: The task is fully text-based and does not require interpreting images or visuals.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or other multimodal inputs are included.

# Notes

Additional notes:
- `scripts/test.gd` looks for the AnimationPlayer under `Main/Player/AnimationPlayer` and verifies value tracks for both `CharacterSprite:frame` and `KnifeSprite:frame`.
- The task starting scene in `tasks/task_0109/scenes/main.tscn` lacks the three animations (expected for the starting point).

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0109/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0109/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0109/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0109/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0109/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
