extends Node

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func run_validation() -> void:
    var main_node = get_node_or_null("Main")
    if main_node == null:
        fail("Main scene not found")
        return

    var visuals = main_node.get_node_or_null("Visuals")
    if visuals == null or not (visuals is Node2D):
        fail("Visuals node missing or incorrect type")
        return

    var background = visuals.get_node_or_null("Background")
    var props = visuals.get_node_or_null("Props")
    var walls = visuals.get_node_or_null("Walls")
    if background == null or not (background is TileMapLayer):
        fail("Background TileMapLayer missing")
        return
    if props == null or not (props is TileMapLayer):
        fail("Props TileMapLayer missing")
        return
    if walls == null or not (walls is TileMapLayer):
        fail("Walls TileMapLayer missing")
        return

    for layer in [background, props, walls]:
        var tile_set = layer.tile_set
        if tile_set == null:
            fail("TileSet missing on %s" % layer.name)
            return
        if tile_set.resource_path == "" or not tile_set.resource_path.ends_with("scenes/arena/tileset.tres"):
            fail("TileSet path incorrect on %s" % layer.name)
            return
        if tile_set.tile_size != Vector2i(32, 32):
            fail("TileSet tile_size must be 32x32")
            return
        var source = tile_set.get_source(0)
        if source == null or not (source is TileSetAtlasSource):
            fail("TileSet atlas source missing")
            return
        if source.texture == null or not source.texture.resource_path.ends_with("assets/sprites/tiles.png"):
            fail("TileSet texture must be tiles.png")
            return

    var background_rect = background.get_used_rect()
    if background_rect.size.x <= 0 or background_rect.size.y <= 0:
        fail("Background must contain tiles")
        return

    var background_cell_count = background.get_used_cells().size()
    var background_area = background_rect.size.x * background_rect.size.y
    if background_cell_count != background_area:
        fail("Background must be a fully filled rectangle")
        return

    var props_cells = props.get_used_cells()
    if props_cells.size() == 0:
        fail("Props must contain at least one tile")
        return
    if props_cells.size() >= background_cell_count:
        fail("Props must be scattered, not filled")
        return
    for cell in props_cells:
        if not background_rect.has_point(cell):
            fail("Props tiles must be inside the background area")
            return

    var walls_cells = walls.get_used_cells()
    if walls_cells.size() == 0:
        fail("Walls must contain tiles")
        return
    var left_x = background_rect.position.x
    var right_x = background_rect.position.x + background_rect.size.x - 1
    var top_y = background_rect.position.y
    var bottom_y = background_rect.position.y + background_rect.size.y - 1
    var has_left := false
    var has_right := false
    var has_top := false
    var has_bottom := false
    for cell in walls_cells:
        var is_left = cell.x == left_x
        var is_right = cell.x == right_x
        var is_top = cell.y == top_y
        var is_bottom = cell.y == bottom_y
        if not (is_left or is_right or is_top or is_bottom):
            fail("Walls tiles must be on the border of the background")
            return
        has_left = has_left or is_left
        has_right = has_right or is_right
        has_top = has_top or is_top
        has_bottom = has_bottom or is_bottom
    if not (has_left and has_right and has_top and has_bottom):
        fail("Walls must frame the arena on all four sides")
        return

    print("VALIDATION_PASSED: Task completed successfully")
    get_tree().quit(0)
