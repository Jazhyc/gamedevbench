# Key Checklist
- [x] The task starting point runs with `uv run gamedevbench  validate $TASK_NAME` and successfully outputs a test failure 
  - Evidence: `uv run gamedevbench validate task_0114` -> FAILED with "DustParticles GPUParticles2D missing".
- [x] The task ground truth runs with `uv run gamedevbench --gt validate $TASK_NAME` and successfully outputs SUCCESS
  - Evidence: `uv run gamedevbench --gt validate task_0114` -> PASSED "Task completed successfully".
- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0114
  - Evidence: `tasks/task_0114/scenes/main.tscn` defines Arena/Visuals; `tasks/task_0114/scenes/test.tscn` instantiates Main and runs `scripts/test.gd`.
- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Add a GPU particles 2D node under Visuals named DustParticles. / “select the visuals node ... add ... a GPU particles 2D node and ... rename this to dust particles”
  - Set position to (320, 180). / “place it at the middle of the screen ... divide 640 by 2 and also divide 360 by two”
  - Set z_index to 99. / “set the Z index to something bigger ... set it 99 or something like that”
  - Set amount to 20. / “bump up the amount of particles to something like 20”
  - Set lifetime to 6. / “set the time to something bigger ... to something like six”
  - Assign star_particle texture. / “use the star particle texture and drop it over the texture property”
  - Create ParticleProcessMaterial. / “for the process material we can create a new particle process material”
  - Emission shape box with extents x=320. / “change the emission shape from a point to a box ... bump X up to 320”
  - Spread 180. / “bump this up to 180”
  - Initial velocity min 20 max 30. / “set the initial velocity to something like 20 and 30”
  - Angular velocity min 20 max 40. / “change the minimum to something like 20 and the maximum to something like 40”
  - Gravity Y = 0. / “change that y to zero”
  - Scale min 0.1 max 0.2. / “change the minimum to 0.1 and change the maximum to 0.2”
  - Add a scale curve (CurveTexture). / “add a scale curve ... click on new curve texture”
  - Set particle color to semi-transparent (alpha between 0 and 1). / “make it semi-transparent”
  - Instructions Missing from Transcript: None.
- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: `tutorials/GodotGameLab/Godot 4 Autobattler Tutorial_ TileMapLayers & Particles (S1E1)/repo/scenes/Arena/Arena.tscn` contains the same DustParticles node, ParticleProcessMaterial values, curve data, and alpha as `tasks_gt/task_0114/scenes/main.tscn`.
- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: `tasks/task_0114/task_config.json` provides all node names, properties, and asset paths without external references.
- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (node structure, z_index, position, amount, lifetime, texture) / “add ... GPUParticles2D ... named DustParticles ... position (320, 180), z_index 99, amount 20, lifetime 6, assign assets/sprites/star_particle.png”
  - Test 2 (process material type + emission box x + spread + initial/ang velocity + gravity y + scale min/max) / “Create a ParticleProcessMaterial with box emission ... extents X to 320 ... spread 180 ... initial velocity 20–30 ... angular velocity 20–40 ... gravity Y to 0 ... scale min 0.1 max 0.2”
  - Test 3 (scale curve exists) / “Add a CurveTexture as the scale_curve”
  - Test 4 (color alpha between 0 and 1) / “Set the particle color alpha to a semi-transparent value between 0 and 1”
  - Missing Coverage: None.
- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1, Assertions: Visuals Node2D, DustParticles GPUParticles2D, z_index 99, position (320,180), amount 20, lifetime 6, texture path ends with star_particle.png. Instruction coverage: exact node names/types and property values specified.
  - Test 2, Assertions: process_material is ParticleProcessMaterial; emission_shape box; emission_box_extents.x == 320; spread 180; initial_velocity_min 20; initial_velocity_max 30; angular_velocity_min 20; angular_velocity_max 40; gravity.y == 0; scale_min 0.1; scale_max 0.2. Instruction coverage: exact values specified.
  - Test 3, Assertions: scale_curve is CurveTexture with Curve; curve has at least one point. Instruction coverage: “Add a CurveTexture as the scale_curve.”
  - Test 4, Assertions: material color alpha between 0 and 1. Instruction coverage: “Set the particle color alpha to a semi-transparent value between 0 and 1.”
  - **CRITICAL AMBIGUITY CHECKS** - For each test, explicitly verify:
    - [x] String formatting (padding, delimiters, exact format) is specified in instruction
    - [x] Exact string values/names are in instruction (not just "format text")
    - [x] Number formats (zero-padding, decimal places) are specified
    - [x] Any comparison operators (==, !=, >, <, contains, begins_with, ends_with) have clear criteria
    - [x] Node names, paths, and types match instruction exactly
    - [x] Property values (numbers, booleans, strings) have exact values in instruction
  - Ambiguous Tests: None.
- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: Single solution is fully specified (exact node names and property values).
- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0114)
  - Evidence: Uses `assets/`, `scenes/`, `scripts/`, `project.godot`, `task_config.json`, `scenes/main.tscn`, `scenes/test.tscn` layout consistent with other tasks.
- [x] PROCEED. Check this box is the task is validated and all key checks pass successfully.


# Feature Checklist
- [x] The task contains instructions or goals that are Node/inspector-focused. 
  - Evidence: Instruction specifies node hierarchy and Inspector properties for GPUParticles2D and ParticleProcessMaterial.
- [ ] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: All requirements are textual; no visual reasoning is required.
- [ ] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No images or other multimodal inputs are included in `task_config.json`.

# Notes
- Transcript supports the particle setup and semi-transparent requirement; tests now reflect the transcript-level specificity.

# Examples

## Matching task instruction to transcript

- Add a ParallaxBackground under Main with a ParallaxLayer named Ground.
    - “here what I'm going to do under main create a new parallx parallx background and here under it create a parallx
      layer let's call it ground”
- Place a Sprite2D in Ground and assign the water texture asset to it.
    - “under it we are going to have a Sprite Tod which can stay Sprite Tod and we're going to drag our water texture
      now you can see it appearing”
- Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud visuals.
    - “go to our parallx background add another Parallax layer which will be clouds that's right and here under it we're
      going to add a wrecked from the control node”
- Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated clouds.gdshader.
    - “go to our color wct and here we are going to do some things so what we're going to do is go to material and add a
      new Shader material … let's create a new Shader which will be let's say clouds. GD Shader”
- Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.
    - “clouds. motion mirror equals to Vector 2 screen size and screen size screen Max size … it's not going to be scale
      but rather size of it and the size will simply be uh screen Max size and uh screen Max size”
## Matching Test to Instruction

- Test 1 / Instruction 1 – “Add a ParallaxBackground under Main with a ParallaxLayer named Ground.”
    - Code: tasks/task_0114/scripts/test.gd:11-17 checks for ParallaxBackground under Main
      and a ParallaxLayer child named Ground.
- Test 2 / Instruction 2 – “Place a Sprite2D in Ground and assign the water texture asset to it.”
    - Code: tasks/task_0114/scripts/test.gd:20-24 fetches Ground/Sprite2D and asserts its
      texture ends with assets/water.tres.
- Test 3 / Instruction 3 – “Create a second ParallaxLayer named Clouds and add a Control ColorRect to render the cloud
  visuals.”
    - Code: tasks/task_0114/scripts/test.gd:27-33 ensures the ParallaxLayer named Clouds
      exists and contains a ColorRect.
- Test 4 / Instruction 4 – “Turn the Clouds ColorRect into a ShaderMaterial-driven surface using the dedicated
  clouds.gdshader.”
    - Code: tasks/task_0114/scripts/test.gd:35-40 enforces that the ColorRect’s material is a
      ShaderMaterial whose shader path ends with shaders/clouds.gdshader.
- Test 5 / Instruction 5 – “Mirror the Clouds layer with the same vector and set the ColorRect’s size to screen_max_size
  so it fills any aspect ratio.”
    - Code: tasks/task_0114/scripts/test.gd:42-58 zeroes the values, runs _process, computes
      screen_max_size, and asserts both Clouds.motion_mirroring and ColorRect.size match Vector2(screen_max_size,
      screen_max_size).
## Identifying Ambiguous Tests (CRITICAL)

### Example 1: AMBIGUOUS - Vague formatting requirement

**Instruction**: "Format incremental and timer step text"

**Test Code**:
```gdscript
var expected_text = "Destroy 5 ships 00/05"
if do_label.text != expected_text:
    issues.append("Initial incremental text should be '%s'" % expected_text)
```

**Assertions**:
- Checks text equals exactly "Destroy 5 ships 00/05"
- Requires zero-padded format (%02d)
- Requires specific spacing and no delimiters

**Why AMBIGUOUS**: Instruction says "format text" but doesn't specify:
- Zero-padding (00 vs 0)
- Exact delimiter (/ vs out of vs :)
- Spacing
- Format string structure

**How to fix**: Change instruction to: "Format incremental step text as '{details} {collected:02d}/{required:02d}'" OR make test flexible to accept any reasonable format.

### Example 2: UNAMBIGUOUS - Specific requirement

**Instruction**: "Set the ColorRect size to Vector2(screen_max_size, screen_max_size)"

**Test Code**:
```gdscript
var expected_size = Vector2(screen_max_size, screen_max_size)
assert(color_rect.size == expected_size)
```

**Assertions**:
- Checks size equals Vector2(screen_max_size, screen_max_size)

**Why UNAMBIGUOUS**: Instruction explicitly states the exact Vector2 formula to use. No ambiguity about what value is expected.

### Example 3: AMBIGUOUS - Missing specific values

**Instruction**: "Connect to QuestManager signals"

**Test Code**:
```gdscript
var required_signals = ["step_updated", "step_complete", "quest_completed", "quest_failed"]
for signal_name in required_signals:
    if not _has_connection(qm, signal_name, quest_ui):
        issues.append("Must connect to QuestManager.%s" % signal_name)
```

**Why AMBIGUOUS**: Instruction says "signals" (plural, vague) but test checks for 4 specific signal names. A solver might connect only 2 signals and technically satisfy "connect to signals".

**How to fix**: Change instruction to: "Connect to QuestManager signals: step_updated, step_complete, quest_completed, and quest_failed"
