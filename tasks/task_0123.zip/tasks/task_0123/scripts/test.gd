extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if main == null:
		return _fail("Main node not found")

	var tile_map = main.get_node_or_null("TileMap")
	if tile_map == null:
		return _fail("TileMap node missing under Main")
	if tile_map is TileMap:
		return _fail("TileMap node must be Node2D")

	if tile_map.get_child_count() != 2:
		return _fail("TileMap node should only contain two children")
	
	var tilemap_layer_base = tile_map.get_child(0)
	if not (tilemap_layer_base is TileMapLayer):
		return _fail("TileMap child node not a TileMaplayer")
	if tilemap_layer_base.name != "Base":
		return _fail("TileMap layer 0 must be named Base")

	var tilemap_layer_decor = tile_map.get_child(1)
	if not (tilemap_layer_decor is TileMapLayer):
		return _fail("TileMap child node not a TileMaplayer")
	if tilemap_layer_decor.name != "Decor":
		return _fail("TileMap layer 1 must be named Decor")	

	var tile_set: TileSet = tilemap_layer_base.tile_set
	if tile_set == null:
		return _fail("TileMap must have a TileSet assigned")

	if tile_set.tile_size != Vector2i(18, 18):
		return _fail("TileSet tile_size must be 18x18")

	var source = tile_set.get_source(0)
	if source == null or not (source is TileSetAtlasSource):
		return _fail("TileSet source 0 must be a TileSetAtlasSource")
	
	for y in range(9):
		for x in range(20):
			var vec : Vector2i = source.get_tile_at_coords(Vector2i(x, y))
			if vec.x < 0 or vec.y < 0:
				return _fail("Some tiles are not set up correctly")
	
	# Content Check
	tilemap_layer_base = tilemap_layer_base as TileMapLayer
	var base_truth_table = {
		Vector2i(0, 7): Vector2i(-1, -1),
		Vector2i(0, 8): Vector2i(1, 1),
		Vector2i(13, 7): Vector2i(15, 0),
		Vector2i(19, 19): Vector2i(-1, -1),
		Vector2i(19, 15): Vector2i(3, 6)
	}
	for key in base_truth_table.keys():
		var value = base_truth_table.get(key)
		var cell_coords : Vector2i = tilemap_layer_base.get_cell_atlas_coords(key)
		if cell_coords != value:
			return _fail("Base layer check failed, expected %s at %s, got %s instead" % [
				str(value), str(key), str(cell_coords)
			])
	
	tilemap_layer_decor = tilemap_layer_decor as TileMapLayer
	var decor_truth_table = {
		Vector2i(0, 7): Vector2i(5, 6),
		Vector2i(0, 8): Vector2i(-1, -1),
		Vector2i(13, 7): Vector2i(-1, -1),
		Vector2i(19, 19): Vector2i(-1, -1),
		Vector2i(20, 15): Vector2i(13, 3)
	}
	for key in decor_truth_table.keys():
		var value = decor_truth_table.get(key)
		var cell_coords : Vector2i = tilemap_layer_decor.get_cell_atlas_coords(key)
		if cell_coords != value:
			return _fail("Decor layer check failed, expected %s at %s, got %s instead" % [
				str(value), str(key), str(cell_coords)
			])
	if tilemap_layer_base.z_index != 0:
		return _fail("Base layer z-index mismatch")
	if tilemap_layer_decor.z_index != -10:
		return _fail("Decor layer z-index mismatch")
	
	if source.has_tiles_outside_texture():
		return _fail("Has tiles outside texture!")

	if source.texture == null or source.texture.resource_path != "res://assets/sprites/tilemap.png":
		return _fail("Atlas source must use res://assets/sprites/tilemap.png")

	if source.texture_region_size != Vector2i(18, 18):
		return _fail("Atlas source tile size must be 18x18")

	if source.separation != Vector2i(1, 1):
		return _fail("Atlas source separation must be 1x1")

	print("VALIDATION_PASSED: TileMap correctly configured.")
	get_tree().quit()

func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
