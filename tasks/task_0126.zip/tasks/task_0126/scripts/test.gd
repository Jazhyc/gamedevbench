extends Node

func _ready():
	run_validation()

func run_validation():
	var main_node = get_node("Main")
	if not main_node:
		print("VALIDATION_FAILED: Main node not found")
		get_tree().quit(1)
		return

	var ui = main_node.get_node("UI")
	if not ui:
		print("VALIDATION_FAILED: UI node not found")
		get_tree().quit(1)
		return

	if not ui is Panel:
		print("VALIDATION_FAILED: UI must be a Panel")
		get_tree().quit(1)
		return

	if abs(ui.self_modulate.a - 0.784314) > 0.001:
		print("VALIDATION_FAILED: UI self_modulate alpha must be 0.784314")
		get_tree().quit(1)
		return

	if abs(ui.anchor_bottom - 1.0) > 0.001 or abs(ui.offset_right - 320.0) > 0.001:
		print("VALIDATION_FAILED: UI anchors/offsets not configured")
		get_tree().quit(1)
		return

	if ui.grow_vertical != Control.GROW_DIRECTION_BOTH:
		print("VALIDATION_FAILED: UI grow_vertical must be BOTH")
		get_tree().quit(1)
		return

	var menu = ui.get_node("Menu")
	if not menu or not menu is VBoxContainer:
		print("VALIDATION_FAILED: Menu VBoxContainer not found")
		get_tree().quit(1)
		return

	if abs(menu.offset_left - 10.0) > 0.001 or abs(menu.offset_right - 310.0) > 0.001:
		print("VALIDATION_FAILED: Menu offsets not configured")
		get_tree().quit(1)
		return

	var fullscreen_block = menu.get_node("FullScreenBlock")
	if not fullscreen_block or not fullscreen_block is HBoxContainer:
		print("VALIDATION_FAILED: FullScreenBlock HBoxContainer not found")
		get_tree().quit(1)
		return

	var fullscreen_label = fullscreen_block.get_node("Full screen label")
	if not fullscreen_label or fullscreen_label.text != "(F)ull Screen: ":
		print("VALIDATION_FAILED: Full screen label text incorrect")
		get_tree().quit(1)
		return

	var fullscreen_toggle = fullscreen_block.get_node("FullScreen")
	if not fullscreen_toggle or not fullscreen_toggle is CheckButton:
		print("VALIDATION_FAILED: FullScreen CheckButton not found")
		get_tree().quit(1)
		return

	if fullscreen_toggle.button_pressed != true:
		print("VALIDATION_FAILED: FullScreen should be pressed by default")
		get_tree().quit(1)
		return

	var fractal_block = menu.get_node("FractalBlock")
	if not fractal_block or not fractal_block is HBoxContainer:
		print("VALIDATION_FAILED: FractalBlock HBoxContainer not found")
		get_tree().quit(1)
		return

	var select_label = fractal_block.get_node("Label")
	if not select_label or select_label.text != "Select Fractal: ":
		print("VALIDATION_FAILED: Select Fractal label text incorrect")
		get_tree().quit(1)
		return

	var mandelbrot_button = fractal_block.get_node("Mandelbrot Button")
	if not mandelbrot_button or not mandelbrot_button is Button:
		print("VALIDATION_FAILED: Mandelbrot Button missing")
		get_tree().quit(1)
		return

	if mandelbrot_button.text != "Mandelbrot":
		print("VALIDATION_FAILED: Mandelbrot Button text incorrect")
		get_tree().quit(1)
		return

	var julia_button = fractal_block.get_node("Julia Button")
	if not julia_button or not julia_button is Button:
		print("VALIDATION_FAILED: Julia Button missing")
		get_tree().quit(1)
		return

	if julia_button.text != "Julia":
		print("VALIDATION_FAILED: Julia Button text incorrect")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: UI controls configured")
	get_tree().quit(1)
