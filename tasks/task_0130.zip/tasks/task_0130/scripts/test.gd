extends Node

const FOG_COLOR := Color(0.517647, 0.552941, 0.619608, 1)
const VOLUMETRIC_COLOR := Color(0.870588, 0.796078, 0.772549, 1)

func _ready():
	validate_fog_and_lut()

func fail(message: String) -> void:
	print(message)
	get_tree().quit(1)

func colors_close(a: Color, b: Color, tolerance: float) -> bool:
	return (
		abs(a.r - b.r) <= tolerance and
		abs(a.g - b.g) <= tolerance and
		abs(a.b - b.b) <= tolerance
	)

func validate_fog_and_lut():
	var main := get_node_or_null("Main")
	if main == null:
		fail("VALIDATION_FAILED: Main node missing")
		return
	var world_env: WorldEnvironment = main.get_node_or_null("WorldEnvironment")
	if world_env == null:
		fail("VALIDATION_FAILED: WorldEnvironment node missing")
		return
	var env: Environment = world_env.environment
	if env == null:
		fail("VALIDATION_FAILED: WorldEnvironment lacks Environment resource")
		return

	if not env.fog_enabled:
		fail("VALIDATION_FAILED: Linear fog must be enabled")
		return
	if not colors_close(env.fog_light_color, FOG_COLOR, 0.02):
		fail("VALIDATION_FAILED: Fog light color incorrect")
		return
	if abs(env.fog_density - 0.001) > 0.0002:
		fail("VALIDATION_FAILED: Fog density must be 0.001")
		return
	if abs(env.fog_sky_affect - 0.147) > 0.01:
		fail("VALIDATION_FAILED: Fog sky affect must be 0.147")
		return
	if env.fog_mode != env.FOG_MODE_DEPTH:
		fail("VALIDATION_FAILED: Fog sky should be FOG_MODE_DEPTH")
		return
	if not env.volumetric_fog_enabled:
		fail("VALIDATION_FAILED: Volumetric fog must be enabled")
		return
	if not colors_close(env.volumetric_fog_albedo, VOLUMETRIC_COLOR, 0.02):
		fail("VALIDATION_FAILED: Volumetric fog albedo incorrect")
		return

	if not env.adjustment_enabled:
		fail("VALIDATION_FAILED: Adjustments must be enabled")
		return
	var lut := env.adjustment_color_correction
	if lut == null:
		fail("VALIDATION_FAILED: LUT texture not assigned")
		return
	if !(lut is Texture3D):
		fail("VALIDATION_FAILED: LUT must import as Texture3D")
		return
	if !lut.resource_path.ends_with("ExtremeLUT.png"):
		fail("VALIDATION_FAILED: LUT must use ExtremeLUT.png")
		return

	print("VALIDATION_PASSED: Fog and LUT configuration complete")
	get_tree().quit(0)
