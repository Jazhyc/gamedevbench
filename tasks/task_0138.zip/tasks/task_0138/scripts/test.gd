extends Node

func _ready():
	var ui_scene: PackedScene = load("res://scenes/ui.tscn")
	if ui_scene == null:
		return _fail("UI scene not found at res://scenes/ui.tscn")

	var ui_instance = ui_scene.instantiate()
	add_child(ui_instance)

	if not ui_instance is CanvasLayer:
		return _fail("UI root must be a CanvasLayer")
	if ui_instance.name != "UI":
		return _fail("CanvasLayer root must be named 'UI'")

	var popup: CenterContainer = ui_instance.get_node_or_null("AlertDialog")
	if popup == null:
		return _fail("AlertDialog node missing under UI")
	if popup.visible:
		return _fail("AlertDialog should be hidden by default")
	if popup.anchor_left != 0.5 or popup.anchor_right != 0.5 or popup.anchor_top != 0.5 or popup.anchor_bottom != 0.5:
		return _fail("AlertDialog must use the Center preset anchors")
	if popup.grow_horizontal != 2 or popup.grow_vertical != 2:
		return _fail("AlertDialog should keep the Center preset growth behavior")

	var popup_rect: ColorRect = popup.get_node_or_null("ColorRect")
	if popup_rect == null:
		return _fail("AlertDialog must contain a ColorRect child")
	if popup_rect.custom_minimum_size != Vector2(220, 100):
		return _fail("ColorRect should keep the requested custom minimum size")

	var popup_label: Label = popup_rect.get_node_or_null("Label")
	if popup_label == null:
		return _fail("ColorRect must contain a Label")
	if popup_label.text.strip_edges() != "ALERT":
		return _fail("Label text should read 'ALERT'")

	print("VALIDATION_PASSED: center preset popup variant is configured correctly")
	get_tree().quit(0)

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
