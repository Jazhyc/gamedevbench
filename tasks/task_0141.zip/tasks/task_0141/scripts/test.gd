extends Node

func _ready():
	var ui_scene: PackedScene = load("res://scenes/ui.tscn")
	if ui_scene == null:
		return _fail("UI scene not found at res://scenes/ui.tscn")

	var ui_instance = ui_scene.instantiate()
	add_child(ui_instance)

	if not ui_instance is CanvasLayer:
		return _fail("UI root must be a CanvasLayer")
	if ui_instance.name != "UI":
		return _fail("CanvasLayer root must be named 'UI'")

	var panel: ColorRect = ui_instance.get_node_or_null("TopPanel")
	if panel == null:
		return _fail("TopPanel node missing under UI")
	if panel.anchor_top != 0.0 or panel.anchor_bottom != 0.0:
		return _fail("TopPanel must be anchored to the top (anchor_top & anchor_bottom = 0)")
	if panel.grow_vertical != 1:
		return _fail("TopPanel should keep the Top Wide preset growth behavior")
	if panel.custom_minimum_size.y < 58.0:
		return _fail("TopPanel should reserve at least 58px height")
	if panel.color != Color(0.6, 0.6, 0.6, 1.0):
		return _fail("TopPanel should use the requested neutral grey")

	var label_a: Label = panel.get_node_or_null("LivesLabel")
	if label_a == null:
		return _fail("LivesLabel missing inside TopPanel")
	if label_a.text.strip_edges() != "Lives: 3":
		return _fail("LivesLabel text should read 'Lives: 3'")

	var label_b: Label = panel.get_node_or_null("PointsLabel")
	if label_b == null:
		return _fail("PointsLabel missing inside TopPanel")
	if label_b.text.strip_edges() != "Points: 0":
		return _fail("PointsLabel text should read 'Points: 0'")

	var power_meter: TextureRect = panel.get_node_or_null("PowerMeter")
	if power_meter == null:
		return _fail("PowerMeter TextureRect missing")
	if not power_meter.texture or not power_meter.texture.resource_path.ends_with("Fuel-Meter.png"):
		return _fail("PowerMeter must use Fuel-Meter.png")
	if power_meter.anchor_left != 0.5 or power_meter.anchor_right != 0.5:
		return _fail("PowerMeter should be centered horizontally")
	if power_meter.anchor_top != 0.0 or power_meter.anchor_bottom != 0.0:
		return _fail("PowerMeter should hug the top (anchor_top/bottom = 0)")

	var power_indicator: TextureRect = panel.get_node_or_null("PowerIndicator")
	if power_indicator == null:
		return _fail("PowerIndicator TextureRect missing")
	if not power_indicator.texture or not power_indicator.texture.resource_path.ends_with("Fuel-Indicator.png"):
		return _fail("PowerIndicator must use Fuel-Indicator.png")

	var overlay: CenterContainer = ui_instance.get_node_or_null("GameOverView")
	if overlay == null:
		return _fail("GameOverView node missing")
	if overlay.visible:
		return _fail("GameOverView should be hidden by default")
	var overlay_rect: ColorRect = overlay.get_node_or_null("ColorRect")
	if overlay_rect == null:
		return _fail("GameOverView must contain a ColorRect background")
	var overlay_label: Label = overlay_rect.get_node_or_null("Label")
	if overlay_label == null:
		return _fail("GameOverView ColorRect must include a Label")
	if overlay_label.text.strip_edges() != "GAME OVER":
		return _fail("Overlay label should read 'GAME OVER'")

	print("VALIDATION_PASSED: top preset HUD variant is configured correctly")
	get_tree().quit(0)

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
