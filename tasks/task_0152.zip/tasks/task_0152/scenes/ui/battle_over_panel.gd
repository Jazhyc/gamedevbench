class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var style_box := StyleBoxFlat.new()
	style_box.bg_color = Color(0, 0, 0, 0.32)
	add_theme_stylebox_override("panel", style_box)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -18
	vbox.offset_top = -18
	vbox.offset_right = 18
	vbox.offset_bottom = 18

	var settings := LabelSettings.new()
	settings.font_size = 22
	label.label_settings = settings
	label.text = 'Victory!'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	continue_button.custom_minimum_size = Vector2(60, 18)
	restart_button.custom_minimum_size = Vector2(60, 18)
	continue_button.text = 'Done'
	restart_button.text = 'Again'
	continue_button.size_flags_horizontal = 3
	restart_button.size_flags_horizontal = 3

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
