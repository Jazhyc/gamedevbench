class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var shade_style := StyleBoxFlat.new()
	shade_style.bg_color = Color(0, 0, 0, 0.26)
	add_theme_stylebox_override("panel", shade_style)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -11.0
	vbox.offset_top = -11.0
	vbox.offset_right = 11.0
	vbox.offset_bottom = 11.0

	var message_settings := LabelSettings.new()
	message_settings.font_size = 18
	label.label_settings = message_settings
	label.text = 'Success'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var button_metrics := Vector2(46, 15)
	continue_button.custom_minimum_size = button_metrics
	restart_button.custom_minimum_size = button_metrics
	continue_button.text = 'Done'
	restart_button.text = 'Retry'

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
