extends Node


func _ready() -> void:
	run_validation()


func fail(message: String) -> void:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)


func assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		fail(message)
		return false
	return true


func _get_animation_frames(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != "CharacterSprite:frame":
			continue

		var frames: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var frame_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if frames.is_empty() or frames[-1] != frame_value:
				frames.append(frame_value)
		return frames

	return []


func _get_animation_property_values(animation_player: AnimationPlayer, animation_name: String, property_path: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != property_path:
			continue

		var values: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			values.append(animation.track_get_key_value(track_idx, key_idx))
		return values

	return []

func run_validation() -> void:
	var player_scene: PackedScene = load("res://scenes/characters/player.tscn")
	if not assert_or_fail(player_scene != null, "player.tscn must load"):
		return

	var player: Node2D = player_scene.instantiate() as Node2D
	if not assert_or_fail(player != null, "player.tscn must instantiate"):
		return
	add_child(player)

	var animation_player: AnimationPlayer = player.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if not assert_or_fail(animation_player != null, "Player must contain AnimationPlayer"):
		return

	var character_sprite: Sprite2D = player.get_node_or_null("CharacterSprite") as Sprite2D
	if not assert_or_fail(character_sprite != null, "Player must contain CharacterSprite"):
		return

	if not assert_or_fail(_get_animation_frames(animation_player, "jumpkick") == [63], "jumpkick animation must use the expected frame from the 7th row"):
		return
	if not assert_or_fail(_get_animation_property_values(animation_player, "jumpkick", "DamageEmitter:monitoring") in [[true, true], [true]], "jumpkick animation must enable DamageEmitter monitoring while it plays"):
		return
	if not assert_or_fail(animation_player.has_animation("jump"), "Player must preserve the existing jump animation"):
		return
	var damage_emitter: Area2D = player.get_node_or_null("DamageEmitter") as Area2D
	if not assert_or_fail(damage_emitter != null, "Player must contain DamageEmitter"):
		return

	var entered_jump := false
	Input.action_press("jump")
	player.call("_process", 0.016)
	Input.action_release("jump")
	for _i: int in range(20):
		player.call("_process", 0.01)
		if animation_player.current_animation == "jump":
			entered_jump = true
			break
	if not assert_or_fail(entered_jump, "The player must still enter the airborne jump animation before a jumpkick can happen"):
		return

	Input.action_press("attack")
	player.call("_process", 0.016)
	Input.action_release("attack")
	animation_player.advance(0.0)
	if not assert_or_fail(animation_player.current_animation == "jumpkick", "Pressing attack during the airborne jump phase must trigger the jumpkick animation"):
		return
	if not assert_or_fail(damage_emitter.monitoring == true, "Jumpkick must enable DamageEmitter monitoring while the attack is active"):
		return
	if not assert_or_fail(character_sprite.position.y < 0.0, "Jumpkick must happen while the player is still airborne"):
		return

	var landed := false
	for _i: int in range(80):
		await get_tree().create_timer(0.04).timeout
		if animation_player.current_animation == "land":
			landed = true
			break
	if not assert_or_fail(landed, "The player must still enter the land animation after a jumpkick"):
		return
	animation_player.advance(0.0)
	if not assert_or_fail(is_zero_approx(character_sprite.position.y), "CharacterSprite must return to its grounded position when landing begins after a jumpkick"):
		return
	if not assert_or_fail(damage_emitter.monitoring == false, "Landing after a jumpkick must disable DamageEmitter monitoring again"):
		return

	print("VALIDATION_PASSED: fighter jumpkick action and animation are implemented")
	get_tree().quit(0)
