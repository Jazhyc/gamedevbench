extends Node


func _ready() -> void:
	run_validation()


func fail(message: String) -> void:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)


func assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		fail(message)
		return false
	return true


func _get_animation_frames(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != "CharacterSprite:frame":
			continue

		var frames: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var frame_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if frames.is_empty() or frames[-1] != frame_value:
				frames.append(frame_value)
		return frames

	return []


func _get_animation_method_names(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	var method_names: Array = []
	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_METHOD:
			continue

		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var key_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if key_value is Dictionary and key_value.has("method"):
				method_names.append(String(key_value["method"]))

	return method_names


func run_validation() -> void:
	var enemy_scene: PackedScene = load("res://scenes/characters/basic_enemy.tscn")
	if not assert_or_fail(enemy_scene != null, "basic_enemy.tscn must load"):
		return

	var enemy: Node2D = enemy_scene.instantiate() as Node2D
	if not assert_or_fail(enemy != null, "basic_enemy.tscn must instantiate"):
		return
	add_child(enemy)
	await get_tree().process_frame

	var animation_player: AnimationPlayer = enemy.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if not assert_or_fail(animation_player != null, "BasicEnemy must contain AnimationPlayer"):
		return

	var frames_used = []
	for frame in _get_animation_frames(animation_player, "dead"):
		if frame not in frames_used:
			frames_used.append(frame)
	frames_used.sort()
	if not assert_or_fail(frames_used == [50, 51, 52], "dead animation must use the first 3 valid frames from the 6th row"):
		return
	if not assert_or_fail("queue_free" in _get_animation_method_names(animation_player, "dead"), "dead animation must call queue_free when it finishes"):
		return
	if not assert_or_fail(animation_player.has_animation("hurt"), "BasicEnemy must preserve the existing hurt animation"):
		return

	var max_health: int = int(enemy.get("max_health"))
	enemy.call("on_receive_damage", max_health, Vector2.RIGHT)
	await get_tree().process_frame

	if not assert_or_fail(is_instance_valid(enemy) and enemy.is_inside_tree(), "Lethal damage must not remove the enemy immediately"):
		return
	if not assert_or_fail(animation_player.current_animation == "dead", "Lethal damage must trigger the dead animation"):
		return
	if not assert_or_fail(enemy.velocity == Vector2.ZERO, "Lethal damage must stop enemy movement"):
		return

	enemy.velocity = Vector2.RIGHT * float(enemy.get("speed"))
	enemy.call("handle_movement")
	await get_tree().process_frame
	if not assert_or_fail(animation_player.current_animation == "dead", "Enemy must stay in the dead animation after death instead of returning to movement states"):
		return

	var enemy_ref: WeakRef = weakref(enemy)
	for _i: int in range(240):
		await get_tree().create_timer(0.01).timeout
		if enemy_ref.get_ref() == null:
			break
	if not assert_or_fail(enemy_ref.get_ref() == null, "Enemy must be removed after the dead animation finishes"):
		return

	print("VALIDATION_PASSED: enemy death logic and animation are implemented")
	get_tree().quit(0)
