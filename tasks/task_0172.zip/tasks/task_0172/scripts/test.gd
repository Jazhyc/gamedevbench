extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is TileMap, "TileMap node missing under Main"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap must have a TileSet assigned"):
		return

	if not _assert_or_fail(tile_set.get_custom_data_layers_count() >= 1, "TileSet must define a custom data layer"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(0) == "water", "The first custom data layer must be named water"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(0) == TYPE_BOOL, "The water custom data layer must be a boolean layer"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var water_tiles := {}
	for x in range(13, 16):
		for y in range(1, 4):
			water_tiles[Vector2i(x, y)] = true

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var water_value: Variant = tile_data.get_custom_data("water")
			if coords in water_tiles:
				if not _assert_or_fail(water_value == true, "Water tile (%d, %d) must have water set to true" % [x, y]):
					return
			else:
				if not _assert_or_fail(water_value == false, "Non-water tile (%d, %d) must have water set to false" % [x, y]):
					return

	print("VALIDATION_PASSED: water custom data layer is configured correctly.")
	get_tree().quit(0)
