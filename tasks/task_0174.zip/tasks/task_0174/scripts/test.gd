extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _neighbor_names() -> Dictionary:
	return {
		TileSet.CELL_NEIGHBOR_RIGHT_SIDE: "right_side",
		TileSet.CELL_NEIGHBOR_BOTTOM_SIDE: "bottom_side",
		TileSet.CELL_NEIGHBOR_LEFT_SIDE: "left_side",
		TileSet.CELL_NEIGHBOR_TOP_SIDE: "top_side",
	}


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return
	if not _assert_or_fail(tile_set.get_terrain_sets_count() >= 1, "TileSet must define a terrain set"):
		return
	if not _assert_or_fail(tile_set.get_terrain_set_mode(0) == TileSet.TERRAIN_MODE_MATCH_SIDES, "Terrain set 0 must use Match Sides mode"):
		return
	if not _assert_or_fail(tile_set.get_terrains_count(0) >= 2, "Terrain set 0 must contain at least 2 terrains"):
		return
	if not _assert_or_fail(tile_set.get_terrain_name(0, 0) == "Grassland", "Terrain 0 in terrain set 0 must remain Grassland"):
		return
	if not _assert_or_fail(tile_set.get_terrain_name(0, 1) == "Leaves", "Terrain 1 in terrain set 0 must be named Leaves"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var expected_tiles := {
		Vector2i(16, 0): [],
		Vector2i(16, 1): [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE],
		Vector2i(16, 2): [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(16, 3): [TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(17, 0): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE],
		Vector2i(17, 1): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(17, 2): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(17, 3): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE],
		Vector2i(18, 0): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE],
		Vector2i(18, 1): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(18, 2): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(18, 3): [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE],
		Vector2i(19, 0): [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE],
		Vector2i(19, 1): [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(19, 2): [TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE],
		Vector2i(19, 3): [TileSet.CELL_NEIGHBOR_LEFT_SIDE],
	}

	var neighbor_names := _neighbor_names()

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			if coords in expected_tiles:
				if not _assert_or_fail(tile_data.terrain_set == 0, "Leaves tile (%d, %d) must belong to terrain set 0" % [x, y]):
					return
				if not _assert_or_fail(tile_data.terrain == 1, "Leaves tile (%d, %d) must use terrain 1" % [x, y]):
					return

				var expected_neighbors: Array = expected_tiles[coords]
				for neighbor in neighbor_names.keys():
					var expected_value := 1 if neighbor in expected_neighbors else -1
					if not _assert_or_fail(tile_data.get_terrain_peering_bit(neighbor) == expected_value, "Leaves tile (%d, %d) has incorrect peering bit for %s" % [x, y, neighbor_names[neighbor]]):
						return
			else:
				if not _assert_or_fail(tile_data.terrain != 1, "Non-leaf tile (%d, %d) must not use the Leaves terrain" % [x, y]):
					return

	print("VALIDATION_PASSED: Leaves terrain is configured correctly.")
	get_tree().quit(0)
