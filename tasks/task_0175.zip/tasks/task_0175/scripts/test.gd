extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _expected_number_for_coords(coords: Vector2i) -> int:
	if coords.y != 8:
		return 0
	if coords.x >= 1 and coords.x <= 9:
		return coords.x
	if coords.x >= 11 and coords.x <= 19:
		return coords.x - 10
	return 0


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is TileMap, "TileMap node missing under Main"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap must have a TileSet assigned"):
		return

	if not _assert_or_fail(tile_set.get_custom_data_layers_count() >= 1, "TileSet must define a custom data layer"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(0) == "number", "The first custom data layer must be named number"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(0) == TYPE_INT, "The number custom data layer must be an integer layer"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var expected_number := _expected_number_for_coords(coords)
			var number_value: Variant = tile_data.get_custom_data("number")
			if not _assert_or_fail(number_value is int, "Tile (%d, %d) must store an integer number value" % [x, y]):
				return
			if not _assert_or_fail(number_value == expected_number, "Tile (%d, %d) must have number set to %d" % [x, y, expected_number]):
				return

	print("VALIDATION_PASSED: number custom data layer is configured correctly.")
	get_tree().quit(0)
