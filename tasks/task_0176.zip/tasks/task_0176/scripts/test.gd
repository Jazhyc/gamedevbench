extends Node


const EXPECTED_POINTS := [
	Vector2(-9, -9),
	Vector2(9, -9),
	Vector2(9, 9),
	Vector2(-9, 9),
]


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _has_expected_collision(tile_data: TileData) -> bool:
	var polygons := tile_data.get_collision_polygons_count(0)
	if polygons != 1:
		return false
	var points := tile_data.get_collision_polygon_points(0, 0)
	return points == PackedVector2Array(EXPECTED_POINTS)


func _should_have_collision(coords: Vector2i) -> bool:
	return coords.x >= 0 and coords.x <= 7 and coords.y >= 0 and coords.y <= 3


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is Node2D, "TileMap node missing under Main"):
		return

	var base := tile_map.get_node_or_null("Base")
	if not _assert_or_fail(base != null and base is TileMapLayer, "Base TileMapLayer missing under TileMap"):
		return

	var tile_set: TileSet = base.tile_set
	if not _assert_or_fail(tile_set != null, "Base TileMapLayer must have a TileSet assigned"):
		return
	if not _assert_or_fail(tile_set.get_physics_layer_collision_mask(0) == 2, "Physics layer 0 collision mask must be 2"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	for y in range(5):
		for x in range(10):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var has_collision := tile_data.get_collision_polygons_count(0) > 0
			if _should_have_collision(coords):
				if not _assert_or_fail(has_collision, "Tile (%d, %d) must have a collision polygon" % [x, y]):
					return
				if not _assert_or_fail(_has_expected_collision(tile_data), "Tile (%d, %d) must use a full-tile rectangle collision polygon" % [x, y]):
					return
			else:
				if not _assert_or_fail(not has_collision, "Tile (%d, %d) must not have a collision polygon" % [x, y]):
					return

	print("VALIDATION_PASSED: terrain collision polygons are configured correctly.")
	get_tree().quit(0)
