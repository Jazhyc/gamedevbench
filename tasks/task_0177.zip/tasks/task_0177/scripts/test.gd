extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _neighbor_names() -> Dictionary:
	return {
		TileSet.CELL_NEIGHBOR_RIGHT_SIDE: "right_side",
		TileSet.CELL_NEIGHBOR_BOTTOM_SIDE: "bottom_side",
		TileSet.CELL_NEIGHBOR_LEFT_SIDE: "left_side",
		TileSet.CELL_NEIGHBOR_TOP_SIDE: "top_side",
	}


func _expected_terrain_tiles() -> Dictionary:
	return {
		Vector2i(0, 0): {"terrain": 0, "neighbors": []},
		Vector2i(0, 1): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE]},
		Vector2i(0, 2): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(0, 3): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(1, 0): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE]},
		Vector2i(1, 1): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE]},
		Vector2i(1, 2): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(1, 3): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(2, 0): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(2, 1): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(2, 2): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(2, 3): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(3, 0): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(3, 1): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(3, 2): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(3, 3): {"terrain": 0, "neighbors": [TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(4, 0): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE]},
		Vector2i(4, 1): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(4, 2): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(4, 3): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE]},
		Vector2i(5, 0): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(5, 1): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(5, 2): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(5, 3): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_RIGHT_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(6, 0): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(6, 1): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(6, 2): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_LEFT_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(6, 3): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_LEFT_SIDE]},
		Vector2i(7, 0): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE]},
		Vector2i(7, 1): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_BOTTOM_SIDE, TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(7, 2): {"terrain": 1, "neighbors": [TileSet.CELL_NEIGHBOR_TOP_SIDE]},
		Vector2i(7, 3): {"terrain": 1, "neighbors": []},
	}


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return
	if not _assert_or_fail(tile_set.get_terrain_sets_count() >= 1, "TileSet must define a terrain set"):
		return
	if not _assert_or_fail(tile_set.get_terrain_set_mode(0) == TileSet.TERRAIN_MODE_MATCH_SIDES, "Terrain set 0 must use Match Sides mode"):
		return
	if not _assert_or_fail(tile_set.get_terrains_count(0) >= 2, "Terrain set 0 must contain at least 2 terrains"):
		return
	if not _assert_or_fail(tile_set.get_terrain_name(0, 0) == "Dirt", "Terrain 0 in terrain set 0 must be named Dirt"):
		return
	if not _assert_or_fail(tile_set.get_terrain_name(0, 1) == "Leaf", "Terrain 1 in terrain set 0 must be named Leaf"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var expected_tiles := _expected_terrain_tiles()
	var neighbor_names := _neighbor_names()

	for y in range(5):
		for x in range(10):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			if coords in expected_tiles:
				var expected: Dictionary = expected_tiles[coords]
				var expected_terrain: int = int(expected["terrain"])
				if not _assert_or_fail(tile_data.terrain_set == 0, "Terrain tile (%d, %d) must belong to terrain set 0" % [x, y]):
					return
				if not _assert_or_fail(tile_data.terrain == expected_terrain, "Terrain tile (%d, %d) has the wrong terrain assigned" % [x, y]):
					return

				var expected_neighbors: Array = expected["neighbors"]
				for neighbor in neighbor_names.keys():
					var expected_value: int = expected_terrain if neighbor in expected_neighbors else -1
					if not _assert_or_fail(tile_data.get_terrain_peering_bit(neighbor) == expected_value, "Terrain tile (%d, %d) has incorrect peering bit for %s" % [x, y, neighbor_names[neighbor]]):
						return
			else:
				if not _assert_or_fail(tile_data.terrain_set == -1, "Non-terrain tile (%d, %d) must not belong to the terrain set" % [x, y]):
					return
				if not _assert_or_fail(tile_data.terrain == -1, "Non-terrain tile (%d, %d) must not have a terrain assigned" % [x, y]):
					return

	print("VALIDATION_PASSED: terrains are configured correctly.")
	get_tree().quit(0)
