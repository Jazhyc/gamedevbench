extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is TileMap, "TileMap node missing under Main"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap must have a TileSet assigned"):
		return

	if not _assert_or_fail(tile_set.get_custom_data_layers_count() >= 2, "TileSet must define at least 2 custom data layers"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(0) == "pipe", "The first custom data layer must remain named pipe"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(0) == TYPE_BOOL, "The pipe custom data layer must remain a boolean layer"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(1) == "plant", "The second custom data layer must be named plant"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(1) == TYPE_BOOL, "The plant custom data layer must be a boolean layer"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var plant_tiles := {
		Vector2i(4, 6): true,
		Vector2i(5, 6): true,
		Vector2i(6, 6): true,
		Vector2i(7, 6): true,
		Vector2i(8, 6): true,
		Vector2i(9, 6): true,
	}

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var plant_value: Variant = tile_data.get_custom_data("plant")
			if coords in plant_tiles:
				if not _assert_or_fail(plant_value == true, "Plant tile (%d, %d) must have plant set to true" % [x, y]):
					return
			else:
				if not _assert_or_fail(plant_value == false, "Non-plant tile (%d, %d) must have plant set to false" % [x, y]):
					return

	print("VALIDATION_PASSED: plant custom data layer is configured correctly.")
	get_tree().quit(0)
