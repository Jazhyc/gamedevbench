extends CharacterBody2D


func _physics_process(_delta: float) -> void:
	velocity.y += 10
	if Input.is_action_pressed("ui_left"):
		velocity.x = -40
	elif Input.is_action_pressed("ui_right"):
		velocity.x = 40
	else:
		velocity.x = 0
	if Input.is_action_just_pressed("ui_accept"):
		velocity.y -= 300
	move_and_slide()
