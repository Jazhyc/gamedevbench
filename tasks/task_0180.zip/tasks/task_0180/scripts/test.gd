extends Node


const EXPECTED_ALPHA := 128.0 / 255.0


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var player := main.get_node_or_null("Player")
	if not _assert_or_fail(player != null and player is CanvasItem, "Player node missing under Main"):
		return
	var player_z := (player as CanvasItem).z_index

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var waterfall_tiles := {
		Vector2i(14, 1): true,
		Vector2i(14, 2): true,
		Vector2i(14, 3): true,
		Vector2i(15, 1): true,
		Vector2i(15, 2): true,
		Vector2i(15, 3): true,
	}

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var alpha := tile_data.modulate.a
			if coords in waterfall_tiles:
				if not _assert_or_fail(tile_data.z_index > player_z, "Waterfall tile (%d, %d) must have a z-index larger than the player" % [x, y]):
					return
				if not _assert_or_fail(is_equal_approx(alpha, EXPECTED_ALPHA), "Waterfall tile (%d, %d) must use alpha 128/255" % [x, y]):
					return
			else:
				if not _assert_or_fail(tile_data.z_index <= player_z, "Non-waterfall tile (%d, %d) must not be forced in front of the player" % [x, y]):
					return
				if not _assert_or_fail(is_equal_approx(alpha, 1.0), "Non-waterfall tile (%d, %d) must keep full opacity" % [x, y]):
					return

	print("VALIDATION_PASSED: waterfall z-index and modulation are configured correctly.")
	get_tree().quit(0)
