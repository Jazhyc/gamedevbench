extends Node


const CRACKED_TILE_PROBABILITY := 0.25
const DEFAULT_TILE_PROBABILITY := 1.0


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return

	var source := tile_set.get_source(1)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 1 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var cracked_tiles := {
		Vector2i(0, 3): true,
		Vector2i(1, 3): true,
		Vector2i(0, 4): true,
	}

	var existing_tiles := [
		Vector2i(1, 0),
		Vector2i(2, 0),
		Vector2i(3, 0),
		Vector2i(0, 1),
		Vector2i(1, 1),
		Vector2i(0, 2),
		Vector2i(1, 2),
		Vector2i(0, 3),
		Vector2i(1, 3),
		Vector2i(0, 4),
		Vector2i(0, 0),
		Vector2i(3, 1),
		Vector2i(3, 2),
	]

	for coords in existing_tiles:
		var tile_data: TileData = source.get_tile_data(coords, 0)
		if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for %s" % coords):
			return

		var expected_probability := CRACKED_TILE_PROBABILITY if coords in cracked_tiles else DEFAULT_TILE_PROBABILITY
		if not _assert_or_fail(is_equal_approx(tile_data.probability, expected_probability), "Tile %s must have probability %s" % [coords, expected_probability]):
			return

	print("VALIDATION_PASSED: cracked tile probabilities are configured correctly.")
	get_tree().quit(0)
