extends Node

const TARGET_BG := Color("90a6d7")
const TARGET_BG2 := Color("8da5df")
const TARGET_BG3 := Color("14222e")
const TARGET_BG4 := Color("3c3831")

func _ready():
	validate_environment()

func fail(message: String) -> void:
	print(message)
	get_tree().quit(1)

func assert_close(actual: float, expected: float, tolerance: float, label: String) -> void:
	if abs(actual - expected) > tolerance:
		fail("VALIDATION_FAILED: %s expected %.3f but was %.3f" % [label, expected, actual])

func colors_close(a: Color, b: Color, tolerance: float) -> bool:
	return (
		abs(a.r - b.r) <= tolerance and
		abs(a.g - b.g) <= tolerance and
		abs(a.b - b.b) <= tolerance
	)

func validate_environment():
	var main := get_node_or_null("Main")
	if main == null:
		fail("VALIDATION_FAILED: Main node missing")
		return

	var world_env: WorldEnvironment = main.get_node_or_null("WorldEnvironment")
	if world_env == null:
		fail("VALIDATION_FAILED: WorldEnvironment node missing")
		return

	var env: Environment = world_env.environment
	if env == null:
		fail("VALIDATION_FAILED: WorldEnvironment lacks Environment resource")
		return

	if env.background_mode != Environment.BG_SKY:
		fail("VALIDATION_FAILED: Background mode must be SKY")
		return

	var sky = env.sky
	if sky == null:
		fail("VALIDATION_FAILED: Environment must have a Sky resource")
		return
		
	var sky_mat = sky.sky_material as ProceduralSkyMaterial
	if sky_mat == null:
		fail("VALIDATION_FAILED: Sky must use ProceduralSkyMaterial")
		return
	
	if not abs(sky_mat.energy_multiplier - 0.5) < 0.01:
		fail("VALIDATION_FAILED: Sky must have correct energy multiplier")
		return

	if not colors_close(sky_mat.sky_horizon_color, TARGET_BG2, 0.02):
		fail("VALIDATION_FAILED: Sky horizon color incorrect (%s)" % sky_mat.sky_horizon_color)
		return
	if not colors_close(sky_mat.sky_top_color, TARGET_BG, 0.02):
		fail("VALIDATION_FAILED: Sky horizon color incorrect (%s)" % sky_mat.sky_horizon_color)
		return
	if not colors_close(sky_mat.ground_bottom_color, TARGET_BG3, 0.02):
		fail("VALIDATION_FAILED: Ground bottom color incorrect (%s)" % sky_mat.sky_horizon_color)
		return
	if not colors_close(sky_mat.ground_horizon_color, TARGET_BG4, 0.02):
		fail("VALIDATION_FAILED: Ground horizon color incorrect (%s)" % sky_mat.sky_horizon_color)
		return

	if env.tonemap_mode != Environment.TONE_MAPPER_ACES:
		fail("VALIDATION_FAILED: Tonemap must be ACES")
		return

	if not env.ssr_enabled:
		fail("VALIDATION_FAILED: SSR must be enabled")
		return
	if env.ssr_max_steps < 128:
		fail("VALIDATION_FAILED: SSR max steps must be 128")
		return
	assert_close(env.ssr_depth_tolerance, 0.51, 0.01, "SSR depth tolerance")

	if not env.ssao_enabled:
		fail("VALIDATION_FAILED: SSAO must be enabled")
		return
	assert_close(env.ssao_intensity, 5.54, 0.05, "SSAO intensity")

	if not env.sdfgi_enabled:
		fail("VALIDATION_FAILED: SDFGI must be enabled")
		return
	if env.sdfgi_cascades != 6:
		fail("VALIDATION_FAILED: SDFGI cascades must be 6")
		return
	assert_close(env.sdfgi_min_cell_size, 0.1, 0.01, "SDFGI min cell size")
	assert_close(env.sdfgi_bounce_feedback, 1.44, 0.01, "SDFGI bounce feedback")
	if not env.sdfgi_use_occlusion:
		fail("VALIDATION_FAILED: SDFGI occlusion must be enabled")
		return

	if not env.glow_enabled:
		fail("VALIDATION_FAILED: Glow must be enabled")
		return
	if not env.glow_normalized:
		fail("VALIDATION_FAILED: Glow normalization must be on")
		return
	assert_close(env.glow_intensity, 4.33, 0.01, "Glow intensity")
	assert_close(env.glow_strength, 0.88, 0.01, "Glow strength")
	assert_close(env.glow_bloom, 0.05, 0.01, "Glow bloom")
	if env.glow_blend_mode != Environment.GLOW_BLEND_MODE_SCREEN:
		fail("VALIDATION_FAILED: Glow blend mode must be Screen")
		return
	if env.glow_map == null:
		fail("VALIDATION_FAILED: Glow map texture missing")
		return
	if not env.glow_map.resource_path.ends_with("LensDirtTexture.png"):
		fail("VALIDATION_FAILED: Glow map must use LensDirtTexture.png")
		return

	print("VALIDATION_PASSED: Gritty environment configured correctly")
	get_tree().quit(0)
