extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _assert_direction_entries_in_resource() -> bool:
	var file := FileAccess.open("res://assets/tile_set.tres", FileAccess.READ)
	if not _assert_or_fail(file != null, "Could not read res://assets/tile_set.tres"):
		return false

	var text := file.get_as_text()
	if not _assert_or_fail(text.count("/custom_data_1 =") == 4, "Only the 4 arrow sign tiles should have an explicit direction value set"):
		return false

	var expected_lines := [
		"4:4/0/custom_data_1 = Vector2i(-1, 0)",
		"5:4/0/custom_data_1 = Vector2i(1, 0)",
		"7:4/0/custom_data_1 = Vector2i(-1, 0)",
		"8:4/0/custom_data_1 = Vector2i(1, 0)",
	]
	for line in expected_lines:
		if not _assert_or_fail(text.contains(line), "Direction entry missing from tile_set.tres: %s" % line):
			return false

	if not _assert_or_fail(not text.contains("6:4/0/custom_data_1 ="), "The empty sign should rely on the default Vector2i.ZERO direction"):
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is TileMap, "TileMap node missing under Main"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap must have a TileSet assigned"):
		return

	if not _assert_or_fail(tile_set.get_custom_data_layers_count() >= 2, "TileSet must define at least 2 custom data layers"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(0) == "isSign", "The first custom data layer must be named isSign"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(0) == TYPE_BOOL, "The isSign custom data layer must be a boolean layer"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(1) == "direction", "The second custom data layer must be named direction"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(1) == TYPE_VECTOR2I, "The direction custom data layer must be a Vector2i layer"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var sign_tiles := {
		Vector2i(4, 4): true,
		Vector2i(5, 4): true,
		Vector2i(6, 4): true,
		Vector2i(7, 4): true,
		Vector2i(8, 4): true,
	}
	var expected_directions := {
		Vector2i(4, 4): Vector2i.LEFT,
		Vector2i(5, 4): Vector2i.RIGHT,
		Vector2i(6, 4): Vector2i.ZERO,
		Vector2i(7, 4): Vector2i.LEFT,
		Vector2i(8, 4): Vector2i.RIGHT,
	}

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var is_sign_value: Variant = tile_data.get_custom_data("isSign")
			if coords in sign_tiles:
				if not _assert_or_fail(is_sign_value == true, "Sign tile (%d, %d) must have isSign set to true" % [x, y]):
					return
				if not _assert_or_fail(tile_data.get_custom_data("direction") == expected_directions[coords], "Sign tile (%d, %d) has the wrong direction value" % [x, y]):
					return
			else:
				if not _assert_or_fail(is_sign_value == false, "Non-sign tile (%d, %d) must have isSign set to false" % [x, y]):
					return

	if not _assert_direction_entries_in_resource():
		return

	print("VALIDATION_PASSED: sign custom data layers are configured correctly.")
	get_tree().quit(0)
