# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0193`
- Emission shape: `point` (`ParticleProcessMaterial.emission_shape = 0`)
- Core properties: `z_index = 90`, `amount = 12`, `lifetime = 4.0`, `spread = 20.0`
- Velocity range: `initial_velocity_min = 12.0`, `initial_velocity_max = 18.0`
- Angular velocity range: `angular_velocity_min = 5.0`, `angular_velocity_max = 15.0`
- Scale range: `scale_min = 0.08`, `scale_max = 0.14`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: emission shape point.
