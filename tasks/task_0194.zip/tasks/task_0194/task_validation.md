# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0194`
- Emission shape: `sphere` (`ParticleProcessMaterial.emission_shape = 1`)
- Core properties: `z_index = 91`, `amount = 16`, `lifetime = 5.0`, `spread = 110.0`
- Velocity range: `initial_velocity_min = 18.0`, `initial_velocity_max = 26.0`
- Angular velocity range: `angular_velocity_min = 10.0`, `angular_velocity_max = 20.0`
- Scale range: `scale_min = 0.09`, `scale_max = 0.17`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: `emission_sphere_radius = 96.0`.
