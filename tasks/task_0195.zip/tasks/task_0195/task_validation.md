# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0195`
- Emission shape: `sphere surface` (`ParticleProcessMaterial.emission_shape = 2`)
- Core properties: `z_index = 92`, `amount = 18`, `lifetime = 5.5`, `spread = 140.0`
- Velocity range: `initial_velocity_min = 22.0`, `initial_velocity_max = 32.0`
- Angular velocity range: `angular_velocity_min = 15.0`, `angular_velocity_max = 25.0`
- Scale range: `scale_min = 0.1`, `scale_max = 0.18`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: `emission_sphere_radius = 140.0`.
