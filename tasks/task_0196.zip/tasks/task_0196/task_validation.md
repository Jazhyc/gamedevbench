# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0196`
- Emission shape: `box` (`ParticleProcessMaterial.emission_shape = 3`)
- Core properties: `z_index = 99`, `amount = 20`, `lifetime = 6.0`, `spread = 180.0`
- Velocity range: `initial_velocity_min = 20.0`, `initial_velocity_max = 30.0`
- Angular velocity range: `angular_velocity_min = 20.0`, `angular_velocity_max = 40.0`
- Scale range: `scale_min = 0.1`, `scale_max = 0.2`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: `emission_box_extents.x = 320.0`.
