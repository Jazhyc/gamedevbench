# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0197`
- Emission shape: `points` (`ParticleProcessMaterial.emission_shape = 4`)
- Core properties: `z_index = 93`, `amount = 14`, `lifetime = 4.5`, `spread = 75.0`
- Velocity range: `initial_velocity_min = 14.0`, `initial_velocity_max = 24.0`
- Angular velocity range: `angular_velocity_min = 8.0`, `angular_velocity_max = 28.0`
- Scale range: `scale_min = 0.06`, `scale_max = 0.12`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: emission shape points.
