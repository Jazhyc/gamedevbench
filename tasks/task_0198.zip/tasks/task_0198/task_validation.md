# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0198`
- Emission shape: `directed points` (`ParticleProcessMaterial.emission_shape = 5`)
- Core properties: `z_index = 94`, `amount = 15`, `lifetime = 4.8`, `spread = 45.0`
- Velocity range: `initial_velocity_min = 26.0`, `initial_velocity_max = 36.0`
- Angular velocity range: `angular_velocity_min = 12.0`, `angular_velocity_max = 22.0`
- Scale range: `scale_min = 0.07`, `scale_max = 0.13`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: emission shape directed points.
