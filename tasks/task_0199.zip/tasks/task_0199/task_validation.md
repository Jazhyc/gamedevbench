# Variant Summary

- Base task: `task_0192`
- Variant task: `task_0199`
- Emission shape: `ring` (`ParticleProcessMaterial.emission_shape = 6`)
- Core properties: `z_index = 95`, `amount = 22`, `lifetime = 5.2`, `spread = 160.0`
- Velocity range: `initial_velocity_min = 16.0`, `initial_velocity_max = 28.0`
- Angular velocity range: `angular_velocity_min = 18.0`, `angular_velocity_max = 30.0`
- Scale range: `scale_min = 0.09`, `scale_max = 0.16`
- Alpha check: material color alpha must be between `0` and `1`
- Shape-specific setting: `emission_ring_radius = 150.0`.
