# Variant Summary

- Base task: `task_0200`
- Variant task: `task_0201`
- Additional requirements: move `Trap` to `Vector2(320, 180)` and scale it to `Vector2(4, 4)`
- Marker requirements remain the same: add `SpawningPoints`, create `SpawnTop` and `SpawnBot`, place them near the spike tips, and set `SpawnBot.z_index = 1`
