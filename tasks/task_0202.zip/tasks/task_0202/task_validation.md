# Variant Summary

- Base task: `task_0200`
- Variant task: `task_0202`
- Trap and sprite transforms are already in place in the starting scene
- Solver work: add `SpawningPoints`, create `SpawnTop` and `SpawnBot`, align them with the rotated spike tips, and set `SpawnBot.z_index = 1`
