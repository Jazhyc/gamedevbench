# Variant Summary

- Base task: `task_0200`
- Variant task: `task_0203`
- Trap and sprite transforms are already in place in the starting scene
- Solver work: add `SpawningPoints`, create `SpawnTop` and `SpawnBot`, align them with the 5th spike from the left and the 6th spike from the right, and set `SpawnBot.z_index = 1`
