# Variant Summary

- Base task: `task_0200`
- Variant task: `task_0204`
- Trap and sprite transforms are already in place in the starting scene
- Solver work: add `SpawningPoints`, create `SpawnTop` and `SpawnBot`, align one marker with the bottom tip of the branch closest to the water and the other with the rightmost bottom tip of the trunk, and set `SpawnBot.z_index = 1`
