# Variant Summary

- Base task: `task_0204`
- Variant task: `task_0207`
- Additional requirement already present in the starting scene: `Trap.scale = Vector2(1.8, 1.8)`
- Solver work: add `SpawningPoints`, create `SpawnTop` and `SpawnBot`, align one marker with the bottom tip of the branch closest to the water and the other with the rightmost bottom tip of the trunk, and set `SpawnBot.z_index = 1`
