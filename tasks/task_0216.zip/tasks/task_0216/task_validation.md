# Variant Summary

- Base idea: place visible overlays by eye on top of image features rather than matching a single point
- Variant task: `task_0216`
- Scene setup: the platformer image is anchored from the top-left under `Level`, and six semi-transparent circular `Polygon2D` highlights are placed very tightly over the yellow star coins
- Intended next step: adjust the guessed circle positions in the editor, then freeze that as GT and follow the usual solved-to-unsolved pipeline
