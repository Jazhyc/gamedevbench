# Variant Summary

- Base task: `task_0216`
- Variant task: `task_0218`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.scale = Vector2(0.65, 0.65)`
- Solver work: add `CoinHighlights`, create six semi-transparent circular `Polygon2D` nodes, and place them tightly over the yellow star coins
