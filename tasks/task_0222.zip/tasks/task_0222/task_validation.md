# Variant Summary

- Base task: `task_0217`
- Variant task: `task_0222`
- Scene setup: `Level` is scaled to `Vector2(0.55, 0.55)` and rotated to `0.37` radians
- Current scene includes initial circular highlights so they can be refined in the editor before freezing GT
