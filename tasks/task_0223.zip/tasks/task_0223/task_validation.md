# Variant Summary

- Base task: `task_0218`
- Variant task: `task_0223`
- Scene setup: `Level` is scaled to `Vector2(0.65, 0.65)` and rotated to `-0.43` radians
- Current scene includes initial circular highlights so they can be refined in the editor before freezing GT
