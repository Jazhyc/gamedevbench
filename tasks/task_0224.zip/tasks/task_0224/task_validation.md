# Variant Summary

- Base task: `task_0219`
- Variant task: `task_0224`
- Scene setup: `Level` is scaled to `Vector2(0.75, 0.75)` and rotated to `0.22` radians
- Current scene includes initial circular highlights so they can be refined in the editor before freezing GT
