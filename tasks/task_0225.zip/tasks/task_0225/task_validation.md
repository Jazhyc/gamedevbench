# Variant Summary

- Base task: `task_0220`
- Variant task: `task_0225`
- Scene setup: `Level` is scaled to `Vector2(0.85, 0.85)` and rotated to `-0.11` radians
- Current scene includes initial circular highlights so they can be refined in the editor before freezing GT
