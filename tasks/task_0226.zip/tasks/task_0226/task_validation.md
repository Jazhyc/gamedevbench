# Variant Summary

- Base task: `task_0221`
- Variant task: `task_0226`
- Scene setup: `Level` is scaled to `Vector2(0.95, 0.95)` and rotated to `0.04` radians
- Current scene includes initial circular highlights so they can be refined in the editor before freezing GT
