# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0229`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(182.04, 28.342)`, `Level.scale = Vector2(0.6, 0.6)`, and `Level.rotation = 0.08`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
