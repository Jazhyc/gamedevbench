# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0231`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(184.431, 4.461)`, `Level.scale = Vector2(0.61, 0.61)`, and `Level.rotation = 0.12`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
