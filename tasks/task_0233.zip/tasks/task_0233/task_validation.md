# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0233`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(213.586, 3.171)`, `Level.scale = Vector2(0.59, 0.59)`, and `Level.rotation = 0.15`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
