# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0237`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(115.625, 61.995)`, `Level.scale = Vector2(0.64, 0.64)`, and `Level.rotation = -0.03`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
