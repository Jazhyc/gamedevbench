# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0243`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(176.049, 108.474)`, `Level.scale = Vector2(0.56, 0.56)`, and `Level.rotation = -0.05`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
