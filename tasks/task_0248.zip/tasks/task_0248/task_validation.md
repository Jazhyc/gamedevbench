# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0248`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(118.631, 56.766)`, `Level.scale = Vector2(0.64, 0.64)`, and `Level.rotation = -0.02`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
