extends CharacterBody2D

var _target: Node2D
var _target_path: NodePath

@export var target: Node2D:
	set(value):
		if value is Node2D:
			_target = value
			_target_path = value.get_path()
		elif value is NodePath:
			_target_path = value
			_target = get_node_or_null(value) as Node2D
	get:
		return _target

var speed: float = 300.0
var acceleration: float = 7.0

@onready var navigation_agent: NavigationAgent2D = $Navigation/NavigationAgent2D

func _ready() -> void:
	if _target == null and not _target_path.is_empty():
		_target = get_node_or_null(_target_path) as Node2D

func _physics_process(delta: float) -> void:
	var direction = Vector2.ZERO

	direction = navigation_agent.get_next_path_position() - global_position
	direction = direction.normalized()

	velocity = velocity.lerp(direction * speed, acceleration * delta)

	move_and_slide()

func _on_timer_timeout() -> void:
	if target == null:
		return

	navigation_agent.target_position = target.global_position
