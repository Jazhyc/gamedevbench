extends CharacterBody2D

@export var beacon: Node2D

var speed: float = 300.0
var acceleration: float = 7.0

@onready var navigation_agent: NavigationAgent2D = $Navigation/NavigationAgent2D

func _physics_process(delta: float) -> void:
	var direction = Vector2.ZERO

	direction = navigation_agent.get_next_path_position() - global_position
	direction = direction.normalized()

	velocity = velocity.lerp(direction * speed, acceleration * delta)

	move_and_slide()

func _on_timer_timeout() -> void:
	if beacon == null:
		return

	navigation_agent.target_position = beacon.global_position
