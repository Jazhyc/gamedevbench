extends CharacterBody2D

@export var target: Node2D

var speed := 300.0
var acceleration := 7.0

@onready var navigation_agent: NavigationAgent2D = $Navigation/NavigationAgent2D

func _ready() -> void:
	if target == null:
		target = get_node_or_null("../Target") as Node2D

func _physics_process(delta: float) -> void:
	var direction := navigation_agent.get_next_path_position() - global_position
	direction = direction.normalized()

	velocity = velocity.lerp(direction * speed, acceleration * delta)

	move_and_slide()

func _on_timer_timeout() -> void:
	if target == null:
		return

	navigation_agent.target_position = target.global_position
