extends Node

func _ready() -> void:
	var project_scene_path: String = ProjectSettings.get_setting("application/run/main_scene", "")
	if project_scene_path.is_empty():
		return

	var project_scene_resource: Variant = load(project_scene_path)
	if project_scene_resource is PackedScene:
		var project_scene: PackedScene = project_scene_resource
		var project_root: Node = project_scene.instantiate()
		project_root.name = "ProjectRoot"
		add_child(project_root)
