extends Node2D
class_name Weapon

enum STATES { READY, FIRING, RELOADING }

signal reload_progress_changed(progress: float)
signal reload_finished

@export var BULLET_SCENE: PackedScene

@onready var reload_timer = $ReloadTimer

var can_fire: bool
var state: STATES = STATES.READY

func _ready():
	change_state(STATES.READY)
	set_process(false)
	reload_progress_changed.emit(1.0)


func change_state(new_state: STATES):
	state = new_state


func _process(_delta):
	if state != STATES.RELOADING:
		return

	var progress := 1.0 - (reload_timer.time_left / reload_timer.wait_time)
	reload_progress_changed.emit(clampf(progress, 0.0, 1.0))


func fire():
	if state == STATES.FIRING || state == STATES.RELOADING:
		return
	
	change_state(STATES.FIRING)
	# Create a bullet at our position and set it's direction
	var bullet = BULLET_SCENE.instantiate()
	bullet.direction = Vector2.from_angle(global_rotation)
	bullet.global_position = global_position
	# Add the bullet to the root scene tree so translation is in world space
	get_tree().root.add_child(bullet)
	# Set our state to reload and start our reloading timer
	change_state(STATES.RELOADING)
	reload_timer.start()
	reload_progress_changed.emit(0.0)
	set_process(true)
	

func _on_reload_timer_timeout():
	change_state(STATES.READY)
	set_process(false)
	reload_progress_changed.emit(1.0)
	reload_finished.emit()
