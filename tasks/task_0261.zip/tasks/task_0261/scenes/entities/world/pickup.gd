extends Area2D
class_name Pickup

signal collected(points: int)

const SCORE_VALUE := 60

func _ready() -> void:
	add_to_group("pickup")


func _on_body_entered(body):
	if body is Tank:
		body.collect_pickup(SCORE_VALUE)
		collected.emit(SCORE_VALUE)
		queue_free()
