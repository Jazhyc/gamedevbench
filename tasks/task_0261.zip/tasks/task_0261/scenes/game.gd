extends Node2D

@export var hero_tank: Tank
@export var scoreboard: UI

var _score := 0

func _ready() -> void:
	if hero_tank == null:
		hero_tank = get_node_or_null("Tank") as Tank
	if scoreboard == null:
		scoreboard = get_node_or_null("UI") as UI
	if hero_tank == null or scoreboard == null or hero_tank.weapon == null:
		return

	_set_score(0)
	_set_reload_progress(1.0)
	if not hero_tank.pickup_collected.is_connected(_on_pickup_collected):
		hero_tank.pickup_collected.connect(_on_pickup_collected)
	if not hero_tank.weapon.reload_progress_changed.is_connected(_on_reload_progress_changed):
		hero_tank.weapon.reload_progress_changed.connect(_on_reload_progress_changed)
	if not hero_tank.weapon.reload_finished.is_connected(_on_reload_finished):
		hero_tank.weapon.reload_finished.connect(_on_reload_finished)


func _on_pickup_collected(points: int) -> void:
	_set_score(_score + points)


func _on_reload_progress_changed(progress: float) -> void:
	_set_reload_progress(progress)


func _on_reload_finished() -> void:
	_set_reload_progress(1.0)


func _set_score(value: int) -> void:
	_score = value
	if scoreboard != null:
		scoreboard.set_score(_score)
		var score_label := scoreboard.get_node_or_null("%Score") as Label
		if score_label != null:
			score_label.text = str(_score)


func _set_reload_progress(value: float) -> void:
	if scoreboard != null:
		scoreboard.set_reload_progress(value)
		var reload_bar := scoreboard.get_node_or_null("%ReloadProgress") as TextureProgressBar
		if reload_bar != null:
			reload_bar.value = clampf(value, reload_bar.min_value, reload_bar.max_value)
