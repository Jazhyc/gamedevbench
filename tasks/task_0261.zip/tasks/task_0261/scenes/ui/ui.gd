extends CanvasLayer
class_name UI

@onready var score: Label = %Score
@onready var reload_progress: TextureProgressBar = %ReloadProgress

var _score_value := 0

func _ready() -> void:
	set_score(_score_value)
	set_reload_progress(1.0)


func set_score(value: int) -> void:
	_score_value = value
	score.text = str(_score_value)


func add_score(points: int) -> void:
	set_score(_score_value + points)


func set_reload_progress(value: float) -> void:
	reload_progress.value = clampf(value, reload_progress.min_value, reload_progress.max_value)
