extends Node

var has_failed := false

func _ready() -> void:
	_run_validation()

func _run_validation() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	if scene == null:
		return _fail("Missing res://scenes/main.tscn")
	var main_scene: Node = scene.instantiate()
	add_child(main_scene)
	var campfire: Node = main_scene.get_node_or_null("Campfire")
	if campfire == null:
		return _fail("Campfire node missing under Main")
	_check_base_sprite(campfire)
	if has_failed:
		return
	var smoke: GPUParticles2D = campfire.get_node_or_null("SmokeStylized")
	if smoke == null:
		return _fail("Campfire must contain a GPUParticles2D named SmokeStylized")
	_check_smoke_node(smoke)
	if has_failed:
		return
	_check_smoke_material(smoke)
	if has_failed:
		return
	_pass("Stylized smoke trails configured correctly")

func _check_base_sprite(campfire: Node) -> void:
	var base_sprite: Sprite2D = campfire.get_node_or_null("CampfireBase")
	if base_sprite == null:
		return _fail("CampfireBase Sprite2D missing")
	var tex := base_sprite.texture
	if tex == null:
		return _fail("CampfireBase must display the campfire_base texture")
	if not tex.resource_path.ends_with("campfire_base.png"):
		return _fail("CampfireBase should use assets/campfire_base.png")

func _check_smoke_node(smoke: GPUParticles2D) -> void:
	if smoke.texture == null or not smoke.texture.resource_path.ends_with("smokelet.png"):
		return _fail("SmokeStylized must use the smokelet texture for long streaks")
	if smoke.amount < 14:
		return _fail("SmokeStylized should emit at least 14 particles")
	if smoke.lifetime < 16.0:
		return _fail("SmokeStylized lifetime must be 16.0 seconds or longer")
	if smoke.preprocess < 22.0:
		return _fail("SmokeStylized preprocess should be around 22.0 seconds so trails start filled")
	if not smoke.trail_enabled:
		return _fail("Enable trails on SmokeStylized")
	if smoke.trail_lifetime < 5.5:
		return _fail("Smoke trails must live for about 5.5 seconds")
	if smoke.trail_sections < 36 or smoke.trail_section_subdivisions < 36:
		return _fail("Smoke trails should use 36 sections and 36 subdivisions for smooth ribbons")

func _check_smoke_material(smoke: GPUParticles2D) -> void:
	var mat: ParticleProcessMaterial = smoke.process_material
	if mat == null:
		return _fail("SmokeStylized requires its own ParticleProcessMaterial")
	if not mat.direction.normalized().is_equal_approx(Vector3(0.05, -1, 0.0).normalized()):
		return _fail("Smoke direction must be (0.05,-1,0)")
	if mat.initial_velocity_min < 35.0 or mat.initial_velocity_max < 55.0:
		return _fail("Smoke velocities must be in the 35-55 range")
	if mat.directional_velocity_min > -9.5 or mat.directional_velocity_max < 9.5:
		return _fail("Smoke needs -10 to 10 directional sway")
	if not mat.gravity.is_equal_approx(Vector3.ZERO):
		return _fail("Smoke gravity should be zero so trails drift up")
	if mat.scale_max < 3.42:
		return _fail("Smoke should grow up to roughly 3.5x its start size")
	var scale_curve := mat.scale_curve
	if scale_curve == null or not scale_curve is CurveTexture:
		return _fail("Smoke scale must be driven by a CurveTexture")
	var embedded_curve: Curve = scale_curve.curve
	if embedded_curve.sample(1.0) <= embedded_curve.sample(0.0):
		return _fail("Smoke scale curve must grow over time")
	var grad := mat.color_ramp
	if grad == null or not grad is GradientTexture1D:
		return _fail("Smoke color must use a GradientTexture that warms near the fire and fades out")
	var gradient: Gradient = grad.gradient
	if gradient == null or gradient.get_point_count() < 3:
		return _fail("Gradient should include at least three colors (orange, gray, transparent)")
	var first_color: Color = gradient.get_color(0)
	var last_color: Color = gradient.get_color(gradient.get_point_count() - 1)
	if first_color.r < first_color.g + 0.05 or first_color.r < first_color.b + 0.05:
		return _fail("First gradient color should be warmer (more red/orange)")
	if last_color.a > 0.15:
		return _fail("Last gradient color must fade to transparent")
	var dir_curve := mat.directional_velocity_curve
	if dir_curve == null or not dir_curve is CurveXYZTexture:
		return _fail("Directional velocity must use a CurveXYZTexture for sideways sway")
	var sway_curve: Curve = dir_curve.curve_x
	if sway_curve == null or sway_curve.get_point_count() < 3:
		return _fail("Directional sway curve should define multiple offsets for left/right motion")

func _fail(message: String) -> void:
	has_failed = true
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func _pass(message: String) -> void:
	print("VALIDATION_PASSED: %s" % message)
	get_tree().quit()
