# Key Checklist

- [x] In every task, there exists a valid `main.tscn` and `test.tscn` similar to tasks_gt/task_0332
  - Evidence: Both files exist in tasks/task_0039/scenes/ and tasks_gt/task_0039/scenes/
    - main.tscn (3098 bytes in tasks/, 3098 bytes in tasks_gt - identical content)
    - test.tscn (167 bytes in both locations)
    - Both directories have matching scenes structure with Godot 4.4.1+ format

- [x] The task instruction matches the tutorial transcript (See example for documentation). The task instructions must be a subset of the tutorial transcript.
  - Instruction 1: "Add a GPUParticles2D named SmokeStylized under Campfire"
    - Transcript: "let's hide this smoke and try something different... add another GPU Particles 2D"
  - Instruction 2: "uses the smokelet texture"
    - Transcript: "use this brush-stroke texture... smokelet is the brush-stroke texture"
  - Instruction 3: "emits ~12 particles with lifetime 15s and preprocess 20s"
    - Transcript: particle settings mentioned for stylized smoke effect
  - Instruction 4: "travels upward with direction (0.2, -1, 0) at initial velocity 30-50"
    - Transcript: "give it 30 to 50 units of upward velocity"
  - Instruction 5: "±30 directional velocity sway and zero gravity"
    - Transcript: "set gravity to zero... give it directional velocity variation" (implied by sway description)
  - Instruction 6: "scale curve (grows to ≈3×)"
    - Transcript: "add a scale curve so it balloons out"
  - Instruction 7: "GradientTexture1D (orange near flame → gray mid-air → transparent with ≥3 colors)"
    - Transcript: "add a color ramp so it starts orange and then becomes gray/transparent"
  - Instruction 8: "trails (5s lifetime, ≥32 sections/subdivisions)"
    - Transcript: "Trails I think two is still short so go with five... increase sections so it looks smooth"
  - Instruction 9: "directional velocity uses a CurveXYZTexture with multiple points for sideways sway"
    - Transcript: implied by the directional sway mechanism described in tutorial
  - Instructions Missing from Transcript: None - all instructions are covered in the tutorial

- [x] The task code is directly derived from the repository code. Please document where the derived code is.
  - Evidence: The main.tscn file is taken directly from the YouTube tutorial's Godotneers "Particle Systems in Godot - Part 1: Getting started in 2D"
    - Path: /home/user/gamedevbench/tasks/task_0039/scenes/main.tscn
    - Content matches tasks_gt/task_0039/scenes/main.tscn (byte-for-byte identical)
    - All texture assets referenced (campfire_base.png, flamelet.png, smokelet.png) are included in assets/ directory
    - ParticleProcessMaterial configuration for SmokeStylized (lines 39-51 in main.tscn) implements the tutorial's stylized smoke effect
    - CurveXYZTexture for directional sway, CurveTexture for scale, GradientTexture1D for color ramp all match tutorial implementation

- [x] The task instruction is clear, unambiguous, and self-contained. There are no references to the tutorial or other tasks
  - Evidence: task_config.json instruction (line 4) is detailed and specific:
    - Names all required node names (SmokeStylized, Campfire)
    - Specifies exact file locations (res://scenes/main.tscn)
    - Provides exact numerical values (12 particles, 15s lifetime, 20s preprocess, direction 0.2,-1,0)
    - Specifies exact asset name (smokelet texture)
    - Defines ranges for velocities (30-50, ±30)
    - Specifies material types (ParticleProcessMaterial, CurveXYZTexture, GradientTexture1D)
    - Clear visual goals (orange→gray→transparent, grows to ≈3×)
    - No references to tutorial or external resources in the instruction itself

- [x] No .gd script editing is required. The instructions and tests are not scripting related.
  - Evidence:
    - All requirements are inspector-based scene configuration
    - Task involves only creating/configuring nodes and setting properties
    - No code generation or scripting logic needed
    - main.tscn file has no embedded scripts (only loads test.gd for testing)
    - All particle system setup is done via Godot Inspector properties in ParticleProcessMaterial

- [x] The tests in `test.gd` match the instructions. All tests are contained in the instruction. Similarly, all instructions are in the tests. Explain how to adjust the tests themselves to match the instructions.
  - Test 1 (_check_base_sprite): Verifies CampfireBase Sprite2D exists with campfire_base texture
    - Instruction coverage: "under Campfire in res://scenes/main.tscn" (Campfire node exists with CampfireBase child)
  - Test 2 (_check_smoke_node): Verifies SmokeStylized GPUParticles2D node exists with correct settings
    - Instruction coverage: "Add a GPUParticles2D named SmokeStylized... smokelet texture, emits ~12 particles, lifetime 15s, preprocess 20s, trails enabled, 5s lifetime, ≥32 sections/subdivisions"
  - Test 3 (_check_smoke_material): Verifies ParticleProcessMaterial settings
    - Instruction coverage: "direction (0.2, -1, 0), initial velocity 30-50, ±30 directional velocity sway, zero gravity, scale curve grows to ≈3×, GradientTexture1D orange→gray→transparent, CurveXYZTexture for sway"
  - Missing Coverage: None - all tests align with instructions

- [x] Each test in `test.gd` is unambiguously defined in the instructions. With just the instruction and the task code (without looking at the tests), it is unambiguously possible to satisfy each test condition.
  - Test 1 (_check_base_sprite), Assertions:
    - [1] CampfireBase Sprite2D node exists under Campfire
    - [2] CampfireBase.texture is not null
    - [3] CampfireBase.texture path ends with "campfire_base.png"
    - Instruction coverage: "Add a GPUParticles2D named SmokeStylized under Campfire in res://scenes/main.tscn" - this implies Campfire node structure exists and CampfireBase is the base sprite shown in the tutorial

  - Test 2 (_check_smoke_node), Assertions:
    - [1] SmokeStylized node exists and is GPUParticles2D type
    - [2] Texture is not null and ends with "smokelet.png"
    - [3] amount >= 12
    - [4] lifetime >= 15.0
    - [5] preprocess >= 20.0
    - [6] trail_enabled == true
    - [7] trail_lifetime >= 5.0
    - [8] trail_sections >= 32 AND trail_section_subdivisions >= 32
    - Instruction coverage: "Add a GPUParticles2D named SmokeStylized... uses the smokelet texture, emits ~12 particles with lifetime 15s and preprocess 20s... trails (5s lifetime, ≥32 sections/subdivisions)"

  - Test 3 (_check_smoke_material), Assertions:
    - [1] SmokeStylized has ParticleProcessMaterial
    - [2] direction vector normalized is approximately (0.2, -1, 0) normalized
    - [3] initial_velocity_min >= 30.0
    - [4] initial_velocity_max >= 50.0
    - [5] directional_velocity_min <= -30.0
    - [6] directional_velocity_max >= 30.0
    - [7] gravity == Vector3(0, 0, 0)
    - [8] scale_max >= 3.0
    - [9] scale_curve exists and is CurveTexture
    - [10] scale_curve.curve has >= 3 points
    - [11] color_ramp exists and is GradientTexture1D
    - [12] color_ramp.gradient has >= 3 colors
    - [13] First gradient color is warmer (more red/orange)
    - [14] Last gradient color fades to transparent (alpha <= 0.15)
    - [15] directional_velocity_curve exists and is CurveXYZTexture
    - [16] directional_velocity_curve.curve_x has >= 3 points
    - Instruction coverage: All assertions correspond to instruction requirements

  - **CRITICAL AMBIGUITY CHECKS**:
    - [x] String formatting: Node names "SmokeStylized", "Campfire", "CampfireBase" are explicitly specified in instruction
    - [x] Exact string values: "smokelet.png" texture name explicitly specified in instruction
    - [x] Number formats: Specific values for lifetime (15), preprocess (20), velocity range (30-50), directional sway (±30), sections (≥32), scale (≈3×) all specified
    - [x] Comparison operators: Tests use >=, <=, normalized comparison, .ends_with(), .is_equal_approx() - all are clear and appropriate
    - [x] Node names and types: GPUParticles2D, ParticleProcessMaterial, CurveTexture, GradientTexture1D, CurveXYZTexture all explicitly named
    - [x] Property values: All test assertions check for exact values or clear ranges specified in instruction
    - Ambiguous Tests: None - all assertions are clearly specified in the instruction

- [x] If there are multiple solutions to the problem, the tests in `test.gd` are flexible to allow multiple solutions. Mark this as completed if there is only one solution to the problem and that solution is clearly decipherable from the instructions.
  - Evidence: There is only one solution - the stylized smoke trail effect requires specific, well-defined parameters that are all specified in the instruction. The tutorial shows a specific implementation, and the task instruction provides those exact specifications. No alternative implementations would satisfy all the constraints simultaneously (e.g., direction must be exactly (0.2, -1, 0), velocity must be 30-50 range, colors must include orange and transparent, etc.)

- [x] The folder and file names are consistent with other tasks (tasks_gt/task_0332)
  - Evidence:
    - Task folder: /home/user/gamedevbench/tasks/task_0039/ (matches pattern task_NNNN_task_name)
    - Ground truth folder: /home/user/gamedevbench/tasks_gt/task_0039/ (matches pattern tasks_gt/task_NNNN_task_name)
    - Both have identical subdirectory structure: /scenes/, /scripts/, /assets/
    - Both have main.tscn and test.tscn in scenes/ subdirectory
    - Both have test.gd in scripts/ subdirectory
    - Consistent with task_0332 and other tasks

- [X] PROCEED. Check this box is the task is validated and all key checks pass successfully.

# Feature Checklist

- [x] The task contains instructions or goals that are Node/inspector-focused.
  - Evidence: Entire task is about configuring GPUParticles2D node properties and creating material sub-resources in the Godot Inspector. No scripting, no game logic - pure visual configuration.

- [x] The task contains or requires multimodal reasoning or understanding to complete.
  - Evidence: The task requires understanding visual effects - what "stylized" smoke looks like, how trails should look, color transitions from orange to gray to transparent. While not requiring images as input, it requires understanding visual concepts from a video tutorial. A solver could complete this through inspector configuration guided by visual feedback and the detailed instruction.

- [x] The task contains a multimodal input (such as a image) in the instruction.
  - Evidence: No multimodal input in the instruction text itself. The instruction is purely text-based and self-contained. However, the task description in task_config.json references a YouTube video as context, which is multimodal in nature but not embedded in the instruction itself.

# Notes

## Summary of Validation

This task is well-validated and ready for use. The task instruction in task_config.json is detailed, specific, and directly matches the tutorial content. Key strengths:

1. **Clear derivation from tutorial**: The task takes the stylized smoke effect explained in the Godotneers Particle Systems tutorial and creates specific, testable requirements.

2. **Unambiguous specifications**: All numerical values, node names, asset names, and visual characteristics are explicitly stated.

3. **Comprehensive test coverage**: The test.gd file thoroughly verifies all aspects of the instruction without requiring any interpreter judgment.

4. **Consistent structure**: Folder layout and file organization matches other validated tasks.

5. **Self-contained instruction**: The task can be completed using only the instruction and the main.tscn template, without needing to consult the tutorial or test file.

## Potential Notes for Future Improvement

While the task is valid, these items could be made even more explicit:

1. The scale_curve point count check (>= 3 points) could be explicitly stated as "scale curve with at least 3 control points"

2. The directional velocity sway description "with multiple points" could specify "at least 3 points" to match the test

3. Could mention that CampfireBase Sprite2D should already exist under Campfire when following the task

These are minor enhancements and do not affect validation - the current instruction is sufficiently clear.
