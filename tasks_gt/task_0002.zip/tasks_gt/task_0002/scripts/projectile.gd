extends Area2D

@export var speed := 600.0
const QUEST_ID := "shoot_em_up"
const STEP_ID := "kill_step"

func _physics_process(delta):
	position += Vector2(0, -speed) * delta
	if position.y < -50:
		queue_free()

func _on_area_entered(area):
	if area.is_in_group("enemy"):
		QuestManager.progress_quest(QUEST_ID, STEP_ID)
		area.queue_free()
		queue_free()
