class_name BattleUnit
extends Area2D

@export var display_name := "Bjorn"
@onready var skin: Sprite2D = $Skin
@onready var animation_player: AnimationPlayer = $AnimationPlayer

func play_idle() -> void:
	if animation_player.has_animation("idle"):
		animation_player.play("idle")
