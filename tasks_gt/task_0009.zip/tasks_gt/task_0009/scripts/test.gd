extends Node

func _ready() -> void:
	run_validation()

func fail(reason: String) -> void:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)

func is_red(color: Color) -> bool:
	return color.r > 0.8 and color.g < 0.3

func is_white(color: Color) -> bool:
	return color.r > 0.9 and color.g > 0.9 and color.b > 0.9

func is_orange(color: Color) -> bool:
	return color.r > 0.9 and color.g > 0.4 and color.g < 0.8 and color.b < 0.4

func run_validation() -> void:
	var main: Node = get_node_or_null("Main")
	if not main:
		fail("Main node missing")
		return

	var platform: Node = main.get_node_or_null("UnsafePlatform")
	if platform == null:
		fail("UnsafePlatform instance missing")
		return

	var area: Area2D = platform.get_node_or_null("Area2D")
	if area == null:
		fail("Area2D node missing on unsafe platform")
		return

	var anim_player: AnimationPlayer = platform.get_node_or_null("AnimationPlayer")
	if anim_player == null:
		fail("AnimationPlayer missing on unsafe platform")
		return

	if anim_player.autoplay != "UnsafeCycle":
		fail("AnimationPlayer must autoplay UnsafeCycle")
		return

	if not anim_player.has_animation("UnsafeCycle"):
		fail("UnsafeCycle animation not found")
		return

	var anim: Animation = anim_player.get_animation("UnsafeCycle")
	if anim == null:
		fail("Unable to load UnsafeCycle animation")
		return

	var color_track := -1
	var process_track := -1

	for track_idx in anim.get_track_count():
		var track_path: NodePath = anim.track_get_path(track_idx)
		if track_path == NodePath("Area2D:modulate"):
			color_track = track_idx
		elif track_path == NodePath("Area2D:process_mode"):
			process_track = track_idx

	if color_track == -1:
		fail("UnsafeCycle must animate Area2D.modulate")
		return

	if process_track == -1:
		fail("UnsafeCycle must toggle Area2D.process_mode")
		return

	var key_count: int = anim.track_get_key_count(color_track)
	if key_count < 3:
		fail("Color track must include at least three keyframes")
		return

	var has_white := false
	var has_orange := false
	var red_times: Array = []
	var non_red_times: Array = []

	for key_idx in key_count:
		var value: Variant = anim.track_get_key_value(color_track, key_idx)
		var time: float = anim.track_get_key_time(color_track, key_idx)
		if value is Color:
			if is_red(value):
				red_times.append(time)
			else:
				non_red_times.append(time)

			if is_white(value):
				has_white = true
			if is_orange(value):
				has_orange = true

	if not has_white:
		fail("Color track must include a calm white keyframe")
		return

	if not has_orange:
		fail("Color track must include a brighter orange keyframe")
		return

	if red_times.is_empty():
		fail("Color track must include a red warning keyframe")
		return

	var disables_found := false
	for key_idx in anim.track_get_key_count(process_track):
		var value: Variant = anim.track_get_key_value(process_track, key_idx)
		if value == Node.PROCESS_MODE_DISABLED:
			disables_found = true

	if not disables_found:
		fail("Process track must disable the Area2D during danger phase")
		return

	var red_start: float = red_times[0]
	var red_end: float = red_times[0]
	for time in red_times:
		red_start = min(red_start, time)
		red_end = max(red_end, time)

	var red_sample: float = (red_start + red_end) * 0.5
	var epsilon: float = min(0.05, anim.length * 0.01)

	anim_player.stop()
	anim_player.play("UnsafeCycle")
	await get_tree().process_frame
	anim_player.advance(red_sample + epsilon)
	await get_tree().process_frame
	if area.process_mode != Node.PROCESS_MODE_DISABLED:
		fail("Area2D should be disabled while the animation is red")
		return

	var non_red_time := -1.0
	if non_red_times.size() > 0:
		non_red_time = non_red_times[0]
	elif red_start > 0.0:
		non_red_time = 0.0
	elif anim.length > red_end:
		non_red_time = anim.length

	if non_red_time < 0.0:
		fail("Unable to find a non-red keyframe for re-enable validation")
		return

	anim_player.stop()
	anim_player.play("UnsafeCycle")
	await get_tree().process_frame
	anim_player.advance(non_red_time + epsilon)
	await get_tree().process_frame
	if area.process_mode == Node.PROCESS_MODE_DISABLED:
		fail("Area2D should re-enable outside the danger window")
		return

	print("VALIDATION_PASSED: Unsafe platform flashes colors and disables safety in sync")
	get_tree().quit()