extends Node3D

@export var Skeleton: NodePath
@export var ChestBone: NodePath
@export var HeadIKSolver: NodePath
@export var ChestTargetPoint: NodePath
@export var ChestTargetContainer: NodePath
@export var HeadTargetContainer: NodePath
@export var EnemyBody: NodePath
@export var LimbRaycast: NodePath
@export var CurrentLimbs: Array[NodePath] = []
@export var TargetOffsetDown: float = 2.5
@export var ShoulderBodyWidth: float = 0.5
@export var BottomBodyWidth: float = 2.0
