extends Control
## Simplified version of Bonkahe's menu handler used for structural tasks.

@export var LaunchMenu: Control
@export var PauseMenu: Control
@export var DeathMenu: Control

@export var PlayerNode: Node3D
@export var LevelCamera: Camera3D
@export var TransitionMaterial: ShaderMaterial
@export var TransitionTime: float = 2.0

var _is_playing: bool = false

func _ready() -> void:
	if LaunchMenu:
		LaunchMenu.visible = true
	if PauseMenu:
		PauseMenu.visible = false
	if DeathMenu:
		DeathMenu.visible = false
	if PlayerNode:
		PlayerNode.visible = false
	if LevelCamera:
		LevelCamera.current = true
	get_tree().paused = true
	TweenOutTrans()

func ToggleFullScreen() -> void:
	var mode := DisplayServer.window_get_mode()
	if mode != DisplayServer.WINDOW_MODE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func BeginLaunch() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if LaunchMenu:
		LaunchMenu.visible = false
	TweenInTrans(FinishLaunch)

func FinishLaunch() -> void:
	if PlayerNode:
		PlayerNode.visible = true
	if LevelCamera:
		LevelCamera.current = false
	get_tree().paused = false
	_is_playing = true
	TweenOutTrans()

func TogglePauseMenu() -> void:
	if PauseMenu and PauseMenu.visible:
		HidePauseMenu()
	else:
		ShowPauseMenu()

func ShowPauseMenu() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if PauseMenu:
		PauseMenu.visible = true
	get_tree().paused = true

func HidePauseMenu() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if PauseMenu:
		PauseMenu.visible = false
	get_tree().paused = false

func ShowDeathMenu(camera_location: Vector3 = Vector3.ZERO, camera_rotation: Vector3 = Vector3.ZERO) -> void:
	if DeathMenu:
		DeathMenu.visible = true
	if LevelCamera:
		LevelCamera.global_position = camera_location
		LevelCamera.global_rotation = camera_rotation
		LevelCamera.current = true
	if PlayerNode:
		PlayerNode.visible = false
	TweenOutTrans()
	get_tree().paused = false
	_is_playing = false

func RestartLevel() -> void:
	get_tree().reload_current_scene()

func ExitGame() -> void:
	TweenInTrans(func(): get_tree().quit())

func TweenInTrans(completion_callable: Callable = Callable()) -> void:
	var tween := create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_method(SetTransitionValue, 0.0, 3.0, TransitionTime)
	if completion_callable.is_valid():
		tween.tween_callback(completion_callable)

func TweenOutTrans(completion_callable: Callable = Callable()) -> void:
	var tween := create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_method(SetTransitionValue, 3.0, 0.0, TransitionTime)
	if completion_callable.is_valid():
		tween.tween_callback(completion_callable)

func SetTransitionValue(value: float) -> void:
	if TransitionMaterial:
		TransitionMaterial.set_shader_parameter("EffectStrength", value)
