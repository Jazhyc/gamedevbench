extends Node

func _ready() -> void:
	_validate_structure()

func fail(reason: String) -> void:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)

func _validate_structure() -> void:
	var packed: PackedScene = load("res://scenes/menus.tscn")
	if not packed:
		fail("Unable to load res://scenes/menus.tscn")
		return
	var menus: Control = packed.instantiate()
	add_child(menus)
	if not menus.get_script() or String(menus.get_script().resource_path) != "res://scripts/menu_handler.gd":
		fail("Menus scene must use scripts/menu_handler.gd")
		return
	if menus.process_mode != Node.PROCESS_MODE_ALWAYS:
		fail("Menus root must process while paused")
		return
	if menus.anchor_right != 1 or menus.anchor_bottom != 1:
		fail("Menus root must stretch to viewport")
		return

	var launch_panel: Panel = _require_panel(menus, "LaunchMenu", Vector2(-205, -196), Vector2(205, 196))
	var pause_panel: Panel = _require_panel(menus, "PauseMenu", Vector2(-205, -196), Vector2(205, 45))
	var restart_panel: Panel = _require_panel(menus, "RestartMenu", Vector2(-205, -196), Vector2(205, 63))
	if not launch_panel or not pause_panel or not restart_panel:
		return

	launch_panel.visible = launch_panel.visible # access to avoid warnings
	if not _validate_launch_menu(launch_panel):
		return
	if not _validate_pause_menu(pause_panel):
		return
	if not _validate_restart_menu(restart_panel):
		return

	var canvas_layer: CanvasLayer = menus.get_node_or_null("CanvasLayer")
	if not canvas_layer:
		fail("Missing CanvasLayer for transition overlay")
		return
	if canvas_layer.layer != 2:
		fail("CanvasLayer must render on layer 2")
		return
	var overlay: ColorRect = canvas_layer.get_node_or_null("TransitionOverlay")
	if not overlay:
		fail("Missing TransitionOverlay ColorRect")
		return
	if overlay.anchor_right != 1 or overlay.anchor_bottom != 1:
		fail("Transition overlay must stretch across the viewport")
		return
	if overlay.mouse_filter != Control.MOUSE_FILTER_IGNORE:
		fail("Transition overlay must ignore mouse input")
		return
	if not overlay.material:
		fail("Transition overlay requires a ShaderMaterial")
		return
	var material_path := String(overlay.material.resource_path)
	if not material_path.ends_with("menu_overlay_material.tres"):
		fail("Transition overlay must use menu_overlay_material.tres")
		return

	if not _check_handler_exports(menus, launch_panel, pause_panel, restart_panel, overlay.material):
		return

	print("VALIDATION_PASSED: Menu prefab matches tutorial structure")
	get_tree().quit()

func _require_panel(menus: Control, node_name: String, expected_top_left: Vector2, expected_bottom_right: Vector2) -> Panel:
	var panel: Panel = menus.get_node_or_null(node_name)
	if not panel:
		fail("Missing %s panel" % node_name)
		return null
	if not (panel.anchor_left == 0.5 and panel.anchor_top == 0.5 and panel.anchor_right == 0.5 and panel.anchor_bottom == 0.5):
		fail("%s must stay centered with 0.5 anchors" % node_name)
		return null
	if panel.offset_left != expected_top_left.x or panel.offset_top != expected_top_left.y:
		fail("%s must keep the expected top-left offset" % node_name)
		return null
	if panel.offset_right != expected_bottom_right.x or panel.offset_bottom != expected_bottom_right.y:
		fail("%s must keep the expected bottom-right offset" % node_name)
		return null
	return panel

func _validate_launch_menu(panel: Panel) -> bool:
	var box: VBoxContainer = panel.get_node_or_null("VBoxContainer")
	if not box:
		fail("LaunchMenu requires a VBoxContainer for buttons")
		return false
	if box.anchor_right != 1 or box.anchor_bottom != 1:
		fail("Launch VBox must stretch to panel margins")
		return false
	var title: Label = box.get_node_or_null("Label")
	var subtitle: Label = box.get_node_or_null("Label2")
	if not title or not subtitle:
		fail("Launch menu titles missing")
		return false
	if title.text.strip_edges() != "FPS Horror":
		fail("Launch title must read 'FPS Horror'")
		return false
	if subtitle.text.strip_edges() != "By Bonkahe":
		fail("Launch subtitle must read 'By Bonkahe'")
		return false
	var full_button: Button = box.get_node_or_null("FullScreenButton")
	var play_button: Button = box.get_node_or_null("PlayButton")
	var quit_button: Button = box.get_node_or_null("QuitButton")
	if not full_button or not play_button or not quit_button:
		fail("Launch menu buttons missing")
		return false
	if play_button.text.strip_edges() != "Play":
		fail("Play button text mismatch")
		return false
	if quit_button.text.strip_edges() != "Quit":
		fail("Launch quit button text mismatch")
		return false
	if not full_button.is_connected("pressed", Callable(panel.get_parent(), "ToggleFullScreen")):
		fail("FullScreenButton must call ToggleFullScreen")
		return false
	if not play_button.is_connected("pressed", Callable(panel.get_parent(), "BeginLaunch")):
		fail("PlayButton must call BeginLaunch")
		return false
	if not quit_button.is_connected("pressed", Callable(panel.get_parent(), "ExitGame")):
		fail("Launch QuitButton must call ExitGame")
		return false
	return true

func _validate_pause_menu(panel: Panel) -> bool:
	var title: Label = panel.get_node_or_null("VBoxContainer/Label")
	if not title:
		fail("Pause menu missing title")
		return false
	if title.text.strip_edges() != "Paused":
		fail("Pause title must read 'Paused'")
		return false
	var resume_btn: Button = panel.get_node_or_null("VBoxContainer/ResumeButton")
	var quit_btn: Button = panel.get_node_or_null("VBoxContainer/QuitButton")
	if not resume_btn or not quit_btn:
		fail("Pause buttons missing")
		return false
	if resume_btn.text.strip_edges() != "Resume":
		fail("Resume button text mismatch")
		return false
	if quit_btn.text.strip_edges() != "Quit":
		fail("Pause quit text mismatch")
		return false
	if not resume_btn.is_connected("pressed", Callable(panel.get_parent(), "HidePauseMenu")):
		fail("Resume button must hide pause menu")
		return false
	if not quit_btn.is_connected("pressed", Callable(panel.get_parent(), "ExitGame")):
		fail("Pause quit button must exit game")
		return false
	return true

func _validate_restart_menu(panel: Panel) -> bool:
	var title: Label = panel.get_node_or_null("VBoxContainer/Label")
	if not title:
		fail("Restart menu missing title")
		return false
	if title.text.strip_edges() != "You Died":
		fail("Restart menu title must read 'You Died'")
		return false
	var restart_btn: Button = panel.get_node_or_null("VBoxContainer/RestartButton")
	var quit_btn: Button = panel.get_node_or_null("VBoxContainer/QuitButton")
	if not restart_btn or not quit_btn:
		fail("Restart buttons missing")
		return false
	if restart_btn.text.strip_edges() != "Restart":
		fail("Restart button text mismatch")
		return false
	if quit_btn.text.strip_edges() != "Quit":
		fail("Restart quit text mismatch")
		return false
	if not restart_btn.is_connected("pressed", Callable(panel.get_parent(), "RestartLevel")):
		fail("Restart button must call RestartLevel")
		return false
	if not quit_btn.is_connected("pressed", Callable(panel.get_parent(), "ExitGame")):
		fail("Restart quit button must call ExitGame")
		return false
	return true

func _check_handler_exports(menus: Control, launch_panel: Panel, pause_panel: Panel, restart_panel: Panel, transition_material: Material) -> bool:
	var launch_ref = menus.LaunchMenu
	var pause_ref = menus.PauseMenu
	var death_ref = menus.DeathMenu
	if _resolve_node(menus, launch_ref) != launch_panel:
		fail("LaunchMenu export must target the LaunchMenu panel")
		return false
	if _resolve_node(menus, pause_ref) != pause_panel:
		fail("PauseMenu export must target the PauseMenu panel")
		return false
	if _resolve_node(menus, death_ref) != restart_panel:
		fail("DeathMenu export must target RestartMenu")
		return false
	if menus.TransitionMaterial != transition_material:
		fail("TransitionMaterial export must reference the overlay material")
		return false
	return true

func _resolve_node(owner: Node, value) -> Node:
	if value is Node:
		return value
	if value is NodePath:
		return owner.get_node_or_null(value)
	return null
