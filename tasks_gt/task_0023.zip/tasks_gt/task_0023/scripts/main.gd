extends Node2D

var total_damage := 0
@onready var damage_label := get_node_or_null("HUD/DamageLabel")

func _ready():
    if damage_label:
        damage_label.text = "Total Damage: 0"

func _on_player_taken_damage(amount: int) -> void:
    total_damage += amount
    if damage_label:
        damage_label.text = "Total Damage: %d" % total_damage
