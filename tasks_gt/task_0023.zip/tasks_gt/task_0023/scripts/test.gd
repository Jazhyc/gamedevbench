extends Node

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func run_validation():
    var main_node = get_node_or_null("Main")
    if not main_node or not main_node is Node2D:
        fail("Main scene must exist as a Node2D root")
        return

    var player = main_node.get_node_or_null("Player")
    if not player or not player is CharacterBody2D:
        fail("Player CharacterBody2D is missing under Main")
        return

    var hud = main_node.get_node_or_null("HUD")
    if not hud or not hud is CanvasLayer:
        fail("Add a CanvasLayer named HUD to host damage UI")
        return

    var damage_label = hud.get_node_or_null("DamageLabel")
    if not damage_label or not damage_label is Label:
        fail("HUD must contain a Label named DamageLabel")
        return

    if damage_label.text != "Total Damage: 0":
        fail("DamageLabel should start at 'Total Damage: 0'")
        return

    var target_callable := Callable(main_node, "_on_player_taken_damage")
    if not player.is_connected("taken_damage", target_callable):
        fail("Connect Player.taken_damage to Main._on_player_taken_damage")
        return

    player.take_damage()

    if main_node.total_damage != 20:
        fail("Main.total_damage should track the emitted 20 damage")
        return

    if damage_label.text != "Total Damage: 20":
        fail("DamageLabel text must update after receiving the signal")
        return

    print("VALIDATION_PASSED: Player damage signal updates the HUD")
    get_tree().quit(0)
