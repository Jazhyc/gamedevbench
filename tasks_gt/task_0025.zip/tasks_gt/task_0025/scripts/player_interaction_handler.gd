extends Area3D
class_name PlayerInteractionHandler

signal item_picked_up(item_data: ItemData)

@export var item_types: Array[ItemData] = []
var nearby_bodies: Array[InteractableItem] = []

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("interact"):
		pickup_nearest_item()

func pickup_nearest_item() -> void:
	var nearest: InteractableItem = null
	var nearest_distance := INF
	for body in nearby_bodies:
		var distance := body.global_position.distance_to(global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest = body
	if nearest == null:
		return
	nearby_bodies.erase(nearest)
	var scene_path := nearest.scene_file_path
	nearest.queue_free()
	var matched_data := _find_item_data(scene_path)
	if matched_data:
		print("Picked up %s" % matched_data.item_name)
		item_picked_up.emit(matched_data)
	else:
		push_warning("Item type not found for scene %s" % scene_path)

func _find_item_data(scene_path: String) -> ItemData:
	for item_data in item_types:
		if item_data and item_data.item_model_prefab and item_data.item_model_prefab.resource_path == scene_path:
			return item_data
	return null

func _on_body_entered(body: Node3D) -> void:
	if body is InteractableItem:
		body.gain_focus()
		if not nearby_bodies.has(body):
			nearby_bodies.append(body)

func _on_body_exited(body: Node3D) -> void:
	if body is InteractableItem and nearby_bodies.has(body):
		body.lose_focus()
		nearby_bodies.erase(body)
