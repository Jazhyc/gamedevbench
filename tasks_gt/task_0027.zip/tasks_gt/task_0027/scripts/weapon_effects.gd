extends Node3D

signal on_shot_camera_impulse(impulse_direction: Vector3, shot_camera_impulse: float)

@export var barrel_end: Node3D
@export var barrel_ray_cast: RayCast3D
@export var camera_shake_power: float = 0.3

func fire_weapon() -> void:
    if barrel_ray_cast == null:
        return
    var direction := -barrel_ray_cast.global_transform.basis.z
    if direction.length() == 0.0:
        return
    direction = direction.normalized()
    emit_signal("on_shot_camera_impulse", direction, camera_shake_power)
    _spawn_debug_flash()

func _spawn_debug_flash() -> void:
    if barrel_end == null:
        return
    var flash := Node3D.new()
    flash.name = "DebugFlash"
    barrel_end.add_child(flash)
    flash.global_position = barrel_end.global_position
    flash.call_deferred("queue_free")
