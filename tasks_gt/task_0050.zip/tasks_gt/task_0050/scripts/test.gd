extends Node

const TILE = 64

func _ready() -> void:
	await get_tree().process_frame
	run_validation()

func run_validation() -> void:
	var main = get_node_or_null("Main")
	if not main:
		return _fail("VALIDATION_FAILED: Main scene missing")
	var player = main.get_node_or_null("Player")
	if not player:
		return _fail("VALIDATION_FAILED: Player instance missing")

	if not _has_property(player, "animation_speed"):
		return _fail("VALIDATION_FAILED: Declare animation_speed on Player")
	var animation_speed: Variant = player.get("animation_speed")
	if typeof(animation_speed) not in [TYPE_FLOAT, TYPE_INT]:
		return _fail("VALIDATION_FAILED: animation_speed must be numeric")
	if float(animation_speed) <= 0.0:
		return _fail("VALIDATION_FAILED: animation_speed must be positive")

	if not _has_property(player, "moving"):
		return _fail("VALIDATION_FAILED: Declare the moving flag on Player")

	if not _has_property(player, "ray"):
		return _fail("VALIDATION_FAILED: Cache the RayCast2d via @onready var ray = $RayCast2d")
	var ray = player.get("ray") as RayCast2D
	if ray == null:
		return _fail("VALIDATION_FAILED: ray property must reference the RayCast2d node")

	var script_text = player.get_script().source_code
	if not script_text.find("force_raycast_update") >= 0:
		return _fail("VALIDATION_FAILED: move() must call ray.force_raycast_update() before checking collisions")
	if not script_text.find("create_tween") >= 0:
		return _fail("VALIDATION_FAILED: move() must create a Tween for smooth movement")
	if not script_text.find("await tween.finished") >= 0:
		return _fail("VALIDATION_FAILED: Tween must be awaited before clearing the moving flag")

	# Guard clause check
	player.set("moving", true)
	var guard_event := InputEventAction.new()
	guard_event.action = "right"
	guard_event.pressed = true
	var start_pos = player.position
	player._unhandled_input(guard_event)
	await get_tree().process_frame
	if player.position != start_pos:
		return _fail("VALIDATION_FAILED: Player moved even though moving flag was true")
	player.set("moving", false)

	# Blocked move should not advance
	var blocker := _create_blocker(main, player.global_position + Vector2(TILE, 0))
	await get_tree().process_frame
	var before_block = player.position
	player.move("right")
	if ray.target_position != Vector2(TILE, 0):
		return _fail("VALIDATION_FAILED: RayCast2d target_position must track the requested direction")
	await get_tree().process_frame
	if player.position != before_block:
		return _fail("VALIDATION_FAILED: Player should not cross the blocking wall to the right")
	blocker.queue_free()

	# Successful move animates and finishes at the correct tile
	var open_start = player.position
	player.move("down")
	await get_tree().process_frame
	if not player.get("moving"):
		return _fail("VALIDATION_FAILED: moving flag must stay true during the tween")
	var anim := player.get_node("AnimationPlayer") as AnimationPlayer
	if anim.current_animation != "down":
		return _fail("VALIDATION_FAILED: AnimationPlayer must play the matching direction")
	await get_tree().create_timer(1.0 / float(animation_speed) + 0.05).timeout
	if player.position != open_start + Vector2(0, TILE):
		return _fail("VALIDATION_FAILED: Tween must land exactly one tile in the requested direction")
	if player.get("moving"):
		return _fail("VALIDATION_FAILED: moving flag must reset after the tween finishes")

	print("VALIDATION_PASSED: Tweened grid movement with collision gating is implemented")
	get_tree().quit(0)

func _has_property(node: Object, prop_name: String) -> bool:
	for prop in node.get_property_list():
		if prop.name == prop_name:
			return true
	return false

func _fail(message: String) -> void:
	print(message)
	get_tree().quit(1)

func _create_blocker(parent: Node, global_position: Vector2) -> StaticBody2D:
	var blocker := StaticBody2D.new()
	blocker.collision_layer = 1
	blocker.collision_mask = 1
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(TILE, TILE)
	shape.shape = rect
	blocker.add_child(shape)
	parent.add_child(blocker)
	blocker.global_position = global_position
	return blocker
