extends Area2D
class_name Crate

signal removed

var minimap_icon := "alert"

func trigger_removal():
	removed.emit(self)
	queue_free()
