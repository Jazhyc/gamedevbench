extends Node2D

@onready var minimap: Node = $CanvasLayer/Minimap
@onready var player = $Player

func _ready():
	if minimap and minimap.has_method("set_player"):
		minimap.set_player(player)
	elif minimap:
		minimap.player = player

	for obj in get_tree().get_nodes_in_group("minimap_objects"):
		if obj.has_signal("removed"):
			obj.removed.connect(minimap._on_object_removed)
