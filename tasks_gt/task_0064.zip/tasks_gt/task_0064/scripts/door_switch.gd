extends Area2D

class_name DoorSwitch

@onready var door_switch_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var floor_shape: CollisionShape2D = $StaticBody2D/CollisionShape2D
@onready var detector_shape: CollisionShape2D = $CollisionShape2D

var switch_pressed := false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if switch_pressed:
		return
	if not (body is Player):
		return
	switch_pressed = true
	door_switch_sprite.play("button_pressed")
	await door_switch_sprite.animation_finished
	EventController.exit_switch_flipped.emit()
