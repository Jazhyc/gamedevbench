extends Node

func _ready():
	run_validation()

func fail(reason:String) -> int:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)
	return 0

func run_validation():
	var main = get_node_or_null("Main")
	if not main:
		return fail("Main scene is missing")
	var hud = main.get_node_or_null("HUD")
	if not hud or not hud is CanvasLayer:
		return fail("HUD CanvasLayer not found")
	var margin := hud.get_node_or_null("MarginContainer")
	if not margin or not margin is MarginContainer:
		return fail("MarginContainer with HUD labels missing")
	if margin.get_theme_constant("margin_left") != 20:
		return fail("Top margin left padding must be 20")
	if margin.get_theme_constant("margin_top") != 20:
		return fail("Top margin top padding must be 20")
	if margin.get_theme_constant("margin_right") != 20:
		return fail("Top margin right padding must be 20")
	var hbox := margin.get_node_or_null("HBoxContainer")
	if not hbox or not hbox is HBoxContainer:
		return fail("HBoxContainer for labels missing")
	var health_label := hbox.get_node_or_null("Health")
	var score_label := hbox.get_node_or_null("Score")
	if not health_label or not score_label:
		return fail("Health/Score labels missing")
	if health_label.text != "Health: 100":
		return fail("Health label must default to 'Health: 100'")
	if score_label.text != "Score: 0":
		return fail("Score label must default to 'Score: 0'")
	if score_label.size_flags_horizontal != 10:
		return fail("Score label must be right-aligned (size_flags_horizontal=10)")

	print("VALIDATION_PASSED: HUD status bar correctly built")
	get_tree().quit()
