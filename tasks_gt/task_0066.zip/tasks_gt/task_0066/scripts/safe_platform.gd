@tool
extends Node2D

@export var speed: Vector2 = Vector2(32, 0)
@export var rotation_offset: Vector2 = Vector2(256, 0)
@export var tile_offset_amount: Vector2 = Vector2(16, 0)
@export_range(1, 5) var length: int:
	set(value):
		inner_length = max(1, value)
		if is_inside_tree():
			setupLength()
	get:
		return inner_length

var inner_length := 1

func _ready() -> void:
	$AutoMover2D.speed = speed
	$VisibilityOffset2D.offset_amount = rotation_offset
	setupLength()

func _process(_delta: float) -> void:
	if Engine.is_editor_hint():
		setupLength()

func setupLength() -> void:
	var area := $Area2D
	if area == null:
		return

	for child in area.get_children():
		child.queue_free()

	$PlayerMover2D.clearCollisionShapes()

	for item in range(1, length + 1):
		var sprite := $Templates/Sprite2D.duplicate() as Sprite2D
		var shape := $Templates/CollisionShape2D.duplicate() as CollisionShape2D
		var offset := (item - 1) * tile_offset_amount
		sprite.position = offset
		shape.position += offset

		area.add_child(sprite)
		area.add_child(shape)

		$PlayerMover2D.addCollisionShape(shape.duplicate())
