extends Node

const MUSIC_PLAYER_SCENE := "res://global/music_player.tscn"
const SOUND_PLAYER_SCRIPT := "res://global/sound_player.gd"


func _ready() -> void:
	run_validation()


func run_validation() -> void:
	if not ResourceLoader.exists(SOUND_PLAYER_SCRIPT):
		print("VALIDATION_FAILED: sound_player.gd not found")
		get_tree().quit(1)
		return

	if not ResourceLoader.exists(MUSIC_PLAYER_SCENE):
		print("VALIDATION_FAILED: music_player.tscn not found")
		get_tree().quit(1)
		return

	var sound_script: Script = load(SOUND_PLAYER_SCRIPT)
	if not sound_script:
		print("VALIDATION_FAILED: sound_player.gd failed to load")
		get_tree().quit(1)
		return

	var sound_instance = sound_script.new()
	if not (sound_instance is Node):
		print("VALIDATION_FAILED: sound_player.gd must extend Node")
		get_tree().quit(1)
		return

	if not sound_instance.has_method("play"):
		print("VALIDATION_FAILED: sound_player.gd missing play method")
		get_tree().quit(1)
		return

	if not sound_instance.has_method("stop"):
		print("VALIDATION_FAILED: sound_player.gd missing stop method")
		get_tree().quit(1)
		return

	var packed: PackedScene = load(MUSIC_PLAYER_SCENE)
	if not packed:
		print("VALIDATION_FAILED: music_player.tscn failed to load")
		get_tree().quit(1)
		return

	var music_player = packed.instantiate()
	if not (music_player is Node):
		print("VALIDATION_FAILED: MusicPlayer root must be a Node")
		get_tree().quit(1)
		return

	if music_player.name != "MusicPlayer":
		print("VALIDATION_FAILED: MusicPlayer root node must be named MusicPlayer")
		get_tree().quit(1)
		return

	if music_player.process_mode != Node.PROCESS_MODE_ALWAYS:
		print("VALIDATION_FAILED: MusicPlayer process_mode must be Always")
		get_tree().quit(1)
		return

	var script_path := ""
	if music_player.get_script():
		script_path = music_player.get_script().resource_path
	if script_path != SOUND_PLAYER_SCRIPT:
		print("VALIDATION_FAILED: MusicPlayer must use sound_player.gd")
		get_tree().quit(1)
		return

	var audio_players := []
	for child in music_player.get_children():
		if child is AudioStreamPlayer:
			audio_players.append(child)

	if audio_players.size() != 4:
		print("VALIDATION_FAILED: MusicPlayer must have exactly 4 AudioStreamPlayer children")
		get_tree().quit(1)
		return

	for player in audio_players:
		if player.bus != "Music":
			print("VALIDATION_FAILED: AudioStreamPlayer bus must be Music")
			get_tree().quit(1)
			return

	# Add music_player to tree for behavior testing
	add_child(music_player)

	# Test 1: play() should return early when audio is null
	music_player.play(null)
	var any_playing_after_null := false
	for player in audio_players:
		if player.playing:
			any_playing_after_null = true
			break
	if any_playing_after_null:
		print("VALIDATION_FAILED: play() should return early when audio is null")
		get_tree().quit(1)
		return

	# Create a dummy audio stream for testing
	var test_audio := AudioStreamGenerator.new()

	# Test 2: play() should play the first idle AudioStreamPlayer
	music_player.play(test_audio)
	if not audio_players[0].playing:
		print("VALIDATION_FAILED: play() should play the first idle AudioStreamPlayer")
		get_tree().quit(1)
		return

	# Test 3: play() with single=false should use next idle player
	music_player.play(test_audio, false)
	if not audio_players[1].playing:
		print("VALIDATION_FAILED: play() should use next idle AudioStreamPlayer")
		get_tree().quit(1)
		return

	# Test 4: stop() should stop all AudioStreamPlayers
	music_player.stop()
	var any_playing_after_stop := false
	for player in audio_players:
		if player.playing:
			any_playing_after_stop = true
			break
	if any_playing_after_stop:
		print("VALIDATION_FAILED: stop() should stop all AudioStreamPlayers")
		get_tree().quit(1)
		return

	# Test 5: play() with single=true should stop all players first
	music_player.play(test_audio)
	music_player.play(test_audio)
	# Now two players are playing
	music_player.play(test_audio, true)
	# After single=true, only one player should be playing
	var playing_count := 0
	for player in audio_players:
		if player.playing:
			playing_count += 1
	if playing_count != 1:
		print("VALIDATION_FAILED: play() with single=true should stop all players first (expected 1, got " + str(playing_count) + ")")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)
