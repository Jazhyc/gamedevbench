extends Control

func _on_pick_rom_button_pressed() -> void:
	pass

func _on_initial_scenario_button_pressed() -> void:
	pass

func _on_many_marios_button_pressed() -> void:
	pass

func _on_flying_range_button_pressed() -> void:
	pass

func _on_bob_omb_battlefield_button_pressed() -> void:
	pass
