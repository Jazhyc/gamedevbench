extends Node

func _ready() -> void:
	run_validation()

func fail(reason: String) -> void:
	print("VALIDATION_FAILED: %s" % reason)
	get_tree().quit(1)

func run_validation() -> void:
	# Verify rom_picker_dialog.tscn exists
	if not ResourceLoader.exists("res://scenes/rom_picker_dialog.tscn"):
		fail("scenes/rom_picker_dialog.tscn not found")
		return

	var main: Control = get_node_or_null("Main")
	if main == null:
		fail("Main node not found")
		return

	var script: Script = main.get_script()
	if script == null or not script.resource_path.ends_with("scripts/main.gd"):
		fail("Main must have scripts/main.gd attached")
		return

	var rom_dialog: FileDialog = main.get_node_or_null("RomPickerDialog")
	if rom_dialog == null:
		fail("RomPickerDialog instance missing")
		return
	if not rom_dialog.is_unique_name_in_owner():
		fail("RomPickerDialog must be unique_name_in_owner")
		return
	if rom_dialog.visible:
		fail("RomPickerDialog must start hidden")
		return
	if rom_dialog.title != "Pick Super Mario 64 ROM file":
		fail("RomPickerDialog title incorrect")
		return
	if rom_dialog.size != Vector2i(335, 180):
		fail("RomPickerDialog size must be 335x180")
		return
	if rom_dialog.ok_button_text != "Open":
		fail("RomPickerDialog ok_button_text must be Open")
		return
	if rom_dialog.file_mode != FileDialog.FILE_MODE_OPEN_FILE:
		fail("RomPickerDialog file_mode must be open file")
		return
	if rom_dialog.access != FileDialog.ACCESS_FILESYSTEM:
		fail("RomPickerDialog access must be filesystem")
		return
	if not rom_dialog.filters.has("*.n64") or not rom_dialog.filters.has("*.z64"):
		fail("RomPickerDialog filters must include *.n64 and *.z64")
		return

	var invalid_dialog: AcceptDialog = rom_dialog.get_node_or_null("InvalidRomDialog")
	if invalid_dialog == null:
		fail("InvalidRomDialog missing under RomPickerDialog")
		return
	if invalid_dialog.size != Vector2i(378, 100):
		fail("InvalidRomDialog size must be 378x100")
		return
	if invalid_dialog.dialog_text != "Selected file is not a valid Super Mario 64 ROM. File will not be loaded":
		fail("InvalidRomDialog text incorrect")
		return
	if invalid_dialog.dialog_close_on_escape:
		fail("InvalidRomDialog must not close on escape")
		return

	var level_container: Node3D = main.get_node_or_null("LevelContainer")
	if level_container == null:
		fail("LevelContainer Node3D missing")
		return
	if not level_container.is_unique_name_in_owner():
		fail("LevelContainer must be unique_name_in_owner")
		return

	var pick_button: Button = main.get_node_or_null("DemoSelection/PickRomButton")
	var initial_button: Button = main.get_node_or_null("DemoSelection/InitialScenarioButton")
	var many_button: Button = main.get_node_or_null("DemoSelection/ManyMariosButton")
	var flying_button: Button = main.get_node_or_null("DemoSelection/FlyingRangeButton")
	var bob_button: Button = main.get_node_or_null("DemoSelection/BobOmbBattlefieldButton")

	if pick_button == null or initial_button == null or many_button == null or flying_button == null or bob_button == null:
		fail("One or more demo selection buttons are missing")
		return

	if not pick_button.is_connected("pressed", Callable(main, "_on_pick_rom_button_pressed")):
		fail("PickRomButton must connect to _on_pick_rom_button_pressed")
		return
	if not initial_button.is_connected("pressed", Callable(main, "_on_initial_scenario_button_pressed")):
		fail("InitialScenarioButton must connect to _on_initial_scenario_button_pressed")
		return
	if not many_button.is_connected("pressed", Callable(main, "_on_many_marios_button_pressed")):
		fail("ManyMariosButton must connect to _on_many_marios_button_pressed")
		return
	if not flying_button.is_connected("pressed", Callable(main, "_on_flying_range_button_pressed")):
		fail("FlyingRangeButton must connect to _on_flying_range_button_pressed")
		return
	if not bob_button.is_connected("pressed", Callable(main, "_on_bob_omb_battlefield_button_pressed")):
		fail("BobOmbBattlefieldButton must connect to _on_bob_omb_battlefield_button_pressed")
		return

	if not main.has_method("_on_pick_rom_button_pressed"):
		fail("Main script missing _on_pick_rom_button_pressed")
		return
	if not main.has_method("_on_initial_scenario_button_pressed"):
		fail("Main script missing _on_initial_scenario_button_pressed")
		return
	if not main.has_method("_on_many_marios_button_pressed"):
		fail("Main script missing _on_many_marios_button_pressed")
		return
	if not main.has_method("_on_flying_range_button_pressed"):
		fail("Main script missing _on_flying_range_button_pressed")
		return
	if not main.has_method("_on_bob_omb_battlefield_button_pressed"):
		fail("Main script missing _on_bob_omb_battlefield_button_pressed")
		return

	print("VALIDATION_PASSED: ROM dialog, level container, and button connections are configured")
	get_tree().quit(0)
