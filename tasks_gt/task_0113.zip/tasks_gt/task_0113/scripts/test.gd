extends Node

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func _validate_tileset(layer: TileMapLayer) -> void:
    var tile_set = layer.tile_set
    if tile_set == null:
        fail("TileSet missing on %s" % layer.name)
        return
    if tile_set.resource_path == "" or not tile_set.resource_path.ends_with("scenes/arena/tileset.tres"):
        fail("TileSet path incorrect on %s" % layer.name)
        return
    if tile_set.tile_size != Vector2i(32, 32):
        fail("TileSet tile_size must be 32x32")
        return
    var source = tile_set.get_source(0)
    if source == null or not (source is TileSetAtlasSource):
        fail("TileSet atlas source missing")
        return
    if source.texture == null or not source.texture.resource_path.ends_with("assets/sprites/tiles.png"):
        fail("TileSet texture must be tiles.png")
        return

func run_validation() -> void:
    var main_node = get_node_or_null("Main")
    if main_node == null:
        fail("Main scene not found")
        return

    var game_area = main_node.get_node_or_null("GameArea")
    if game_area == null or not (game_area is TileMapLayer):
        fail("GameArea TileMapLayer missing")
        return
    if game_area.position != Vector2(160, 32):
        fail("GameArea position must be (160, 32)")
        return
    _validate_tileset(game_area)

    var decor = game_area.get_node_or_null("Decor")
    if decor == null or not (decor is TileMapLayer):
        fail("Decor TileMapLayer missing")
        return
    _validate_tileset(decor)

    var highlight = game_area.get_node_or_null("Highlight")
    if highlight == null or not (highlight is TileMapLayer):
        fail("Highlight TileMapLayer missing under GameArea")
        return
    _validate_tileset(highlight)
    if highlight.tile_map_data.size() != 0:
        fail("GameArea Highlight layer must be empty")
        return

    var bench = main_node.get_node_or_null("Bench")
    if bench == null or not (bench is TileMapLayer):
        fail("Bench TileMapLayer missing")
        return
    if bench.position != Vector2(160, 320):
        fail("Bench position must be (160, 320)")
        return
    _validate_tileset(bench)

    var bench_highlight = bench.get_node_or_null("Highlight")
    if bench_highlight == null or not (bench_highlight is TileMapLayer):
        fail("Bench Highlight TileMapLayer missing")
        return
    if bench_highlight.position != Vector2(160, 32):
        fail("Bench Highlight position must be (160, 32)")
        return
    _validate_tileset(bench_highlight)
    if bench_highlight.tile_map_data.size() != 0:
        fail("Bench Highlight layer must be empty")
        return

    var expected_game_area := Marshalls.base64_to_raw("AAABAAAAAAACAAwAAAABAAIAAAAAAAwAAAABAAQAAAAAAAwAAAABAAYAAAAAAAwAAAAAAAEAAAAAAAwAAAAAAAMAAAAAAAwAAAAAAAUAAAABAAwAAAACAAEAAAAAAAwAAAACAAMAAAADAAwAAAACAAUAAAAAAAwAAAADAAAAAAAAAAwAAAADAAIAAAAAAAwAAAADAAQAAAAAAAwAAAADAAYAAAAAAAwAAAAEAAEAAAAAAAwAAAAEAAMAAAAAAAwAAAAEAAUAAAAAAAwAAAAFAAAAAAAAAAwAAAAFAAIAAAAAAAwAAAAFAAQAAAAAAAwAAAAFAAYAAAACAAwAAAAGAAEAAAADAAwAAAAGAAMAAAAAAAwAAAAGAAUAAAADAAwAAAAHAAAAAAAAAAwAAAAHAAIAAAAAAAwAAAAHAAQAAAAAAAwAAAAHAAYAAAAAAAwAAAAIAAEAAAAAAAwAAAAIAAMAAAABAAwAAAAIAAUAAAAAAAwAAAAJAAAAAAAAAAwAAAAJAAIAAAAAAAwAAAAJAAQAAAAAAAwAAAAJAAYAAAADAAwAAAA=")
    var expected_decor := Marshalls.base64_to_raw("AAAGAAAAAAABABUAAAAJAAEAAAAAABYAAAAIAAQAAAABABYAAAA=")
    var expected_bench := Marshalls.base64_to_raw("AAAAAAAAAAAAAAsAAAABAAAAAAAAAAcAAAACAAAAAAAAAAsAAAADAAAAAAAAAAcAAAAEAAAAAAAAAAsAAAAFAAAAAAAAAAcAAAAGAAAAAAAAAAsAAAAHAAAAAAAAAAcAAAAIAAAAAAAAAAsAAAAJAAAAAAAAAAcAAAA=")

    if game_area.tile_map_data != expected_game_area:
        fail("GameArea tile_map_data does not match expected layout")
        return
    if decor.tile_map_data != expected_decor:
        fail("Decor tile_map_data does not match expected layout")
        return
    if bench.tile_map_data != expected_bench:
        fail("Bench tile_map_data does not match expected layout")
        return

    print("VALIDATION_PASSED: Task completed successfully")
    get_tree().quit(0)
