extends Node2D

@onready var hurtbox = $HurtboxComponent
@onready var hit_audio = $VariablePitchAudioStreamPlayer

var hurt_sound_played := false

func _ready() -> void:
	hurtbox.hurt.connect(_on_hurt)

func _on_hurt(_hitbox = null) -> void:
	hurt_sound_played = true
	hit_audio.play_with_variance()
