extends Node

func _ready() -> void:
	run_validation()

func run_validation() -> void:
	var main_node := get_node_or_null("Main")
	if main_node == null:
		print("VALIDATION_FAILED: Main node not found")
		get_tree().quit(1)
		return

	var enemy := main_node.get_node_or_null("Enemy")
	if enemy == null:
		print("VALIDATION_FAILED: Enemy node not found")
		get_tree().quit(1)
		return

	var hurtbox := enemy.get_node_or_null("HurtboxComponent")
	if hurtbox == null:
		print("VALIDATION_FAILED: HurtboxComponent missing")
		get_tree().quit(1)
		return
	if not hurtbox is HurtboxComponent:
		print("VALIDATION_FAILED: HurtboxComponent must use HurtboxComponent script")
		get_tree().quit(1)
		return

	var audio := enemy.get_node_or_null("VariablePitchAudioStreamPlayer")
	if audio == null:
		print("VALIDATION_FAILED: VariablePitchAudioStreamPlayer missing")
		get_tree().quit(1)
		return
	if not audio is AudioStreamPlayer:
		print("VALIDATION_FAILED: Audio player must be AudioStreamPlayer")
		get_tree().quit(1)
		return
	if not audio is VariablePitchAudioStreamPlayer:
		print("VALIDATION_FAILED: Audio player must use VariablePitchAudioStreamPlayer script")
		get_tree().quit(1)
		return
	var bus_enemy = AudioServer.get_bus_index("Enemy")
	if bus_enemy < 0:
		print("VALIDATION_FAILED: Audio bus named Enemy does not exist")
		get_tree().quit(1)
		return
	var bus_send = AudioServer.get_bus_send(bus_enemy)
	if bus_send != "Sounds":
		print("VALIDATION_FAILED: Audio bus Enemy should send to Sounds.")
		get_tree().quit(1)
		return
	if audio.stream == null or audio.stream.resource_path != "res://assets/sounds/hit_sound.wav":
		print("VALIDATION_FAILED: Hit sound stream not set")
		get_tree().quit(1)
		return
	if audio.bus != "Enemy":
		print("VALIDATION_FAILED: Audio bus must be Enemy")
		get_tree().quit(1)
		return
	if abs(audio.volume_db - 5.0) > 0.01:
		print("VALIDATION_FAILED: Audio volume_db must be 5.0")
		get_tree().quit(1)
		return

	print("VALIDATION_PASSED: Task completed successfully")
	get_tree().quit(0)
