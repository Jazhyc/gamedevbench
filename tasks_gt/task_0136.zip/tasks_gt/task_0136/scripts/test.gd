extends Node

func _ready():
	var ui_scene: PackedScene = load("res://scenes/ui.tscn")
	if ui_scene == null:
		return _fail("UI scene not found at res://scenes/ui.tscn")

	var ui_instance = ui_scene.instantiate()
	add_child(ui_instance)

	if not ui_instance is CanvasLayer:
		return _fail("UI root must be a CanvasLayer")
	if ui_instance.name != "UI":
		return _fail("CanvasLayer root must be named 'UI'")

	var panel: ColorRect = ui_instance.get_node_or_null("StatusStrip")
	if panel == null:
		return _fail("StatusStrip node missing under UI")
	if panel.anchor_top != 1.0 or panel.anchor_bottom != 1.0:
		return _fail("StatusStrip must be anchored to the bottom (anchor_top & anchor_bottom = 1)")
	if panel.grow_vertical != 0:
		return _fail("StatusStrip should keep the Bottom Wide preset growth behavior")
	if panel.custom_minimum_size.y < 58.0:
		return _fail("StatusStrip should reserve at least 58px height")
	if not _color_close(panel.color, Color(0.6, 0.6, 0.6, 1.0), 0.0):
		return _fail("StatusStrip should use the requested neutral grey")

	var label_a: Label = panel.get_node_or_null("HealthLabel")
	if label_a == null:
		return _fail("HealthLabel missing inside StatusStrip")
	if label_a.text.strip_edges() != "Health: 3":
		return _fail("HealthLabel text should read 'Health: 3'")

	var label_b: Label = panel.get_node_or_null("ScoreLabel")
	if label_b == null:
		return _fail("ScoreLabel missing inside StatusStrip")
	if label_b.text.strip_edges() != "Score: 0":
		return _fail("ScoreLabel text should read 'Score: 0'")

	var power_meter: TextureRect = panel.get_node_or_null("PowerMeter")
	if power_meter == null:
		return _fail("PowerMeter TextureRect missing")
	if not power_meter.texture or not power_meter.texture.resource_path.ends_with("Fuel-Meter.png"):
		return _fail("PowerMeter must use Fuel-Meter.png")
	if power_meter.anchor_left != 0.5 or power_meter.anchor_right != 0.5:
		return _fail("PowerMeter should be centered (anchor_left/right = 0.5)")
	if power_meter.anchor_top != 1.0 or power_meter.anchor_bottom != 1.0:
		return _fail("PowerMeter should hug the bottom (anchor_top/bottom = 1)")

	var power_indicator: TextureRect = panel.get_node_or_null("PowerIndicator")
	if power_indicator == null:
		return _fail("PowerIndicator TextureRect missing")
	if not power_indicator.texture or not power_indicator.texture.resource_path.ends_with("Fuel-Indicator.png"):
		return _fail("PowerIndicator must use Fuel-Indicator.png")
	if power_indicator.size.x <= 0 or power_indicator.size.y <= 0:
		return _fail("PowerIndicator needs non-zero size")

	var overlay: CenterContainer = ui_instance.get_node_or_null("DefeatView")
	if overlay == null:
		return _fail("DefeatView node missing")
	if overlay.visible:
		return _fail("DefeatView should be hidden by default")

	var overlay_rect: ColorRect = overlay.get_node_or_null("ColorRect")
	if overlay_rect == null:
		return _fail("DefeatView must contain a ColorRect background")
	var overlay_label: Label = overlay_rect.get_node_or_null("Label")
	if overlay_label == null:
		return _fail("DefeatView ColorRect must include a Label")
	if overlay_label.text.strip_edges() != "DEFEAT":
		return _fail("Overlay label should read 'DEFEAT'")

	print("VALIDATION_PASSED: bottom preset HUD variant is configured correctly")
	get_tree().quit(0)

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func _color_close(a: Color, b: Color, tolerance: float) -> bool:
	return abs(a.r - b.r) <= tolerance \
		and abs(a.g - b.g) <= tolerance \
		and abs(a.b - b.b) <= tolerance \
		and abs(a.a - b.a) <= tolerance
