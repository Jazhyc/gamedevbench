extends Node

func _ready():
	var ui_scene: PackedScene = load("res://scenes/ui.tscn")
	if ui_scene == null:
		return _fail("UI scene not found at res://scenes/ui.tscn")

	var ui_instance = ui_scene.instantiate()
	add_child(ui_instance)

	if not ui_instance is CanvasLayer:
		return _fail("UI root must be a CanvasLayer")
	if ui_instance.name != "UI":
		return _fail("CanvasLayer root must be named 'UI'")

	var panel: ColorRect = ui_instance.get_node_or_null("StatusPanel")
	if panel == null:
		return _fail("StatusPanel node missing under UI")
	if panel.anchor_left != 1.0 or panel.anchor_right != 1.0:
		return _fail("StatusPanel must be anchored to the right side")
	if panel.grow_horizontal != 0:
		return _fail("StatusPanel should keep the Right Wide preset growth behavior")
	if panel.custom_minimum_size.x < 86.0:
		return _fail("StatusPanel should reserve at least 86px width")
	if panel.color != Color(0.6, 0.6, 0.6, 1.0):
		return _fail("StatusPanel should use the requested neutral grey")

	var label_a: Label = panel.get_node_or_null("HealthLabel")
	if label_a == null or label_a.text.strip_edges() != "Health: 3":
		return _fail("HealthLabel should read 'Health: 3'")
	var label_b: Label = panel.get_node_or_null("ScoreLabel")
	if label_b == null or label_b.text.strip_edges() != "Score: 0":
		return _fail("ScoreLabel should read 'Score: 0'")

	var power_meter: TextureRect = panel.get_node_or_null("PowerMeter")
	if power_meter == null:
		return _fail("PowerMeter TextureRect missing")
	if not power_meter.texture or not power_meter.texture.resource_path.ends_with("Fuel-Meter.png"):
		return _fail("PowerMeter must use Fuel-Meter.png")
	if power_meter.anchor_left != 1.0 or power_meter.anchor_right != 1.0:
		return _fail("PowerMeter should hug the right side")
	if power_meter.anchor_top != 0.5 or power_meter.anchor_bottom != 0.5:
		return _fail("PowerMeter should be centered vertically")
	if power_meter.grow_horizontal != 0:
		return _fail("PowerMeter should keep the Right Wide preset growth behavior")

	var power_indicator: TextureRect = panel.get_node_or_null("PowerIndicator")
	if power_indicator == null or not power_indicator.texture or not power_indicator.texture.resource_path.ends_with("Fuel-Indicator.png"):
		return _fail("PowerIndicator must use Fuel-Indicator.png")

	var overlay: CenterContainer = ui_instance.get_node_or_null("RetryView")
	if overlay == null or overlay.visible:
		return _fail("RetryView should exist and be hidden by default")
	var overlay_rect: ColorRect = overlay.get_node_or_null("ColorRect")
	var overlay_label: Label = overlay_rect.get_node_or_null("Label") if overlay_rect else null
	if overlay_label == null or overlay_label.text.strip_edges() != "RETRY":
		return _fail("Overlay label should read 'RETRY'")

	print("VALIDATION_PASSED: right preset HUD variant is configured correctly")
	get_tree().quit(0)

func _fail(message: String):
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)
