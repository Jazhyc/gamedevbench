class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var bg_style := StyleBoxFlat.new()
	bg_style.bg_color = Color(0, 0, 0, 0.33)
	add_theme_stylebox_override("panel", bg_style)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -34.0
	vbox.offset_top = -34.0
	vbox.offset_right = 34.0
	vbox.offset_bottom = 34.0

	var headline_settings := LabelSettings.new()
	headline_settings.font_size = 27
	label.label_settings = headline_settings
	label.text = 'Triumph!'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var button_size := Vector2(78, 26)
	continue_button.custom_minimum_size = button_size
	restart_button.custom_minimum_size = button_size
	continue_button.text = 'Advance'
	restart_button.text = 'Restart Battle'

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
