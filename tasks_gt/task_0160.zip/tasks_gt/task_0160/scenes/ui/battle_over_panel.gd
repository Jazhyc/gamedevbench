class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var style_override := StyleBoxFlat.new()
	style_override.bg_color = Color(0, 0, 0, 0.37)
	add_theme_stylebox_override("panel", style_override)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -10.0
	vbox.offset_top = -10.0
	vbox.offset_right = 10.0
	vbox.offset_bottom = 10.0

	var result_settings := LabelSettings.new()
	result_settings.font_size = 19
	label.label_settings = result_settings
	label.text = 'Mission Complete'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var button_dimensions := Vector2(48, 16)
	continue_button.custom_minimum_size = button_dimensions
	restart_button.custom_minimum_size = button_dimensions
	continue_button.text = 'Okay'
	restart_button.text = 'Restart'

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
