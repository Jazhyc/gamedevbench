class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var screen_style := StyleBoxFlat.new()
	screen_style.bg_color = Color(0, 0, 0, 0.43)
	add_theme_stylebox_override("panel", screen_style)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -38.0
	vbox.offset_top = -38.0
	vbox.offset_right = 38.0
	vbox.offset_bottom = 38.0

	var result_theme := LabelSettings.new()
	result_theme.font_size = 32
	label.label_settings = result_theme
	label.text = 'You Won This One'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var button_span := Vector2(82, 30)
	continue_button.custom_minimum_size = button_span
	restart_button.custom_minimum_size = button_span
	continue_button.text = 'Keep Going'
	restart_button.text = 'Try Again'

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
