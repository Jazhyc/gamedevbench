class_name BattleOverPanel
extends Panel

enum Type {WIN, LOSE}

@onready var label: Label = %Label
@onready var continue_button: Button = %ContinueButton
@onready var restart_button: Button = %RestartButton
@onready var vbox: VBoxContainer = $VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var drop_style := StyleBoxFlat.new()
	drop_style.bg_color = Color(0, 0, 0, 0.45)
	add_theme_stylebox_override("panel", drop_style)

	vbox.anchor_left = 0.5
	vbox.anchor_top = 0.5
	vbox.anchor_right = 0.5
	vbox.anchor_bottom = 0.5
	vbox.offset_left = -40.0
	vbox.offset_top = -40.0
	vbox.offset_right = 40.0
	vbox.offset_bottom = 40.0

	var victory_settings := LabelSettings.new()
	victory_settings.font_size = 33
	label.label_settings = victory_settings
	label.text = 'Battle Resolved'
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var button_bounds := Vector2(84, 30)
	continue_button.custom_minimum_size = button_bounds
	restart_button.custom_minimum_size = button_bounds
	continue_button.text = 'Onward'
	restart_button.text = 'Restart Match'

	continue_button.pressed.connect(get_tree().quit)
	restart_button.pressed.connect(get_tree().reload_current_scene)
	Events.battle_over_screen_requested.connect(show_screen)


func show_screen(text: String, type: Type) -> void:
	label.text = text
	continue_button.visible = type == Type.WIN
	restart_button.visible = type == Type.LOSE
	show()
	get_tree().paused = true
