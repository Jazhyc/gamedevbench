extends Node


func _ready() -> void:
	run_validation()


func fail(message: String) -> void:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)


func assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		fail(message)
		return false
	return true


func _ensure_action_exists(action_name: String) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)


func _get_animation_frames(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != "CharacterSprite:frame":
			continue

		var frames: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var frame_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if frames.is_empty() or frames[-1] != frame_value:
				frames.append(frame_value)
		return frames

	return []


func _get_animation_property_values(animation_player: AnimationPlayer, animation_name: String, property_path: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != property_path:
			continue

		var values: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			values.append(animation.track_get_key_value(track_idx, key_idx))
		return values

	return []


func _get_animation_method_names(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	var method_names: Array = []
	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_METHOD:
			continue

		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var key_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if key_value is Dictionary and key_value.has("method"):
				method_names.append(String(key_value["method"]))

	return method_names


func run_validation() -> void:
	for action_name: String in ["ui_left", "ui_right", "ui_up", "ui_down", "attack", "jump"]:
		_ensure_action_exists(action_name)

	var player_scene: PackedScene = load("res://scenes/characters/player.tscn")
	if not assert_or_fail(player_scene != null, "player.tscn must load"):
		return

	var player: Node2D = player_scene.instantiate() as Node2D
	if not assert_or_fail(player != null, "player.tscn must instantiate"):
		return
	add_child(player)
	await get_tree().process_frame

	var animation_player: AnimationPlayer = player.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if not assert_or_fail(animation_player != null, "Player must contain AnimationPlayer"):
		return

	var character_sprite: Sprite2D = player.get_node_or_null("CharacterSprite") as Sprite2D
	if not assert_or_fail(character_sprite != null, "Player must contain CharacterSprite"):
		return

	if not assert_or_fail(_get_animation_frames(animation_player, "jab") == [30, 31, 32], "jab animation must use the first 3 valid frames from the 4th row"):
		return
	var jab_monitoring_values: Array = _get_animation_property_values(animation_player, "jab", "DamageEmitter:monitoring")
	if not assert_or_fail(not jab_monitoring_values.is_empty() and jab_monitoring_values[0] == true and jab_monitoring_values[-1] == false, "jab animation must enable DamageEmitter monitoring during the jab and disable it when the jab ends"):
		return
	if not assert_or_fail("on_action_complete" in _get_animation_method_names(animation_player, "jab"), "jab animation must call on_action_complete when it finishes"):
		return
	if not assert_or_fail(animation_player.has_animation("punch"), "Player must preserve the existing punch animation"):
		return
	var damage_emitter: Area2D = player.get_node_or_null("DamageEmitter") as Area2D
	if not assert_or_fail(damage_emitter != null, "Player must contain DamageEmitter"):
		return

	Input.action_press("attack")
	await get_tree().process_frame
	Input.action_release("attack")
	await get_tree().process_frame
	if not assert_or_fail(animation_player.current_animation == "jab", "Pressing attack while idle must trigger the jab animation"):
		return
	if not assert_or_fail(damage_emitter.monitoring == true, "Jab must enable DamageEmitter monitoring while the attack is active"):
		return
	if not assert_or_fail(is_zero_approx(character_sprite.position.y), "Jab must remain a grounded attack"):
		return

	var monitoring_disabled := false
	for _i: int in range(120):
		await get_tree().create_timer(0.01).timeout
		if damage_emitter.monitoring == false:
			monitoring_disabled = true
			break
	if not assert_or_fail(monitoring_disabled, "Jab must disable DamageEmitter monitoring again after the attack finishes"):
		return

	player.queue_free()
	await get_tree().process_frame

	player = player_scene.instantiate() as Node2D
	if not assert_or_fail(player != null, "player.tscn must instantiate for the punch test"):
		return
	add_child(player)
	await get_tree().process_frame
	animation_player = player.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if not assert_or_fail(animation_player != null, "Player must contain AnimationPlayer for the punch test"):
		return

	player.velocity = Vector2.RIGHT * player.speed
	Input.action_press("ui_right")
	player.call("handle_movement")
	if not assert_or_fail(player.velocity.x > 0.0, "The player must still be able to move horizontally before testing punch"):
		return
	Input.action_press("attack")
	await get_tree().process_frame
	Input.action_release("attack")
	await get_tree().process_frame
	if not assert_or_fail(animation_player.current_animation == "punch", "Pressing attack while moving must still trigger the punch animation"):
		return

	print("VALIDATION_PASSED: fighter jab action and animation are implemented")
	get_tree().quit(0)
