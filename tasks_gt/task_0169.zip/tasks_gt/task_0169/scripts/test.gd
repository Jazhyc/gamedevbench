extends Node


func _ready() -> void:
	run_validation()


func fail(message: String) -> void:
	print("VALIDATION_FAILED: " + message)
	get_tree().quit(1)


func assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		fail(message)
		return false
	return true


func _get_animation_frames(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_VALUE:
			continue
		if String(animation.track_get_path(track_idx)) != "CharacterSprite:frame":
			continue

		var frames: Array = []
		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var frame_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if frames.is_empty() or frames[-1] != frame_value:
				frames.append(frame_value)
		return frames

	return []


func _get_animation_method_names(animation_player: AnimationPlayer, animation_name: String) -> Array:
	if not animation_player.has_animation(animation_name):
		return []

	var animation: Animation = animation_player.get_animation(animation_name)
	if animation == null:
		return []

	var method_names: Array = []
	for track_idx: int in range(animation.get_track_count()):
		if animation.track_get_type(track_idx) != Animation.TYPE_METHOD:
			continue

		for key_idx: int in range(animation.track_get_key_count(track_idx)):
			var key_value: Variant = animation.track_get_key_value(track_idx, key_idx)
			if key_value is Dictionary and key_value.has("method"):
				method_names.append(String(key_value["method"]))

	return method_names


func run_validation() -> void:
	var enemy_scene: PackedScene = load("res://scenes/characters/basic_enemy.tscn")
	if not assert_or_fail(enemy_scene != null, "basic_enemy.tscn must load"):
		return

	var enemy: Node2D = enemy_scene.instantiate() as Node2D
	if not assert_or_fail(enemy != null, "basic_enemy.tscn must instantiate"):
		return
	add_child(enemy)
	await get_tree().process_frame

	var sprite: Sprite2D = enemy.get_node_or_null("CharacterSprite") as Sprite2D
	if not assert_or_fail(sprite != null, "BasicEnemy must contain CharacterSprite"):
		return
	if not assert_or_fail(sprite.texture != null and sprite.texture.resource_path == "res://assets/art/characters/enemy_boss.png", "BasicEnemy must use res://assets/art/characters/enemy_boss.png as its sprite"):
		return

	var animation_player: AnimationPlayer = enemy.get_node_or_null("AnimationPlayer") as AnimationPlayer
	if not assert_or_fail(animation_player != null, "BasicEnemy must contain AnimationPlayer"):
		return

	if not assert_or_fail(_get_animation_frames(animation_player, "hurt") == [50, 51], "hurt animation must use the first 2 valid frames from the 6th row of the new spritesheet"):
		return
	if not assert_or_fail(_get_animation_frames(animation_player, "dead") == [60, 61, 62], "dead animation must use the first 3 valid frames from the 7th row of the new spritesheet"):
		return
	if not assert_or_fail("on_action_complete" in _get_animation_method_names(animation_player, "hurt"), "hurt animation must still call on_action_complete when it finishes"):
		return
	if not assert_or_fail("queue_free" in _get_animation_method_names(animation_player, "dead"), "dead animation must still call queue_free when it finishes"):
		return
	if not assert_or_fail(_get_animation_frames(animation_player, "idle") == [0], "idle animation must still exist"):
		return
	if not assert_or_fail(_get_animation_frames(animation_player, "walk") == [10, 11, 12, 13, 14, 15, 16, 17], "walk animation must still use the existing walk frames"):
		return

	print("VALIDATION_PASSED: enemy sprite and animation frames are updated")
	get_tree().quit(0)
