extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap")
	if not _assert_or_fail(tile_map != null and tile_map is TileMap, "TileMap node missing under Main"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap must have a TileSet assigned"):
		return

	if not _assert_or_fail(tile_set.get_custom_data_layers_count() >= 1, "TileSet must define a custom data layer"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_name(0) == "pipe", "The first custom data layer must be named pipe"):
		return
	if not _assert_or_fail(tile_set.get_custom_data_layer_type(0) == TYPE_BOOL, "The pipe custom data layer must be a boolean layer"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var pipe_tiles := {
		Vector2i(12, 6): true,
		Vector2i(13, 4): true,
		Vector2i(13, 5): true,
		Vector2i(13, 6): true,
		Vector2i(14, 4): true,
		Vector2i(14, 5): true,
		Vector2i(14, 6): true,
		Vector2i(15, 4): true,
		Vector2i(15, 5): true,
		Vector2i(15, 6): true,
	}

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			var pipe_value: Variant = tile_data.get_custom_data("pipe")
			if coords in pipe_tiles:
				if not _assert_or_fail(pipe_value == true, "Pipe tile (%d, %d) must have pipe set to true" % [x, y]):
					return
			else:
				if not _assert_or_fail(pipe_value == false, "Non-pipe tile (%d, %d) must have pipe set to false" % [x, y]):
					return

	print("VALIDATION_PASSED: pipe custom data layer is configured correctly.")
	get_tree().quit(0)
