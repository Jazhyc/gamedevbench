extends Node


const EXPECTED_POINTS := [
	Vector2(-9, -9),
	Vector2(9, -9),
	Vector2(9, 9),
	Vector2(-9, 9),
]


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _has_expected_collision(tile_data: TileData) -> bool:
	if tile_data.get_collision_polygons_count(0) != 1:
		return false
	return tile_data.get_collision_polygon_points(0, 0) == PackedVector2Array(EXPECTED_POINTS)


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return

	var source := tile_set.get_source(0)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 0 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var cloud_tiles := {
		Vector2i(13, 7): true,
		Vector2i(14, 7): true,
		Vector2i(15, 7): true,
		Vector2i(16, 7): true,
	}

	for y in range(9):
		for x in range(20):
			var coords := Vector2i(x, y)
			var tile_data: TileData = source.get_tile_data(coords, 0)
			if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for (%d, %d)" % [x, y]):
				return

			if coords in cloud_tiles:
				if not _assert_or_fail(_has_expected_collision(tile_data), "Cloud tile (%d, %d) must use the standard full-tile collision polygon" % [x, y]):
					return
				if not _assert_or_fail(tile_data.is_collision_polygon_one_way(0, 0), "Cloud tile (%d, %d) must use one-way collision" % [x, y]):
					return
			else:
				if tile_data.get_collision_polygons_count(0) > 0 and tile_data.is_collision_polygon_one_way(0, 0):
					if not _assert_or_fail(false, "Only the cloud platform tiles may use one-way collision; tile (%d, %d) must not be one-way" % [x, y]):
						return

	print("VALIDATION_PASSED: cloud one-way collision is configured correctly.")
	get_tree().quit(0)
