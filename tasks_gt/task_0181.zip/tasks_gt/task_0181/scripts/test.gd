extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _uses_valid_solution(tile_set: TileSet) -> bool:
	var width := tile_set.tile_size.x
	var height := tile_set.tile_size.y
	var width_valid := width >= 26 and width <= 32

	if tile_set.tile_shape == TileSet.TILE_SHAPE_HALF_OFFSET_SQUARE:
		return width_valid and height >= 17 and height <= 20
	if tile_set.tile_shape == TileSet.TILE_SHAPE_ISOMETRIC:
		return width_valid and height >= 36 and height <= 40
	return false


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return

	var default_tile_set := TileSet.new()
	if not _assert_or_fail(tile_set.tile_layout == default_tile_set.tile_layout, "TileSet tile_layout must not be changed"):
		return
	if not _assert_or_fail(tile_set.tile_offset_axis == default_tile_set.tile_offset_axis, "TileSet tile_offset_axis must not be changed"):
		return
	if not _assert_or_fail(_uses_valid_solution(tile_set), "TileSet must use a valid tile shape and tile size combination for the diagonal tileset"):
		return

	print("VALIDATION_PASSED: tile shape and tile size are configured correctly for the diagonal tileset.")
	get_tree().quit(0)
