extends Node


func _ready() -> void:
	run_validation()


func _fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)


func _assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		_fail(message)
		return false
	return true


func _is_walkable_polygon(polygon: NavigationPolygon) -> bool:
	return polygon != null and (not polygon.vertices.is_empty() or polygon.get_outline_count() > 0)


func run_validation() -> void:
	var main := get_node_or_null("Main")
	if not _assert_or_fail(main != null, "Main node not found"):
		return

	var tile_map := main.get_node_or_null("TileMap/Base")
	if not _assert_or_fail(tile_map != null and tile_map is TileMapLayer, "TileMap/Base layer missing"):
		return

	var tile_set: TileSet = tile_map.tile_set
	if not _assert_or_fail(tile_set != null, "TileMap layer must have a TileSet assigned"):
		return
	if not _assert_or_fail(tile_set.get_navigation_layers_count() >= 1, "TileSet must define a navigation layer"):
		return
	if not _assert_or_fail(tile_set.get_navigation_layer_layers(0) == 1, "Navigation layer 0 must use navigation map layer 1"):
		return

	var source := tile_set.get_source(1)
	if not _assert_or_fail(source != null and source is TileSetAtlasSource, "TileSet source 1 must be a TileSetAtlasSource"):
		return
	source = source as TileSetAtlasSource

	var walkable_tiles := {
		Vector2i(0, 0): true,
		Vector2i(1, 0): true,
		Vector2i(2, 0): true,
		Vector2i(0, 1): true,
		Vector2i(1, 1): true,
		Vector2i(2, 1): true,
		Vector2i(0, 2): true,
		Vector2i(1, 2): true,
		Vector2i(2, 2): true,
		Vector2i(0, 3): true,
		Vector2i(1, 3): true,
		Vector2i(2, 3): true,
		Vector2i(0, 4): true,
		Vector2i(1, 4): true,
		Vector2i(2, 4): true,
		Vector2i(0, 5): true,
	}

	var existing_tiles := [
		Vector2i(0, 0),
		Vector2i(1, 0),
		Vector2i(2, 0),
		Vector2i(3, 0),
		Vector2i(0, 1),
		Vector2i(1, 1),
		Vector2i(2, 1),
		Vector2i(3, 1),
		Vector2i(0, 2),
		Vector2i(1, 2),
		Vector2i(2, 2),
		Vector2i(3, 2),
		Vector2i(0, 3),
		Vector2i(1, 3),
		Vector2i(2, 3),
		Vector2i(3, 3),
		Vector2i(0, 4),
		Vector2i(1, 4),
		Vector2i(2, 4),
		Vector2i(0, 5),
		Vector2i(1, 5),
		Vector2i(0, 6),
		Vector2i(1, 6),
		Vector2i(0, 7),
		Vector2i(1, 7),
		Vector2i(0, 8),
	]

	for coords in existing_tiles:
		var tile_data: TileData = source.get_tile_data(coords, 0)
		if not _assert_or_fail(tile_data != null, "Atlas source must define tile data for %s" % coords):
			return

		var polygon: NavigationPolygon = tile_data.get_navigation_polygon(0)
		var is_walkable := _is_walkable_polygon(polygon)
		if coords in walkable_tiles:
			if not _assert_or_fail(is_walkable, "Path tile %s must remain walkable" % coords):
				return
		else:
			if not _assert_or_fail(not is_walkable, "Non-path tile %s must not be walkable" % coords):
				return

	print("VALIDATION_PASSED: only the path tiles are walkable.")
	get_tree().quit(0)
