extends Node

const EXPECTED_Z_INDEX := 99
const EXPECTED_POSITION := Vector2(320, 180)
const EXPECTED_AMOUNT := 20
const EXPECTED_LIFETIME := 6.0
const EXPECTED_SHAPE := 3
const EXPECTED_SHAPE_LABEL := "box"
const EXPECTED_SPREAD := 180.0
const EXPECTED_INITIAL_MIN := 20.0
const EXPECTED_INITIAL_MAX := 30.0
const EXPECTED_ANGULAR_MIN := 20.0
const EXPECTED_ANGULAR_MAX := 40.0
const EXPECTED_SCALE_MIN := 0.1
const EXPECTED_SCALE_MAX := 0.2

func _ready():
    run_validation()

func fail(message: String) -> void:
    print("VALIDATION_FAILED: %s" % message)
    get_tree().quit(1)

func assert_float(value: float, expected: float, label: String) -> bool:
    if abs(value - expected) > 0.001:
        fail("%s must be %s" % [label, expected])
        return false
    return true

func run_validation() -> void:
    var main_node = get_node_or_null("Main")
    if main_node == null:
        fail("Main scene not found")
        return

    var visuals = main_node.get_node_or_null("Visuals")
    if visuals == null or not (visuals is Node2D):
        fail("Visuals node missing or incorrect type")
        return

    var dust = visuals.get_node_or_null("DustParticles")
    if dust == null or not (dust is GPUParticles2D):
        fail("DustParticles GPUParticles2D missing")
        return

    if dust.z_index != EXPECTED_Z_INDEX:
        fail("DustParticles z_index must be %s" % EXPECTED_Z_INDEX)
        return
    if dust.position != EXPECTED_POSITION:
        fail("DustParticles position must be (320, 180)")
        return
    if dust.amount != EXPECTED_AMOUNT:
        fail("DustParticles amount must be %s" % EXPECTED_AMOUNT)
        return
    if not assert_float(dust.lifetime, EXPECTED_LIFETIME, "DustParticles lifetime"):
        return
    if dust.texture == null or not dust.texture.resource_path.ends_with("assets/sprites/star_particle.png"):
        fail("DustParticles texture must be star_particle.png")
        return

    var material = dust.process_material
    if material == null or not (material is ParticleProcessMaterial):
        fail("ParticleProcessMaterial missing")
        return

    if material.emission_shape != EXPECTED_SHAPE:
        fail("Emission shape must be %s" % EXPECTED_SHAPE_LABEL)
        return
    if not assert_float(material.emission_box_extents.x, 320.0, "Emission box extents X"):
        return
    if not assert_float(material.spread, EXPECTED_SPREAD, "Spread"):
        return
    if not assert_float(material.initial_velocity_min, EXPECTED_INITIAL_MIN, "Initial velocity min"):
        return
    if not assert_float(material.initial_velocity_max, EXPECTED_INITIAL_MAX, "Initial velocity max"):
        return
    if not assert_float(material.angular_velocity_min, EXPECTED_ANGULAR_MIN, "Angular velocity min"):
        return
    if not assert_float(material.angular_velocity_max, EXPECTED_ANGULAR_MAX, "Angular velocity max"):
        return
    if abs(material.gravity.y) > 0.001:
        fail("Gravity Y must be 0")
        return
    if not assert_float(material.scale_min, EXPECTED_SCALE_MIN, "Scale min"):
        return
    if not assert_float(material.scale_max, EXPECTED_SCALE_MAX, "Scale max"):
        return

    var curve_texture = material.scale_curve
    if curve_texture == null or not (curve_texture is CurveTexture):
        fail("Scale curve texture missing")
        return
    var curve = curve_texture.curve
    if curve == null:
        fail("Scale curve missing")
        return
    if curve.point_count < 1:
        fail("Scale curve must have at least one point")
        return

    if material.color.a <= 0.0 or material.color.a >= 1.0:
        fail("Particle color alpha must be between 0 and 1")
        return

    print("VALIDATION_PASSED: Task completed successfully")
    get_tree().quit(0)
