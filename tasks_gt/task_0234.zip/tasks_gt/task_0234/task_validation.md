# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0234`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(173.749, 180.879)`, `Level.scale = Vector2(0.53, 0.53)`, and `Level.rotation = -0.18`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
