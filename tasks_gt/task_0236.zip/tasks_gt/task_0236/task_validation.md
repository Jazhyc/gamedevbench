# Variant Summary

- Base task: `task_0227`
- Variant task: `task_0236`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(211.163, 22.665)`, `Level.scale = Vector2(0.55, 0.55)`, and `Level.rotation = 0.16`
- Solver work: add `StarHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the single yellow star collectible
