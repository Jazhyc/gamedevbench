# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0240`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(170.225, 12.571)`, `Level.scale = Vector2(0.62, 0.62)`, and `Level.rotation = 0.09`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
