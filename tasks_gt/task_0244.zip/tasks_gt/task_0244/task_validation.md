# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0244`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(188.509, -25.555)`, `Level.scale = Vector2(0.63, 0.63)`, and `Level.rotation = 0.16`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
