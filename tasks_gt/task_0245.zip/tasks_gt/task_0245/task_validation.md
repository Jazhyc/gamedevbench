# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0245`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(180.812, 188.842)`, `Level.scale = Vector2(0.52, 0.52)`, and `Level.rotation = -0.19`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
