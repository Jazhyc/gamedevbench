# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0246`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(158.137, 46.505)`, `Level.scale = Vector2(0.61, 0.61)`, and `Level.rotation = 0.03`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
