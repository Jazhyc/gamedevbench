# Variant Summary

- Base task: `task_0238`
- Variant task: `task_0247`
- Scene setup: the platformer image stays anchored from the top-left under `Level`, with `Level.position = Vector2(252.652, 15.589)`, `Level.scale = Vector2(0.55, 0.55)`, and `Level.rotation = 0.18`
- Solver work: add `GemstoneHighlights`, create one semi-transparent `Polygon2D`, and place it tightly over the gemstone
