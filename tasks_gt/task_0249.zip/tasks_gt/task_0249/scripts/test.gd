extends Node

func _ready() -> void:
	await run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func run_validation() -> void:
	var main := get_node_or_null("Main")
	if main == null:
		return fail("Main scene not found")

	var navigation_region := main.get_node_or_null("NavigationRegion2D")
	if not (navigation_region is NavigationRegion2D):
		return fail("NavigationRegion2D missing")

	var tile_map := navigation_region.get_node_or_null("TileMap")
	if not (tile_map is TileMap):
		return fail("TileMap must be a child of NavigationRegion2D")
	if tile_map.get_layer_name(0) != "Fence":
		return fail("TileMap layer 0 must be named Fence")
	if tile_map.get_layer_name(1) != "Terrain":
		return fail("TileMap layer 1 must be named Terrain")
	if tile_map.get_layer_z_index(1) != -1:
		return fail("Terrain layer must keep z_index -1")

	var enemy := main.get_node_or_null("Enemy")
	var target := main.get_node_or_null("Target")
	if not (enemy is CharacterBody2D):
		return fail("Enemy node missing")
	if not (target is Area2D):
		return fail("Target node missing")

	if enemy.collision_layer != 2:
		return fail("Enemy must keep collision layer 2")
	if enemy.motion_mode != CharacterBody2D.MOTION_MODE_FLOATING:
		return fail("Enemy must use floating motion")
	if not is_equal_approx(enemy.wall_min_slide_angle, 0.0):
		return fail("Enemy wall_min_slide_angle must be 0")

	var enemy_script: Script = enemy.get_script()
	if enemy_script == null:
		return fail("Enemy must have a script attached")
	var enemy_source := enemy_script.get_source_code()
	if enemy_source.find("@export var target") == -1:
		return fail("Enemy script must export the target node")
	if enemy_source.find("get_next_path_position") == -1:
		return fail("Enemy script must query NavigationAgent2D path positions")
	if enemy_source.find("velocity.lerp") == -1:
		return fail("Enemy script must smooth velocity toward the path direction")
	if enemy_source.find("target_position = target.global_position") == -1:
		return fail("Enemy script must update the navigation target position")

	var navigation_root := enemy.get_node_or_null("Navigation")
	if not (navigation_root is Node2D):
		return fail("Enemy must have a Navigation node")

	var navigation_agent := navigation_root.get_node_or_null("NavigationAgent2D")
	if not (navigation_agent is NavigationAgent2D):
		return fail("NavigationAgent2D missing")

	var timer := navigation_root.get_node_or_null("Timer")
	if not (timer is Timer):
		return fail("Navigation timer missing")
	if not is_equal_approx(timer.wait_time, 0.1):
		return fail("Timer wait_time must be 0.1")
	if timer.timeout.get_connections().is_empty():
		return fail("Timer timeout must be connected")

	if enemy.get("target") != target:
		return fail("Enemy.target must resolve to Target at runtime")

	for _i in 2:
		await get_tree().physics_frame

	var original_target_position: Vector2 = target.global_position
	var moved_target: Vector2 = original_target_position + Vector2(32.0, 48.0)
	target.global_position = moved_target
	enemy.call("_on_timer_timeout")
	await get_tree().physics_frame
	if navigation_agent.target_position.distance_to(moved_target) > 0.01:
		return fail("Timer callback must push the target position into NavigationAgent2D")

	target.global_position = original_target_position
	enemy.call("_on_timer_timeout")
	await get_tree().physics_frame

	print("VALIDATION_PASSED: tilemap navigation chase restored")
	get_tree().quit()
