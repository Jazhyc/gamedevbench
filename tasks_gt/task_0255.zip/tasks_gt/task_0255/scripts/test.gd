extends Node

func _ready() -> void:
	await run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func run_validation() -> void:
	var main := get_node_or_null("Main")
	if main == null:
		return fail("Main scene not found")

	var navigation_region := main.get_node_or_null("NavigationRegion2D")
	if not (navigation_region is NavigationRegion2D):
		return fail("NavigationRegion2D missing")

	var tile_map := navigation_region.get_node_or_null("TileMap")
	if not (tile_map is TileMap):
		return fail("TileMap must stay under NavigationRegion2D")
	if tile_map.get_layer_name(0) != "Fence":
		return fail("TileMap layer 0 must be Fence")
	if tile_map.get_layer_name(1) != "Terrain":
		return fail("TileMap layer 1 must be Terrain")
	if tile_map.get_layer_z_index(1) != -1:
		return fail("Terrain layer z_index must remain -1")

	var controller := main.get_node_or_null("Bot")
	var target := main.get_node_or_null("Checkpoint")
	if not (controller is CharacterBody2D):
		return fail("Bot node missing")
	if not (target is Area2D):
		return fail("Checkpoint node missing")

	if controller.collision_layer != 2:
		return fail("Bot must keep collision layer 2")
	if controller.motion_mode != CharacterBody2D.MOTION_MODE_FLOATING:
		return fail("Bot must use floating motion")
	if not is_equal_approx(controller.wall_min_slide_angle, 0.0):
		return fail("Bot wall_min_slide_angle must be 0")

	var script_resource: Script = controller.get_script()
	if script_resource == null:
		return fail("Bot must have a script attached")
	if script_resource.resource_path != "res://Bot.gd":
		return fail("Bot must use res://Bot.gd")
	var source := script_resource.get_source_code()
	if source.find("@export var checkpoint") == -1:
		return fail("Bot.gd must export the checkpoint node")
	if source.find("get_next_path_position") == -1:
		return fail("Bot.gd must query NavigationAgent2D path positions")
	if source.find("velocity.lerp") == -1:
		return fail("Bot.gd must smooth velocity toward the path direction")
	if source.find("target_position = checkpoint.global_position") == -1:
		return fail("Bot.gd must update the navigation target position")

	var navigation_root := controller.get_node_or_null("Navigation")
	if not (navigation_root is Node2D):
		return fail("Bot must have a Navigation node")

	var navigation_agent := navigation_root.get_node_or_null("NavigationAgent2D")
	if not (navigation_agent is NavigationAgent2D):
		return fail("NavigationAgent2D missing")

	var timer := navigation_root.get_node_or_null("Timer")
	if not (timer is Timer):
		return fail("Navigation timer missing")
	if not is_equal_approx(timer.wait_time, 0.1):
		return fail("Timer wait_time must be 0.1")
	if timer.timeout.get_connections().is_empty():
		return fail("Timer timeout must be connected")

	if controller.get("checkpoint") != target:
		return fail("Bot checkpoint must resolve to the live Checkpoint node at runtime")

	for _i in 2:
		await get_tree().physics_frame

	await get_tree().physics_frame
	if controller.get("checkpoint") != target:
		return fail("Bot checkpoint reference must stay bound after physics updates")

	var original_target_position: Vector2 = target.global_position
	var moved_target: Vector2 = original_target_position
	moved_target = original_target_position + Vector2(28.0, 44.0)
	moved_target = moved_target + Vector2(8.0, -12.0)

	target.global_position = moved_target
	controller.call("_on_timer_timeout")
	await get_tree().physics_frame
	if navigation_agent.target_position.distance_to(moved_target) > 0.01:
		return fail("Timer callback must push the latest Checkpoint position into NavigationAgent2D")

	target.global_position = moved_target
	controller.call("_on_timer_timeout")
	await get_tree().physics_frame
	if navigation_agent.target_position.distance_to(moved_target) > 0.01:
		return fail("Timer callback must push the latest Checkpoint position into NavigationAgent2D")
	target.global_position = original_target_position
	controller.call("_on_timer_timeout")
	await get_tree().physics_frame

	print("VALIDATION_PASSED: tilemap bot checkpoint variant f restored")
	get_tree().quit()
