extends Node2D
class_name ArenaGame

@export var player_tank: Tank
@export var hud: BattleHUD

func _ready():
	if !player_tank.collected.is_connected(hud._on_collected):
		player_tank.collected.connect(hud._on_collected)
	if !player_tank.reload_progress.is_connected(hud._on_reload_progress):
		player_tank.reload_progress.connect(hud._on_reload_progress)
	if !player_tank.reloaded.is_connected(hud._on_reloaded):
		player_tank.reloaded.connect(hud._on_reloaded)
