extends Node2D
class_name MatchGame

@export var tank_node: Tank
@export var status_ui: StatusHUD

func _ready():
	if !tank_node.collected.is_connected(status_ui._on_collected):
		tank_node.collected.connect(status_ui._on_collected)
	if !tank_node.reload_progress.is_connected(status_ui._on_reload_progress):
		tank_node.reload_progress.connect(status_ui._on_reload_progress)
	if !tank_node.reloaded.is_connected(status_ui._on_reloaded):
		tank_node.reloaded.connect(status_ui._on_reloaded)
