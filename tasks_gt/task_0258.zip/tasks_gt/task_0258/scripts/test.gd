extends Node

func _ready() -> void:
	await run_validation()

func fail(message: String) -> void:
	print("VALIDATION_FAILED: %s" % message)
	get_tree().quit(1)

func assert_or_fail(condition: bool, message: String) -> bool:
	if not condition:
		fail(message)
		return false
	return true

func approx_equal(a: float, b: float, epsilon: float = 0.05) -> bool:
	return abs(a - b) <= epsilon

func wait_frames(count: int) -> void:
	for _i in range(count):
		await get_tree().process_frame

func find_named_node(root: Node, node_name: String) -> Node:
	return root.find_child(node_name, true, false)

func texture_resource_path(texture: Texture2D) -> String:
	if texture == null:
		return ""
	if texture is AtlasTexture:
		var atlas_texture: AtlasTexture = texture
		if atlas_texture.atlas == null:
			return ""
		return atlas_texture.atlas.resource_path
	return texture.resource_path

func run_validation() -> void:
	await wait_frames(2)

	var main = get_node_or_null("Main")
	if not assert_or_fail(main is Node, "scenes/test.tscn must instance scenes/main.tscn as Main"):
		return
	if not assert_or_fail(ResourceLoader.exists("res://scenes/main.tscn"), "Missing res://scenes/main.tscn"):
		return

	var main_scene_path: String = ProjectSettings.get_setting("application/run/main_scene", "")
	if not assert_or_fail(main_scene_path == "res://scenes/game.tscn", "Project main scene must be res://scenes/game.tscn"):
		return

	if not assert_or_fail(ResourceLoader.exists("res://scenes/game.tscn"), "Missing res://scenes/game.tscn"):
		return
	if not assert_or_fail(ResourceLoader.exists("res://scenes/ui/ui.tscn"), "Missing res://scenes/ui/ui.tscn"):
		return

	await wait_frames(4)

	var game = main.get_node_or_null("ProjectRoot")
	if not assert_or_fail(game is Node2D, "scenes/main.tscn must load the configured project main scene as ProjectRoot"):
		return

	var world = game.get_node_or_null("World")
	var tank = game.get_node_or_null("Tank")
	var ui = game.get_node_or_null("UI")

	if not assert_or_fail(world is Node2D, "game.tscn must instance the World scene as World"):
		return
	if not assert_or_fail(tank is CharacterBody2D, "game.tscn must instance the Tank scene as Tank"):
		return
	if not assert_or_fail(ui is CanvasLayer, "game.tscn must instance the UI scene as UI"):
		return
	if not assert_or_fail(game.get("tank_node") == tank, "game.gd must bind the exported tank_node reference to the Tank node"):
		return
	if not assert_or_fail(game.get("status_ui") == ui, "game.gd must bind the exported status_ui reference to the UI node"):
		return

	var score_label_node = find_named_node(ui, "Score")
	var reload_progress_node = find_named_node(ui, "ReloadProgress")

	if not assert_or_fail(score_label_node is Label, "UI must contain a Label named Score"):
		return
	if not assert_or_fail(reload_progress_node is TextureProgressBar, "UI must contain a TextureProgressBar named ReloadProgress"):
		return

	var score_label: Label = score_label_node
	var reload_progress: TextureProgressBar = reload_progress_node

	if not assert_or_fail(score_label.unique_name_in_owner, "Score must be marked as a unique-name node"):
		return
	if not assert_or_fail(reload_progress.unique_name_in_owner, "ReloadProgress must be marked as a unique-name node"):
		return
	if not assert_or_fail(score_label.text == "0", "Score label must initialize to 0"):
		return
	if not assert_or_fail(approx_equal(reload_progress.max_value, 1.0, 0.001), "ReloadProgress max_value must be 1.0"):
		return
	if not assert_or_fail(approx_equal(reload_progress.step, 0.2, 0.001), "ReloadProgress step must be 0.2"):
		return
	if not assert_or_fail(reload_progress.fill_mode == 3, "ReloadProgress must fill from bottom to top"):
		return
	if not assert_or_fail(approx_equal(reload_progress.value, 1.0, 0.001), "ReloadProgress must start full"):
		return
	if not assert_or_fail(texture_resource_path(reload_progress.texture_under) == "res://assets/sprites/ammo_ui_icon.png", "ReloadProgress texture_under must come from res://assets/sprites/ammo_ui_icon.png"):
		return
	if not assert_or_fail(texture_resource_path(reload_progress.texture_progress) == "res://assets/sprites/ammo_ui_icon.png", "ReloadProgress texture_progress must come from res://assets/sprites/ammo_ui_icon.png"):
		return
	var pickup_scene: Variant = load("res://scenes/entities/world/pickup.tscn")
	if not assert_or_fail(pickup_scene is PackedScene, "Pickup scene must still load"):
		return

	var pickup = pickup_scene.instantiate()
	game.add_child(pickup)
	pickup._on_body_entered(tank)
	await wait_frames(3)

	if not assert_or_fail(score_label.text == "125", "Collecting one pickup must raise the score to 125"):
		return

	var weapon = tank.get_node_or_null("Weapon")
	if not assert_or_fail(weapon != null, "Tank must still contain its Weapon child"):
		return

	weapon.fire()
	await wait_frames(10)

	if not assert_or_fail(reload_progress.value > 0.0 and reload_progress.value < 1.0, "ReloadProgress must update while the weapon reload timer is running"):
		return

	await get_tree().create_timer(0.7).timeout
	await wait_frames(4)

	if not assert_or_fail(approx_equal(reload_progress.value, 1.0, 0.05), "ReloadProgress must return to full after reloading completes"):
		return

	print("VALIDATION_PASSED: UI scene, game wrapper, and signal-driven HUD behavior restored")
	get_tree().quit()
