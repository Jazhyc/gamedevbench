extends Node2D
class_name MissionGame

@export var vehicle: Tank
@export var overlay: OverlayUI

func _ready():
	if !vehicle.collected.is_connected(overlay._on_collected):
		vehicle.collected.connect(overlay._on_collected)
	if !vehicle.reload_progress.is_connected(overlay._on_reload_progress):
		vehicle.reload_progress.connect(overlay._on_reload_progress)
	if !vehicle.reloaded.is_connected(overlay._on_reloaded):
		vehicle.reloaded.connect(overlay._on_reloaded)
