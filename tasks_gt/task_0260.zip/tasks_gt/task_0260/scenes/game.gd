extends Node2D
class_name CombatGame

@export var tank_actor: Tank
@export var hud_layer: HUDLayer

func _ready():
	if !tank_actor.collected.is_connected(hud_layer._on_collected):
		tank_actor.collected.connect(hud_layer._on_collected)
	if !tank_actor.reload_progress.is_connected(hud_layer._on_reload_progress):
		tank_actor.reload_progress.connect(hud_layer._on_reload_progress)
	if !tank_actor.reloaded.is_connected(hud_layer._on_reloaded):
		tank_actor.reloaded.connect(hud_layer._on_reloaded)
