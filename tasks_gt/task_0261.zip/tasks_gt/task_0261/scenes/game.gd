extends Node2D
class_name StageGame

@export var hero_tank: Tank
@export var scoreboard: TankHUD

func _ready():
	if !hero_tank.collected.is_connected(scoreboard._on_collected):
		hero_tank.collected.connect(scoreboard._on_collected)
	if !hero_tank.reload_progress.is_connected(scoreboard._on_reload_progress):
		hero_tank.reload_progress.connect(scoreboard._on_reload_progress)
	if !hero_tank.reloaded.is_connected(scoreboard._on_reloaded):
		hero_tank.reloaded.connect(scoreboard._on_reloaded)
