class_name DetectRange
extends Area2D

@export var col_shape: CollisionShape2D
@export var base_range_size: float
@export var actor: BattleUnit:
	set(value):
		actor = value
		collision_layer = 4 * (actor.stats.team + 1)
		collision_mask = 2 - actor.stats.team
		
		var shape := CircleShape2D.new()
		shape.radius = base_range_size * actor.stats.attack_range
		col_shape.shape = shape
