class_name DetectRange
extends Area2D

signal unit_entered_range(unit: BattleUnit)
signal unit_exited_range(unit: BattleUnit)

@export var col_shape: CollisionShape2D
@export var base_range_size: float
@export var stats: UnitStats:
	set(value):
		stats = value
		collision_layer = 4 * (stats.team + 1)
		collision_mask = 2 - stats.team
		
		var shape := CircleShape2D.new()
		shape.radius = base_range_size * stats.attack_range
		col_shape.shape = shape


func _ready() -> void:
	area_entered.connect(_on_area_entered)
	area_exited.connect(_on_area_exited)


func _on_area_entered(area: Area2D) -> void:
	if area is BattleUnit:
		unit_entered_range.emit(area)


func _on_area_exited(area: Area2D) -> void:
	if area is BattleUnit:
		unit_exited_range.emit(area)
