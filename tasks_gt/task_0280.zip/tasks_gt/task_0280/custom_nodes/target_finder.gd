class_name TargetFinder
extends Node

signal targets_in_range_changed

@export var actor: BattleUnit

var target: BattleUnit
var targets_in_range: Array[BattleUnit]


func _ready() -> void:
	actor.ready.connect(
		func():
			actor.detect_range.unit_entered_range.connect(_on_unit_entered_range)
			actor.detect_range.unit_exited_range.connect(_on_unit_exited_range)
	, CONNECT_ONE_SHOT
	)


func find_target() -> void:
	var opposing_group: String = UnitStats.TARGET[actor.stats.team]
	var all_targets := actor.get_tree().get_nodes_in_group(opposing_group)
	var distances := all_targets.map(
		func(target_candidate: BattleUnit) -> float:
			return actor.global_position.distance_squared_to(target_candidate.global_position)
	)
	var idx := distances.find(distances.min())
	
	target = all_targets[idx]


func has_target_in_range() -> bool:
	return targets_in_range.size() > 0


func _on_unit_entered_range(unit: BattleUnit) -> void:
	targets_in_range.append(unit)
	targets_in_range_changed.emit()


func _on_unit_exited_range(unit: BattleUnit) -> void:
	targets_in_range.erase(unit)
	targets_in_range_changed.emit()
